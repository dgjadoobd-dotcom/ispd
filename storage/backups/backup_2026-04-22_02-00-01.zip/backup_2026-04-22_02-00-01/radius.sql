-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: radius
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activity_log`
--

DROP TABLE IF EXISTS `activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activity_log` (
  `id` bigint(21) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `username` varchar(64) DEFAULT '',
  `action` varchar(64) NOT NULL,
  `module` varchar(64) DEFAULT '',
  `description` text DEFAULT NULL,
  `old_data` text DEFAULT NULL,
  `new_data` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT '',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `action` (`action`),
  KEY `module` (`module`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_log`
--

LOCK TABLES `activity_log` WRITE;
/*!40000 ALTER TABLE `activity_log` DISABLE KEYS */;
INSERT INTO `activity_log` VALUES (1,1,'admin','login','auth','User logged in',NULL,NULL,'172.17.50.10','2026-03-27 02:03:56'),(2,1,'admin','login','auth','User logged in',NULL,NULL,'127.0.0.1','2026-03-27 02:53:25'),(3,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-27 03:01:45'),(4,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-27 03:02:22'),(5,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-27 03:47:57'),(6,1,'admin','login','auth','User logged in',NULL,NULL,'127.0.0.1','2026-03-27 03:49:24'),(7,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-27 04:05:26'),(8,1,'admin','login','auth','User logged in',NULL,NULL,'127.0.0.1','2026-03-27 06:47:09'),(9,1,'admin','update_settings','settings','Updated system settings',NULL,NULL,'127.0.0.1','2026-03-27 06:56:20'),(10,1,'admin','login','auth','User logged in',NULL,NULL,'127.0.0.1','2026-03-27 07:00:42'),(11,1,'admin','login','auth','User logged in',NULL,NULL,'127.0.0.1','2026-03-27 07:18:08'),(12,1,'admin','login','auth','User logged in',NULL,NULL,'127.0.0.1','2026-03-27 07:18:50'),(13,1,'','logout','auth','User logged out',NULL,NULL,'','2026-03-27 07:18:50'),(14,1,'admin','login','auth','User logged in',NULL,NULL,'127.0.0.1','2026-03-27 11:10:07'),(15,1,'admin','login','auth','User logged in',NULL,NULL,'127.0.0.1','2026-03-29 01:46:36'),(16,1,'admin','login','auth','User logged in',NULL,NULL,'127.0.0.1','2026-03-29 08:00:15'),(17,1,'admin','login','auth','User logged in',NULL,NULL,'127.0.0.1','2026-03-29 17:46:45'),(18,1,'admin','login','auth','User logged in',NULL,NULL,'127.0.0.1','2026-03-30 19:14:00'),(19,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-31 08:43:36'),(20,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-31 08:43:48'),(21,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-31 08:44:03'),(22,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-31 08:45:52'),(23,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-31 08:52:00'),(24,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-31 08:52:41'),(25,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-31 08:53:51'),(26,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-31 08:54:02'),(27,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-31 08:55:04'),(28,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-31 08:56:19'),(29,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-31 08:57:53'),(30,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-31 09:03:38'),(31,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-31 09:04:08'),(32,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-31 09:15:13'),(33,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-31 09:16:47'),(34,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-31 09:17:04'),(35,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-31 09:18:45'),(36,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-31 09:20:01'),(37,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-31 09:20:31'),(38,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-31 09:21:17'),(39,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-31 09:21:35'),(40,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-31 09:23:57'),(41,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-31 10:29:25');
/*!40000 ALTER TABLE `activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_permissions`
--

DROP TABLE IF EXISTS `admin_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permission_name` varchar(128) NOT NULL,
  `permission_slug` varchar(128) NOT NULL,
  `module` varchar(64) NOT NULL,
  `description` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `permission_slug` (`permission_slug`),
  KEY `module` (`module`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_permissions`
--

LOCK TABLES `admin_permissions` WRITE;
/*!40000 ALTER TABLE `admin_permissions` DISABLE KEYS */;
INSERT INTO `admin_permissions` VALUES (1,'View Dashboard','dashboard.view','dashboard','View dashboard statistics'),(2,'View Users','users.view','users','View RADIUS users'),(3,'Create Users','users.create','users','Create new RADIUS users'),(4,'Edit Users','users.edit','users','Edit existing RADIUS users'),(5,'Delete Users','users.delete','users','Delete RADIUS users'),(6,'Disconnect Users','users.disconnect','users','Disconnect user sessions'),(7,'Manage User Attributes','users.attributes','users','Manage RADIUS attributes'),(8,'View Groups','groups.view','groups','View user groups'),(9,'Create Groups','groups.create','groups','Create new groups'),(10,'Edit Groups','groups.edit','groups','Edit existing groups'),(11,'Delete Groups','groups.delete','groups','Delete groups'),(12,'View Plans','plans.view','plans','View billing plans'),(13,'Create Plans','plans.create','plans','Create billing plans'),(14,'Edit Plans','plans.edit','plans','Edit billing plans'),(15,'Delete Plans','plans.delete','plans','Delete billing plans'),(16,'View NAS','nas.view','nas','View NAS devices'),(17,'Create NAS','nas.create','nas','Create NAS devices'),(18,'Edit NAS','nas.edit','nas','Edit NAS devices'),(19,'Delete NAS','nas.delete','nas','Delete NAS devices'),(20,'View Sessions','sessions.view','sessions','View active sessions'),(21,'Disconnect Sessions','sessions.disconnect','sessions','Kill active sessions'),(22,'View Traffic','traffic.view','traffic','View traffic data'),(23,'View Accounting','accounting.view','accounting','View accounting records'),(24,'View Auth Log','authlog.view','authlog','View authentication log'),(25,'View OLT','olt.view','olt','View OLT devices'),(26,'Create OLT','olt.create','olt','Create OLT devices'),(27,'Edit OLT','olt.edit','olt','Edit OLT devices'),(28,'Delete OLT','olt.delete','olt','Delete OLT devices'),(29,'Sync OLT','olt.sync','olt','Sync OLT data'),(30,'Manage ONU','onu.manage','olt','Manage ONU devices'),(31,'View Payments','payments.view','payments','View payments and invoices'),(32,'Create Invoice','payments.create','payments','Create invoices'),(33,'Cancel Invoice','payments.cancel','payments','Cancel invoices'),(34,'Manage Gateways','payments.gateways','payments','Manage payment gateways'),(35,'View Billing','billing.view','billing','View auto-billing'),(36,'Run Cron','billing.cron','billing','Run billing cron'),(37,'Manage Schedules','billing.schedules','billing','Manage billing schedules'),(38,'View SMS','sms.view','sms','View SMS log'),(39,'Send SMS','sms.send','sms','Send SMS messages'),(40,'Manage Templates','sms.templates','sms','Manage SMS templates'),(41,'Manage Providers','sms.providers','sms','Manage SMS providers'),(42,'View Settings','settings.view','settings','View system settings'),(43,'Edit Settings','settings.edit','settings','Edit system settings'),(44,'View Admin Users','adminusers.view','adminusers','View admin users'),(45,'Create Admin Users','adminusers.create','adminusers','Create admin users'),(46,'Edit Admin Users','adminusers.edit','adminusers','Edit admin users'),(47,'Delete Admin Users','adminusers.delete','adminusers','Delete admin users'),(48,'View Roles','roles.view','roles','View roles and permissions'),(49,'Create Roles','roles.create','roles','Create roles'),(50,'Edit Roles','roles.edit','roles','Edit roles'),(51,'Delete Roles','roles.delete','roles','Delete roles'),(52,'View Resellers','resellers.view','resellers','View resellers'),(53,'Manage Resellers','resellers.manage','resellers','Manage reseller config'),(54,'Credit Reseller','resellers.credit','resellers','Add/deduct reseller credit'),(55,'View Reports','reports.view','reports','View reports'),(56,'Export Reports','reports.export','reports','Export reports'),(57,'View Activity Log','activitylog.view','activitylog','View activity log');
/*!40000 ALTER TABLE `admin_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_role_permissions`
--

DROP TABLE IF EXISTS `admin_role_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_role_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_permission` (`role_id`,`permission_id`),
  KEY `role_id` (`role_id`),
  KEY `permission_id` (`permission_id`),
  CONSTRAINT `admin_role_permissions_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `admin_roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `admin_role_permissions_ibfk_2` FOREIGN KEY (`permission_id`) REFERENCES `admin_permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=183 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_role_permissions`
--

LOCK TABLES `admin_role_permissions` WRITE;
/*!40000 ALTER TABLE `admin_role_permissions` DISABLE KEYS */;
INSERT INTO `admin_role_permissions` VALUES (11,1,1),(52,1,2),(53,1,3),(54,1,4),(55,1,5),(56,1,6),(57,1,7),(12,1,8),(13,1,9),(14,1,10),(15,1,11),(30,1,12),(31,1,13),(32,1,14),(33,1,15),(16,1,16),(17,1,17),(18,1,18),(19,1,19),(43,1,20),(44,1,21),(51,1,22),(1,1,23),(7,1,24),(20,1,25),(21,1,26),(22,1,27),(23,1,28),(24,1,29),(25,1,30),(26,1,31),(27,1,32),(28,1,33),(29,1,34),(8,1,35),(9,1,36),(10,1,37),(47,1,38),(48,1,39),(49,1,40),(50,1,41),(45,1,42),(46,1,43),(3,1,44),(4,1,45),(5,1,46),(6,1,47),(39,1,48),(40,1,49),(41,1,50),(42,1,51),(36,1,52),(37,1,53),(38,1,54),(34,1,55),(35,1,56),(2,1,57),(73,2,1),(117,2,2),(113,2,3),(116,2,4),(114,2,5),(115,2,6),(112,2,7),(77,2,8),(74,2,9),(76,2,10),(75,2,11),(95,2,12),(92,2,13),(94,2,14),(93,2,15),(81,2,16),(78,2,17),(80,2,18),(79,2,19),(105,2,20),(104,2,21),(111,2,22),(64,2,23),(69,2,24),(86,2,25),(82,2,26),(84,2,27),(83,2,28),(85,2,29),(87,2,30),(91,2,31),(89,2,32),(88,2,33),(90,2,34),(72,2,35),(70,2,36),(71,2,37),(110,2,38),(108,2,39),(109,2,40),(107,2,41),(106,2,42),(68,2,44),(66,2,45),(67,2,46),(103,2,48),(101,2,49),(102,2,50),(100,2,52),(99,2,53),(98,2,54),(97,2,55),(96,2,56),(65,2,57),(129,3,1),(140,3,2),(137,3,3),(139,3,4),(138,3,6),(136,3,7),(130,3,8),(131,3,12),(134,3,20),(133,3,21),(135,3,22),(127,3,23),(128,3,35),(132,3,55),(144,4,1),(153,4,2),(150,4,3),(152,4,4),(151,4,6),(145,4,8),(146,4,12),(148,4,20),(147,4,21),(149,4,22),(142,4,23),(143,4,24),(159,5,1),(162,5,2),(160,5,20),(161,5,22),(157,5,23),(158,5,24),(169,6,1),(182,6,2),(170,6,8),(174,6,12),(171,6,16),(178,6,20),(181,6,22),(164,6,23),(167,6,24),(172,6,25),(173,6,31),(168,6,35),(180,6,38),(179,6,42),(166,6,44),(177,6,48),(176,6,52),(175,6,55),(165,6,57);
/*!40000 ALTER TABLE `admin_role_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_roles`
--

DROP TABLE IF EXISTS `admin_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(64) NOT NULL,
  `role_slug` varchar(64) NOT NULL,
  `description` varchar(255) DEFAULT '',
  `is_default` tinyint(1) DEFAULT 0,
  `is_system` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_slug` (`role_slug`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_roles`
--

LOCK TABLES `admin_roles` WRITE;
/*!40000 ALTER TABLE `admin_roles` DISABLE KEYS */;
INSERT INTO `admin_roles` VALUES (1,'Super Admin','super-admin','Full system access',0,1,'2026-03-27 02:02:53'),(2,'Admin','admin','Administrative access',0,1,'2026-03-27 02:02:53'),(3,'Reseller','reseller','Reseller with credit-based user management',0,1,'2026-03-27 02:02:53'),(4,'Employee','employee','Staff member with limited access',0,1,'2026-03-27 02:02:53'),(5,'Support','support','Support staff - view and ticket management',0,1,'2026-03-27 02:02:53'),(6,'Viewer','viewer','Read-only access',1,1,'2026-03-27 02:02:53');
/*!40000 ALTER TABLE `admin_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_sessions`
--

DROP TABLE IF EXISTS `admin_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_sessions` (
  `id` bigint(21) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `session_token` varchar(128) NOT NULL,
  `ip_address` varchar(45) DEFAULT '',
  `user_agent` varchar(512) DEFAULT '',
  `expires_at` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `session_token` (`session_token`),
  KEY `user_id` (`user_id`),
  KEY `expires_at` (`expires_at`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_sessions`
--

LOCK TABLES `admin_sessions` WRITE;
/*!40000 ALTER TABLE `admin_sessions` DISABLE KEYS */;
INSERT INTO `admin_sessions` VALUES (5,1,'9bd701d20242bbbde0155bb03e337fb496ac05376c8791e65226609d2750076c','::1','','2026-03-27 10:47:57','2026-03-27 03:47:57'),(6,1,'64c1f709d0bb3bd541d458852916ada06699c5820cba8e9d66a2dc073ee0274f','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0','2026-03-27 11:18:49','2026-03-27 03:49:24'),(7,1,'d2a9c93537455782bfbe9d6ede4575d00c5155c293fb6a36d39308c6f851f8b6','::1','','2026-03-27 11:05:26','2026-03-27 04:05:26'),(8,1,'aa69e80a5d014f6fc28a2d8db35c89cf331d7f06938cb8649bf53731ae1de671','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0','2026-03-27 13:57:38','2026-03-27 06:47:09'),(9,1,'6c801728d64f96a6cadbf5059c5e723aacc6f11136ab1e26dfd19ddcdcc0e57a','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0','2026-03-27 16:06:48','2026-03-27 07:00:42'),(10,1,'04a6419f7513ce49c0c86ff83ead551e13f4c7f7a3ece3c304850a3ebf4c173c','127.0.0.1','','2026-03-27 09:18:08','2026-03-27 07:18:08'),(12,1,'3c336c45d7f90af33bd323b1016c0de1955e9b4722aaf96a520175879c8fc757','172.17.50.10','curl/8.18.0','2026-03-27 09:59:02','2026-03-27 07:48:37'),(13,1,'4b17d92127a45887ea8c0410114bcdb980d1cf426d95b94bc74c6b62a4c2845e','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0','2026-03-27 18:40:38','2026-03-27 11:10:07'),(14,1,'ab66275c4bbe3377ee747b71061f6cf03b1352ab047b2d5309bb002924ed59f8','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0','2026-03-29 08:46:52','2026-03-29 01:46:36'),(15,1,'b12d0d42aa90c42cfcf230a20d9a0b5c33ebf6818da6f219f6aa885c85ddedf8','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0','2026-03-29 15:00:34','2026-03-29 08:00:15'),(16,1,'a2176f79764b8874c6f1564ca0d5b4baf0f708ed15fe0b5ee853e7569b304734','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0','2026-03-30 00:48:06','2026-03-29 17:46:45'),(17,1,'802dbb1ef29a2c209f22116f76d65a55668ad3a932c1ddb8350abba7989272b0','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0','2026-03-31 02:14:14','2026-03-30 19:14:00'),(18,1,'c72e7cc6262e846e908cf476f40c8ba93e3b1dabc4b0a694e8d1881694074bf9','::1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920','2026-03-31 11:43:35','2026-03-31 08:43:36'),(19,1,'1815ee83b735fe49e70a5e85763595094439f4bd6821648aa17668454c434ca7','::1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920','2026-03-31 11:43:48','2026-03-31 08:43:48'),(20,1,'3164fc7f89fc54b234488b92af6f4bf1b280740ec9c364ea317232a7b4ae2e36','::1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920','2026-03-31 11:44:03','2026-03-31 08:44:03'),(21,1,'a59b04157df50a049e088a881a645fef43ace5d32702c31ae429dd1be9e40b77','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36','2026-03-31 11:45:52','2026-03-31 08:45:52'),(22,1,'87d7ffa57f12cc7b5861838c7a94d7a0fa66006ed4258a501374141461c48a6d','::1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920','2026-03-31 11:52:00','2026-03-31 08:52:00'),(23,1,'c66dbda2046a53b84f0075089ff568ba521437e41b551c63bb3dabcefb587bd3','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36','2026-03-31 11:52:41','2026-03-31 08:52:41'),(24,1,'131d80fc6946ed9685677ea59b0d60185764509c17d9aac397502f21d8d152bd','::1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920','2026-03-31 11:53:51','2026-03-31 08:53:51'),(25,1,'4d2ba3570e7bae849eceba9876a257954e73b1caae86cb04053fa7694073dbeb','::1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920','2026-03-31 11:54:02','2026-03-31 08:54:02'),(26,1,'88db3b5aca5d75e2f3aba9ab8e40ba0ab76600e39056454ee3ca270d7cd7a236','::1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920','2026-03-31 11:55:04','2026-03-31 08:55:04'),(27,1,'6a65699c6abd76736c968da5e5d4402ffb24190c7489e955b669e3b86ff42712','::1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920','2026-03-31 11:56:19','2026-03-31 08:56:19'),(28,1,'acbba7ac52377babd069ba28b80a4259ff80be1b5cc10c138c8027c6c36684c0','::1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920','2026-03-31 11:57:53','2026-03-31 08:57:53'),(29,1,'2947b7bc31fbca07a63aa0c23e70fea3b291be196a5c49f8b91a6d963137eae5','::1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920','2026-03-31 12:03:40','2026-03-31 09:03:38'),(30,1,'4925d70690f6d6fde1427852d2d587e63f2c74a5680d8b97a139a7c206151b02','::1','','2026-03-31 12:04:09','2026-03-31 09:04:08'),(31,1,'e742c1d2258da11df28fcfc1f75a289ad36102c95a06bbfed2e861884eb7f351','::1','','2026-03-31 12:15:13','2026-03-31 09:15:13'),(32,1,'e5ea7e25fb899ac99dfc616df1e32e95bbc304f1c95ee0b58dae51329b3cac7f','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36','2026-03-31 12:16:47','2026-03-31 09:16:47'),(33,1,'06544f2beb8ea419c0cb11493b3f2f1df9945ef5266b7c5127ed8a3d5faa35d7','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36','2026-03-31 12:17:04','2026-03-31 09:17:04'),(34,1,'8637bdfe0f57523e4f74213fe564c673cf5adcd4724c228df6e19c17365da02e','::1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920','2026-03-31 12:18:45','2026-03-31 09:18:45'),(35,1,'ebd5d2c30d5b49fa792cb383a14d54ea721731e4b9061fe51c630bc1f83763cc','::1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920','2026-03-31 12:20:01','2026-03-31 09:20:01'),(36,1,'c15e315f5e0b89e3bf8b4f5e8f7e751de3980e8888a7500d55959358e5437836','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36','2026-03-31 12:20:31','2026-03-31 09:20:31'),(37,1,'7498a0dfb7c1bd1277fafe063635cda09afd5d57dd0ecebc620fa6a9821e25c0','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36','2026-03-31 12:21:17','2026-03-31 09:21:17'),(38,1,'bd4ad436bea1e7e680f241f3ff2f412cb0a050f15aadc7898160e5717321656b','::1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920','2026-03-31 12:21:35','2026-03-31 09:21:35'),(39,1,'a198f4a27f67b45a93d2589cc18c70d249bc81edec4169c5ec1065a32d98ff07','::1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920','2026-03-31 12:23:57','2026-03-31 09:23:57'),(40,1,'c3b2649a8325734c85b03201ca55311ccd3432bfc5ff875c362a77460cb52dda','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36','2026-03-31 13:31:54','2026-03-31 10:29:25');
/*!40000 ALTER TABLE `admin_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_users`
--

DROP TABLE IF EXISTS `admin_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL,
  `password` varchar(255) NOT NULL,
  `fullname` varchar(128) DEFAULT '',
  `email` varchar(200) DEFAULT '',
  `phone` varchar(32) DEFAULT '',
  `role_id` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `user_type` enum('admin','reseller','employee','support','viewer') DEFAULT 'employee',
  `status` enum('active','inactive','suspended','locked') DEFAULT 'active',
  `avatar` varchar(255) DEFAULT '',
  `last_login` datetime DEFAULT NULL,
  `last_ip` varchar(45) DEFAULT '',
  `login_attempts` int(3) DEFAULT 0,
  `locked_until` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `role_id` (`role_id`),
  KEY `parent_id` (`parent_id`),
  KEY `user_type` (`user_type`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_users`
--

LOCK TABLES `admin_users` WRITE;
/*!40000 ALTER TABLE `admin_users` DISABLE KEYS */;
INSERT INTO `admin_users` VALUES (1,'admin','$2y$10$gEtsbUYHaqdalPLSgUyGe.K54HBZPqGSqAYJVjfQPvCtADNUv1gIu','System Administrator','admin@example.com','',1,NULL,'admin','active','','2026-03-31 10:29:25','::1',4,NULL,'2026-03-27 02:02:53','2026-04-19 06:43:14');
/*!40000 ALTER TABLE `admin_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `billing_history`
--

DROP TABLE IF EXISTS `billing_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `billing_history` (
  `id` bigint(21) NOT NULL AUTO_INCREMENT,
  `username` varchar(128) NOT NULL,
  `action` enum('invoice_generated','payment_received','reminder_sent','grace_period','suspended','reactivated','auto_renewed','plan_changed') NOT NULL,
  `invoice_number` varchar(64) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `details` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `username` (`username`),
  KEY `action` (`action`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billing_history`
--

LOCK TABLES `billing_history` WRITE;
/*!40000 ALTER TABLE `billing_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `billing_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `billing_plans`
--

DROP TABLE IF EXISTS `billing_plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `billing_plans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `planname` varchar(64) NOT NULL,
  `plandesc` varchar(256) DEFAULT NULL,
  `rate_limit` varchar(128) DEFAULT NULL,
  `burst_limit` varchar(128) DEFAULT NULL,
  `burst_threshold` varchar(128) DEFAULT NULL,
  `burst_time` varchar(128) DEFAULT NULL,
  `priority` int(11) DEFAULT 8,
  `traffic_limit` bigint(20) DEFAULT NULL,
  `time_limit` int(11) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT 0.00,
  `currency` varchar(3) DEFAULT 'USD',
  `active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `planname` (`planname`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billing_plans`
--

LOCK TABLES `billing_plans` WRITE;
/*!40000 ALTER TABLE `billing_plans` DISABLE KEYS */;
INSERT INTO `billing_plans` VALUES (1,'basic_1mbps','15Mbps','20M/20M','40M/40M','40M/40M','40/40',8,0,0,500.00,'BDT',1,'2026-03-27 02:02:40','2026-03-27 08:56:34'),(2,'standard_5mbps','Standard 5Mbps Plan','5M/10M','10M/20M','5M/10M','40/40',6,0,0,2500.00,'BDT',1,'2026-03-27 02:02:40','2026-03-27 06:49:22'),(3,'premium_10mbps','Premium 10Mbps Plan','10M/20M','20M/40M','10M/20M','40/40',4,0,0,500.00,'BDT',1,'2026-03-27 02:02:40','2026-03-27 06:49:05');
/*!40000 ALTER TABLE `billing_plans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `billing_schedule`
--

DROP TABLE IF EXISTS `billing_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `billing_schedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(128) NOT NULL,
  `planname` varchar(128) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `currency` varchar(3) DEFAULT 'BDT',
  `billing_cycle` enum('daily','weekly','monthly','quarterly','yearly','one-time') DEFAULT 'monthly',
  `billing_day` int(2) DEFAULT 1,
  `next_billing_date` date NOT NULL,
  `last_billed_date` date DEFAULT NULL,
  `grace_period_days` int(3) DEFAULT 3,
  `auto_suspend` tinyint(1) DEFAULT 1,
  `auto_generate_invoice` tinyint(1) DEFAULT 1,
  `send_sms_reminder` tinyint(1) DEFAULT 1,
  `reminder_days_before` int(3) DEFAULT 3,
  `status` enum('active','paused','cancelled') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `next_billing_date` (`next_billing_date`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billing_schedule`
--

LOCK TABLES `billing_schedule` WRITE;
/*!40000 ALTER TABLE `billing_schedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `billing_schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `billing_settings`
--

DROP TABLE IF EXISTS `billing_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `billing_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(128) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `description` varchar(512) DEFAULT '',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billing_settings`
--

LOCK TABLES `billing_settings` WRITE;
/*!40000 ALTER TABLE `billing_settings` DISABLE KEYS */;
INSERT INTO `billing_settings` VALUES (1,'auto_billing_enabled','0','Enable/disable automatic billing system','2026-03-27 02:03:32'),(2,'auto_suspend_enabled','1','Auto-suspend users who dont pay','2026-03-27 02:03:32'),(3,'auto_sms_enabled','0','Enable/disable SMS notifications','2026-03-27 02:03:32'),(4,'sms_provider','sslwireless','Active SMS provider','2026-03-27 02:03:32'),(5,'support_number','+8801XXXXXXXXX','Support phone number','2026-03-27 02:03:32'),(6,'company_name','ISP Billing','Company name for SMS','2026-03-27 02:03:32'),(7,'invoice_prefix','INV','Invoice number prefix','2026-03-27 02:03:32'),(8,'grace_period_days','3','Default grace period before suspension','2026-03-27 02:03:32'),(9,'reminder_days_before','3','Days before due date to send reminder','2026-03-27 02:03:32'),(10,'billing_cron_last_run','2026-03-31 10:15:49','Last auto-billing cron run time','2026-03-31 08:15:49');
/*!40000 ALTER TABLE `billing_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoices`
--

DROP TABLE IF EXISTS `invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_number` varchar(64) NOT NULL,
  `gateway_id` int(11) DEFAULT NULL,
  `username` varchar(128) NOT NULL,
  `planname` varchar(128) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `currency` varchar(3) DEFAULT 'BDT',
  `payment_method` varchar(32) DEFAULT '',
  `description` varchar(512) DEFAULT '',
  `status` enum('pending','processing','paid','failed','expired','cancelled','refunded') DEFAULT 'pending',
  `gateway_txn_id` varchar(256) DEFAULT '',
  `gateway_ref` varchar(256) DEFAULT '',
  `gateway_response` text DEFAULT NULL,
  `paid_at` datetime DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoice_number` (`invoice_number`),
  KEY `username` (`username`),
  KEY `status` (`status`),
  KEY `gateway_id` (`gateway_id`),
  CONSTRAINT `invoices_ibfk_1` FOREIGN KEY (`gateway_id`) REFERENCES `payment_gateways` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoices`
--

LOCK TABLES `invoices` WRITE;
/*!40000 ALTER TABLE `invoices` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mikrotik_devices`
--

DROP TABLE IF EXISTS `mikrotik_devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mikrotik_devices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `api_port` int(11) NOT NULL DEFAULT 8728,
  `api_user` varchar(64) NOT NULL DEFAULT 'admin',
  `api_pass` varchar(128) NOT NULL DEFAULT '',
  `description` varchar(255) DEFAULT '',
  `status` enum('online','offline','unknown') DEFAULT 'unknown',
  `is_default` tinyint(1) DEFAULT 0,
  `version` varchar(50) DEFAULT '',
  `board` varchar(100) DEFAULT '',
  `uptime` varchar(100) DEFAULT '',
  `last_sync` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_ip_port` (`ip_address`,`api_port`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mikrotik_devices`
--

LOCK TABLES `mikrotik_devices` WRITE;
/*!40000 ALTER TABLE `mikrotik_devices` DISABLE KEYS */;
INSERT INTO `mikrotik_devices` VALUES (1,'Main Router','192.168.1.1',8728,'admin','','Main office router','offline',1,'','','',NULL,'2026-03-27 11:23:43','2026-03-29 01:47:41');
/*!40000 ALTER TABLE `mikrotik_devices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nas`
--

DROP TABLE IF EXISTS `nas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nas` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `nasname` varchar(128) NOT NULL,
  `shortname` varchar(32) DEFAULT NULL,
  `type` varchar(30) DEFAULT 'other',
  `ports` int(5) DEFAULT NULL,
  `secret` varchar(60) NOT NULL DEFAULT 'secret',
  `server` varchar(64) DEFAULT NULL,
  `community` varchar(50) DEFAULT NULL,
  `description` varchar(200) DEFAULT 'RADIUS Client',
  `require_ma` varchar(4) DEFAULT 'auto',
  `limit_proxy_state` varchar(4) DEFAULT 'auto',
  PRIMARY KEY (`id`),
  KEY `nasname` (`nasname`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nas`
--

LOCK TABLES `nas` WRITE;
/*!40000 ALTER TABLE `nas` DISABLE KEYS */;
INSERT INTO `nas` VALUES (2,'180.149.232.33','KP-R2','Mikrotik',1812,'fcn1999','','','CCR-1009','auto','auto');
/*!40000 ALTER TABLE `nas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `olt_devices`
--

DROP TABLE IF EXISTS `olt_devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `olt_devices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `port` int(5) DEFAULT 23,
  `telnet_user` varchar(64) DEFAULT 'admin',
  `telnet_pass` varchar(128) DEFAULT '',
  `enable_pass` varchar(128) DEFAULT '',
  `vendor` varchar(64) DEFAULT 'generic',
  `model` varchar(128) DEFAULT '',
  `firmware` varchar(128) DEFAULT '',
  `connection_type` enum('telnet','ssh','snmp') DEFAULT 'telnet',
  `snmp_community` varchar(64) DEFAULT 'public',
  `snmp_version` int(1) DEFAULT 2,
  `snmp_port` int(5) DEFAULT 161,
  `slot_count` int(11) DEFAULT 16,
  `ports_per_slot` int(11) DEFAULT 4,
  `onus_per_port` int(11) DEFAULT 64,
  `status` enum('online','offline','unknown') DEFAULT 'unknown',
  `location` varchar(256) DEFAULT '',
  `description` varchar(512) DEFAULT '',
  `last_sync` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip_address` (`ip_address`),
  KEY `status` (`status`),
  KEY `vendor` (`vendor`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `olt_devices`
--

LOCK TABLES `olt_devices` WRITE;
/*!40000 ALTER TABLE `olt_devices` DISABLE KEYS */;
INSERT INTO `olt_devices` VALUES (1,'OLT-HeadOffice','192.168.1.10',23,'admin','admin','','huawei','MA5608T','','telnet','public',2,161,2,16,128,'offline','','Head Office Huawei OLT',NULL,'2026-03-27 02:03:19','2026-03-27 07:44:31'),(2,'OLT-Branch1','172.25.100.2',23,'admin','admin','','zte','ZXA10 C320','','telnet','public',2,161,2,16,64,'offline','','Branch 1 ZTE OLT',NULL,'2026-03-27 02:03:19','2026-03-27 09:00:06'),(3,'OLT-Branch2','192.168.1.30',23,'admin','admin','','fiberhome','AN5516-01','','telnet','public',2,161,4,16,128,'offline','','Branch 2 Fiberhome OLT',NULL,'2026-03-27 02:03:19','2026-03-27 07:44:41');
/*!40000 ALTER TABLE `olt_devices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `olt_pon_ports`
--

DROP TABLE IF EXISTS `olt_pon_ports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `olt_pon_ports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `olt_id` int(11) NOT NULL,
  `slot_number` int(11) NOT NULL,
  `port_number` int(11) NOT NULL,
  `port_name` varchar(64) DEFAULT '',
  `port_type` enum('EPON','GPON','XG-PON','XGS-PON') DEFAULT 'GPON',
  `status` enum('up','down','admin-down','unknown') DEFAULT 'unknown',
  `onu_count` int(11) DEFAULT 0,
  `rx_power` decimal(10,2) DEFAULT NULL,
  `tx_power` decimal(10,2) DEFAULT NULL,
  `description` varchar(256) DEFAULT '',
  `last_sync` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `olt_port` (`olt_id`,`slot_number`,`port_number`),
  KEY `olt_id` (`olt_id`),
  CONSTRAINT `olt_pon_ports_ibfk_1` FOREIGN KEY (`olt_id`) REFERENCES `olt_devices` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `olt_pon_ports`
--

LOCK TABLES `olt_pon_ports` WRITE;
/*!40000 ALTER TABLE `olt_pon_ports` DISABLE KEYS */;
/*!40000 ALTER TABLE `olt_pon_ports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `onu_alarms`
--

DROP TABLE IF EXISTS `onu_alarms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `onu_alarms` (
  `id` bigint(21) NOT NULL AUTO_INCREMENT,
  `olt_id` int(11) NOT NULL,
  `onu_id` int(11) DEFAULT NULL,
  `slot_number` int(11) DEFAULT NULL,
  `port_number` int(11) DEFAULT NULL,
  `onu_number` int(11) DEFAULT NULL,
  `alarm_type` varchar(64) NOT NULL,
  `severity` enum('critical','major','minor','warning','info') DEFAULT 'info',
  `message` text DEFAULT NULL,
  `cleared` tinyint(1) DEFAULT 0,
  `cleared_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `olt_id` (`olt_id`),
  KEY `severity` (`severity`),
  KEY `created_at` (`created_at`),
  CONSTRAINT `onu_alarms_ibfk_1` FOREIGN KEY (`olt_id`) REFERENCES `olt_devices` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `onu_alarms`
--

LOCK TABLES `onu_alarms` WRITE;
/*!40000 ALTER TABLE `onu_alarms` DISABLE KEYS */;
/*!40000 ALTER TABLE `onu_alarms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `onu_devices`
--

DROP TABLE IF EXISTS `onu_devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `onu_devices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `olt_id` int(11) NOT NULL,
  `pon_port_id` int(11) DEFAULT NULL,
  `slot_number` int(11) NOT NULL,
  `port_number` int(11) NOT NULL,
  `onu_number` int(11) NOT NULL,
  `onu_id` varchar(64) DEFAULT '',
  `serial_number` varchar(128) DEFAULT '',
  `mac_address` varchar(32) DEFAULT '',
  `name` varchar(128) DEFAULT '',
  `status` enum('online','offline','dying-gasp','unknown') DEFAULT 'unknown',
  `auth_status` enum('authorized','unauthorized','pending') DEFAULT 'pending',
  `distance` decimal(10,2) DEFAULT NULL,
  `uptime` int(12) DEFAULT 0,
  `last_down_time` datetime DEFAULT NULL,
  `last_down_reason` varchar(256) DEFAULT '',
  `rx_power` decimal(10,2) DEFAULT NULL,
  `tx_power` decimal(10,2) DEFAULT NULL,
  `olt_rx_power` decimal(10,2) DEFAULT NULL,
  `temperature` decimal(10,2) DEFAULT NULL,
  `voltage` decimal(10,2) DEFAULT NULL,
  `firmware` varchar(128) DEFAULT '',
  `equipment_id` varchar(256) DEFAULT '',
  `profile_name` varchar(128) DEFAULT '',
  `vlan_id` int(11) DEFAULT NULL,
  `bandwidth_up` varchar(64) DEFAULT '',
  `bandwidth_down` varchar(64) DEFAULT '',
  `description` varchar(256) DEFAULT '',
  `last_sync` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `olt_onu` (`olt_id`,`slot_number`,`port_number`,`onu_number`),
  KEY `olt_id` (`olt_id`),
  KEY `serial_number` (`serial_number`),
  KEY `mac_address` (`mac_address`),
  KEY `status` (`status`),
  CONSTRAINT `onu_devices_ibfk_1` FOREIGN KEY (`olt_id`) REFERENCES `olt_devices` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `onu_devices`
--

LOCK TABLES `onu_devices` WRITE;
/*!40000 ALTER TABLE `onu_devices` DISABLE KEYS */;
/*!40000 ALTER TABLE `onu_devices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `onu_eth_ports`
--

DROP TABLE IF EXISTS `onu_eth_ports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `onu_eth_ports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `onu_id` int(11) NOT NULL,
  `port_number` int(11) NOT NULL,
  `port_name` varchar(64) DEFAULT '',
  `status` enum('up','down','unknown') DEFAULT 'unknown',
  `speed` varchar(32) DEFAULT '',
  `duplex` varchar(16) DEFAULT '',
  `vlan_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `onu_id` (`onu_id`),
  CONSTRAINT `onu_eth_ports_ibfk_1` FOREIGN KEY (`onu_id`) REFERENCES `onu_devices` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `onu_eth_ports`
--

LOCK TABLES `onu_eth_ports` WRITE;
/*!40000 ALTER TABLE `onu_eth_ports` DISABLE KEYS */;
/*!40000 ALTER TABLE `onu_eth_ports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_gateways`
--

DROP TABLE IF EXISTS `payment_gateways`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_gateways` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `slug` varchar(64) NOT NULL,
  `gateway_url` varchar(512) NOT NULL,
  `api_key` varchar(256) DEFAULT '',
  `api_secret` varchar(256) DEFAULT '',
  `callback_url` varchar(512) DEFAULT '',
  `method` enum('bkash','nagad','rocket','bank','card','all') DEFAULT 'all',
  `currency` varchar(3) DEFAULT 'BDT',
  `auto_activate` tinyint(1) DEFAULT 0,
  `min_amount` decimal(10,2) DEFAULT 10.00,
  `max_amount` decimal(10,2) DEFAULT 50000.00,
  `status` enum('active','inactive','test') DEFAULT 'test',
  `description` varchar(512) DEFAULT '',
  `config_json` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_gateways`
--

LOCK TABLES `payment_gateways` WRITE;
/*!40000 ALTER TABLE `payment_gateways` DISABLE KEYS */;
INSERT INTO `payment_gateways` VALUES (1,'PiPraPay bKash','piprapay-bkash','https://billing.fcnchbd.xyz/bkash/ngod/getway','','','','bkash','BDT',0,10.00,50000.00,'active','PiPraPay bKash/Nagad Gateway',NULL,'2026-03-27 02:03:08','2026-03-27 02:03:08');
/*!40000 ALTER TABLE `payment_gateways` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_transactions`
--

DROP TABLE IF EXISTS `payment_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_transactions` (
  `id` bigint(21) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) DEFAULT NULL,
  `gateway_id` int(11) DEFAULT NULL,
  `username` varchar(128) NOT NULL,
  `txn_type` enum('payment','refund','reversal') DEFAULT 'payment',
  `amount` decimal(10,2) NOT NULL,
  `currency` varchar(3) DEFAULT 'BDT',
  `payment_method` varchar(32) DEFAULT '',
  `gateway_txn_id` varchar(256) DEFAULT '',
  `gateway_ref` varchar(256) DEFAULT '',
  `status` enum('success','failed','pending','cancelled') DEFAULT 'pending',
  `request_data` text DEFAULT NULL,
  `response_data` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT '',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `invoice_id` (`invoice_id`),
  KEY `username` (`username`),
  KEY `status` (`status`),
  KEY `created_at` (`created_at`),
  CONSTRAINT `payment_transactions_ibfk_1` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_transactions`
--

LOCK TABLES `payment_transactions` WRITE;
/*!40000 ALTER TABLE `payment_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radacct`
--

DROP TABLE IF EXISTS `radacct`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `radacct` (
  `radacctid` bigint(21) NOT NULL AUTO_INCREMENT,
  `acctsessionid` varchar(64) NOT NULL DEFAULT '',
  `acctuniqueid` varchar(32) NOT NULL DEFAULT '',
  `username` varchar(64) NOT NULL DEFAULT '',
  `groupname` varchar(64) NOT NULL DEFAULT '',
  `realm` varchar(64) DEFAULT '',
  `nasipaddress` varchar(15) NOT NULL DEFAULT '',
  `nasportid` varchar(32) DEFAULT NULL,
  `nasporttype` varchar(32) DEFAULT NULL,
  `acctstarttime` datetime DEFAULT NULL,
  `acctupdatetime` datetime DEFAULT NULL,
  `acctstoptime` datetime DEFAULT NULL,
  `acctinterval` int(12) DEFAULT NULL,
  `acctsessiontime` int(12) unsigned DEFAULT NULL,
  `acctauthentic` varchar(32) DEFAULT NULL,
  `connectinfo_start` varchar(50) DEFAULT NULL,
  `connectinfo_stop` varchar(50) DEFAULT NULL,
  `acctinputoctets` bigint(20) DEFAULT NULL,
  `acctoutputoctets` bigint(20) DEFAULT NULL,
  `calledstationid` varchar(50) NOT NULL DEFAULT '',
  `callingstationid` varchar(50) NOT NULL DEFAULT '',
  `acctterminatecause` varchar(32) NOT NULL DEFAULT '',
  `servicetype` varchar(32) DEFAULT NULL,
  `framedprotocol` varchar(32) DEFAULT NULL,
  `framedipaddress` varchar(15) NOT NULL DEFAULT '',
  `framedipv6address` varchar(45) NOT NULL DEFAULT '',
  `framedipv6prefix` varchar(45) NOT NULL DEFAULT '',
  `framedinterfaceid` varchar(44) NOT NULL DEFAULT '',
  `delegatedipv6prefix` varchar(45) NOT NULL DEFAULT '',
  `class` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`radacctid`),
  UNIQUE KEY `acctuniqueid` (`acctuniqueid`),
  KEY `username` (`username`),
  KEY `framedipaddress` (`framedipaddress`),
  KEY `acctstoptime` (`acctstoptime`),
  KEY `nasipaddress` (`nasipaddress`),
  KEY `bulk_close` (`acctstoptime`,`nasipaddress`,`acctstarttime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radacct`
--

LOCK TABLES `radacct` WRITE;
/*!40000 ALTER TABLE `radacct` DISABLE KEYS */;
/*!40000 ALTER TABLE `radacct` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radcheck`
--

DROP TABLE IF EXISTS `radcheck`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `radcheck` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL DEFAULT '',
  `attribute` varchar(64) NOT NULL DEFAULT '',
  `op` char(2) NOT NULL DEFAULT '==',
  `value` varchar(253) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `username` (`username`(32))
) ENGINE=InnoDB AUTO_INCREMENT=806 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radcheck`
--

LOCK TABLES `radcheck` WRITE;
/*!40000 ALTER TABLE `radcheck` DISABLE KEYS */;
INSERT INTO `radcheck` VALUES (1,'user1','Cleartext-Password',':=','pass123'),(2,'user2','Cleartext-Password',':=','pass456'),(3,'user3','Cleartext-Password',':=','pass789'),(5,'admin','Cleartext-Password',':=','ab123'),(6,'ppp1','Cleartext-Password',':=','fcn@1999'),(7,'testuser','Cleartext-Password',':=','test123'),(8,'fcnpc','Cleartext-Password',':=','ab1234'),(9,'test','Cleartext-Password',':=','ab1234'),(10,'test1','Cleartext-Password',':=','test1234'),(11,'rcn','Cleartext-Password',':=','rcn1234'),(12,'576613','Cleartext-Password',':=','ab1234'),(13,'Bserajul@dtati','Cleartext-Password',':=','123456'),(14,'Bsihabnody','Cleartext-Password',':=','sihab1234#'),(15,'taj@eid','Cleartext-Password',':=','123456'),(16,'Kmanikb','Cleartext-Password',':=','manik1234#'),(18,'abdul@hatpara','Cleartext-Password',':=','123456'),(19,'ahad@dnody','Cleartext-Password',':=','123456'),(20,'anowar@dnody','Cleartext-Password',':=','123456'),(21,'arif@dtati','Cleartext-Password',':=','123456'),(22,'atik@dnody','Cleartext-Password',':=','123456'),(23,'badrul@tati','Cleartext-Password',':=','123456'),(24,'bisonat@dnody','Cleartext-Password',':=','123456'),(25,'durul@b','Cleartext-Password',':=','123456'),(26,'faruk@felu','Cleartext-Password',':=','123456'),(27,'habibur@dnody','Cleartext-Password',':=','123456'),(28,'hafizur@dtati','Cleartext-Password',':=','123456'),(29,'hakim@dnody','Cleartext-Password',':=','123456'),(30,'halim@dnody','Cleartext-Password',':=','123456'),(31,'hameem@ds','Cleartext-Password',':=','123456'),(32,'hasibul@felu','Cleartext-Password',':=','123456'),(33,'kader@hata','Cleartext-Password',':=','123456'),(34,'kawser@badsa','Cleartext-Password',':=','123456'),(35,'khairulnody','Cleartext-Password',':=','khairul1234#'),(37,'milon@dnody','Cleartext-Password',':=','123456'),(38,'mohammad@dta','Cleartext-Password',':=','123456'),(39,'mojibur@badsa','Cleartext-Password',':=','123456'),(40,'mostofab','Cleartext-Password',':=','mostofa1234#'),(41,'nashir@badsa','Cleartext-Password',':=','123456'),(42,'omor@felu','Cleartext-Password',':=','123456'),(43,'pobon@dnody','Cleartext-Password',':=','123456'),(44,'sadiqul@dnody','Cleartext-Password',':=','123456'),(45,'shaide@bh','Cleartext-Password',':=','123456'),(46,'shamim@bnody','Cleartext-Password',':=','123456'),(47,'shohidul@dnody','Cleartext-Password',':=','123456'),(48,'taosiqe@ed','Cleartext-Password',':=','123456'),(50,'tohorul@mohajon','Cleartext-Password',':=','123456'),(51,'mohammad@dtati','Cleartext-Password',':=','123456'),(52,'tanvir@bhat','Cleartext-Password',':=','123456'),(53,'591250','Cleartext-Password',':=','ab1234'),(54,'Kmonirul','Cleartext-Password',':=','ab1234'),(55,'abdullah@hata','Cleartext-Password',':=','123456'),(56,'ahad@bd','Cleartext-Password',':=','123456'),(57,'akbor@bd','Cleartext-Password',':=','123456'),(58,'akher@bd','Cleartext-Password',':=','123456'),(59,'akhtarulb','Cleartext-Password',':=','akhtarul1234#'),(60,'alim@bd','Cleartext-Password',':=','123456'),(61,'aminul@hata','Cleartext-Password',':=','123456'),(62,'chomotkersir','Cleartext-Password',':=','chomotker1234#'),(63,'emdadul@bk','Cleartext-Password',':=','123456'),(64,'faruk@bd','Cleartext-Password',':=','123456'),(65,'kamal@bd','Cleartext-Password',':=','123456'),(66,'masum@bk','Cleartext-Password',':=','123456'),(67,'monoranjan@bk','Cleartext-Password',':=','123456'),(68,'morshalin@bk','Cleartext-Password',':=','123456'),(69,'nojrul@bk','Cleartext-Password',':=','123456'),(70,'rabiwl@bd','Cleartext-Password',':=','123456'),(71,'samad@bdro','Cleartext-Password',':=','123456'),(72,'shahin@bd','Cleartext-Password',':=','123456'),(73,'shakilb','Cleartext-Password',':=','shakil1234#'),(75,'sorifulkub','Cleartext-Password',':=','soriful1234#'),(76,'sifat@ed','Cleartext-Password',':=','123456'),(77,'bayezid@tati','Cleartext-Password',':=','123456'),(78,'Rubel@eid','Cleartext-Password',':=','123456'),(79,'zillur@tati','Cleartext-Password',':=','123456'),(80,'atawr','Cleartext-Password',':=','atawr1234#'),(81,'ibrahim@rod','Cleartext-Password',':=','123456'),(82,'mosidul@hata','Cleartext-Password',':=','123456'),(83,'yakub','Cleartext-Password',':=','12345678#'),(84,'mainulgro','Cleartext-Password',':=','mainul1234#'),(85,'rubel@spur','Cleartext-Password',':=','123456'),(86,'rakib','Cleartext-Password',':=','rakib1234#'),(87,'samiul@rod','Cleartext-Password',':=','123456'),(88,'sumonnim','Cleartext-Password',':=','sumon1234#'),(89,'Lmoyejmia','Cleartext-Password',':=','moyej1234#'),(91,'mizan2','Cleartext-Password',':=','123456'),(92,'Lbaidulraja','Cleartext-Password',':=','baidul1234#'),(93,'Lnayondur','Cleartext-Password',':=','nayon1234#'),(94,'Lsorifulpw','Cleartext-Password',':=','soriful1234#'),(95,'Lesarulraja','Cleartext-Password',':=','esarul1234#'),(96,'Lmasudraja','Cleartext-Password',':=','masud1234#'),(97,'saifulub','Cleartext-Password',':=','saiful1234#'),(98,'Bripongro','Cleartext-Password',':=','ripon1234#'),(99,'Lricpw','Cleartext-Password',':=','ric1234#'),(100,'ahsan','Cleartext-Password',':=','123456'),(101,'Bshohidulgro','Cleartext-Password',':=','shohidul1234#'),(102,'mijan','Cleartext-Password',':=','12345678#'),(103,'sojib@mia','Cleartext-Password',':=','123456'),(104,'Lmokseduldurga','Cleartext-Password',':=','moksedul1234#'),(105,'Krahat','Cleartext-Password',':=','ab1234'),(106,'yazdani','Cleartext-Password',':=','12345678#'),(107,'shahabuldur','Cleartext-Password',':=','shahabul1234#'),(108,'moyez@cho','Cleartext-Password',':=','123456'),(109,'jamal@rtati','Cleartext-Password',':=','123456'),(110,'shihan1','Cleartext-Password',':=','shihan1234#'),(111,'tohidul@deow','Cleartext-Password',':=','123456'),(112,'kader@ub','Cleartext-Password',':=','123456'),(113,'selimraj','Cleartext-Password',':=','selim1234#'),(114,'masum@raja','Cleartext-Password',':=','123456'),(115,'Lmofijulpw','Cleartext-Password',':=','mofijul1234#'),(116,'motalleb@chow','Cleartext-Password',':=','123456'),(117,'mtb mill','Cleartext-Password',':=','12345678#'),(118,'romjanmohal','Cleartext-Password',':=','romjan1234#'),(119,'alifbod','Cleartext-Password',':=','alif1234#'),(120,'Lshifat@dur','Cleartext-Password',':=','123456'),(121,'mukter@mohal','Cleartext-Password',':=','123456'),(122,'korim@durga','Cleartext-Password',':=','123456'),(123,'hamid@deow','Cleartext-Password',':=','123456'),(124,'Lhojrot@markaj','Cleartext-Password',':=','123456'),(125,'mamun@bod','Cleartext-Password',':=','123456'),(126,'Sabdulnim','Cleartext-Password',':=','abdul1234#'),(127,'Ksahalalub','Cleartext-Password',':=','sahalal1234#'),(128,'Bgaji@bod','Cleartext-Password',':=','123456'),(129,'Lkhabirmia','Cleartext-Password',':=','khabir1234#'),(130,'foisal@chm','Cleartext-Password',':=','123456'),(131,'Lshahindurga','Cleartext-Password',':=','shahin1234#'),(132,'Bmerajsir','Cleartext-Password',':=','meraj1234#'),(134,'Ljoshimpw','Cleartext-Password',':=','joshim1234#'),(135,'josim','Cleartext-Password',':=','123456'),(136,'rajuub','Cleartext-Password',':=','raju1234#'),(137,'Saesagopi','Cleartext-Password',':=','aesa1234#'),(138,'Sbahadurmia','Cleartext-Password',':=','bahadur1234#'),(139,'Ssahalaldeow','Cleartext-Password',':=','sahalal1234#'),(140,'sagor@ghon','Cleartext-Password',':=','123456'),(141,'Lasrafulraja','Cleartext-Password',':=','asraful1234#'),(142,'dr.naimul','Cleartext-Password',':=','naimul1234#'),(143,'Srinabod','Cleartext-Password',':=','rina1234#'),(144,'Skurbanmia','Cleartext-Password',':=','kurban1234#'),(145,'aminul@mohal','Cleartext-Password',':=','123456'),(146,'Shihab','Cleartext-Password',':=','ab1234'),(147,'Lpintu','Cleartext-Password',':=','ab1234'),(148,'Bsajid@mohal','Cleartext-Password',':=','123456'),(149,'Bjibon@dhab','Cleartext-Password',':=','123456'),(150,'582908','Cleartext-Password',':=','ab1234'),(151,'torikul@deo','Cleartext-Password',':=','123456'),(152,'shohel@dur','Cleartext-Password',':=','123456'),(153,'kamrul@deow','Cleartext-Password',':=','123456'),(155,'ppptest','Cleartext-Password',':=','ppp1234#'),(156,'577342','Cleartext-Password',':=','ab1234'),(157,'haider@chow','Cleartext-Password',':=','123456'),(158,'581754','Cleartext-Password',':=','ab1234'),(159,'aktarul@rod','Cleartext-Password',':=','123456'),(160,'sajahan@dur','Cleartext-Password',':=','123456'),(161,'Bjohorul@chow','Cleartext-Password',':=','123456'),(162,'fcntest18','Cleartext-Password',':=','123456'),(163,'nazim','Cleartext-Password',':=','123456'),(165,'moyej@chow','Cleartext-Password',':=','123456'),(166,'Bhalim@chow','Cleartext-Password',':=','123456'),(167,'afjal@chow','Cleartext-Password',':=','123456'),(168,'kawser@chow','Cleartext-Password',':=','123456'),(170,'rasel@cho','Cleartext-Password',':=','123456'),(171,'samsu@chow','Cleartext-Password',':=','123456'),(172,'asraful@cho','Cleartext-Password',':=','123456'),(173,'pritom@hpur','Cleartext-Password',':=','123456'),(174,'kanon@chow','Cleartext-Password',':=','123456'),(175,'faruk@chow','Cleartext-Password',':=','123456'),(176,'manik@mohal','Cleartext-Password',':=','123456'),(177,'593522','Cleartext-Password',':=','ab1234'),(178,'595573','Cleartext-Password',':=','ab1234'),(179,'573749','Cleartext-Password',':=','ab1234'),(180,'Latawr@rod','Cleartext-Password',':=','123456'),(182,'rakhi','Cleartext-Password',':=','123456'),(183,'Bmotaleb@moha','Cleartext-Password',':=','123456'),(184,'arif@rod','Cleartext-Password',':=','123456'),(185,'osman@raj','Cleartext-Password',':=','123456'),(186,'Lromjan@jhondi','Cleartext-Password',':=','123456'),(187,'arifmarkaj','Cleartext-Password',':=','arif1234#'),(188,'sojol@deow','Cleartext-Password',':=','123456'),(189,'sijan@mia','Cleartext-Password',':=','123456'),(190,'shiper@mohal','Cleartext-Password',':=','123456'),(191,'Lalim@ntola','Cleartext-Password',':=','123456'),(193,'Lsojib@durga','Cleartext-Password',':=','123456'),(194,'sadiqul','Cleartext-Password',':=','sadiqul1234#'),(195,'nayem@bod','Cleartext-Password',':=','123456'),(196,'Lrobbani@kraja','Cleartext-Password',':=','123456'),(197,'yousuf@deow','Cleartext-Password',':=','123456'),(198,'Lpolas@kraja','Cleartext-Password',':=','123456'),(199,'Bmadrasa@chow','Cleartext-Password',':=','123456'),(200,'mijan@raja','Cleartext-Password',':=','123456'),(201,'harun@nim','Cleartext-Password',':=','123456'),(202,'shohidul@dgoni','Cleartext-Password',':=','123456'),(203,'amijul@deow','Cleartext-Password',':=','123456'),(204,'Lpintu@mia','Cleartext-Password',':=','123456'),(205,'babu@horma','Cleartext-Password',':=','123456'),(206,'mosarof@haji','Cleartext-Password',':=','123456'),(207,'Bjuel@sahu','Cleartext-Password',':=','123456'),(208,'Lsaidur@rtati','Cleartext-Password',':=','123456'),(209,'raju@gro','Cleartext-Password',':=','123456'),(210,'Bbulu@chow','Cleartext-Password',':=','123456'),(211,'Lmadrasa@durga','Cleartext-Password',':=','123456'),(212,'Bdon@chow','Cleartext-Password',':=','123456'),(213,'ismail@deow','Cleartext-Password',':=','123456'),(214,'robbani@chow','Cleartext-Password',':=','123456'),(215,'Brohman@chow','Cleartext-Password',':=','123456'),(217,'Kmoklesur@hata','Cleartext-Password',':=','123456'),(218,'sojib@nim','Cleartext-Password',':=','123456'),(219,'Baziz@chow','Cleartext-Password',':=','123456'),(220,'595737','Cleartext-Password',':=','ab1234'),(221,'Bmasud@mohal','Cleartext-Password',':=','123456'),(222,'Lasgar@mia','Cleartext-Password',':=','123456'),(223,'bablu@chow','Cleartext-Password',':=','123456'),(224,'mahatab@gro','Cleartext-Password',':=','123456'),(225,'bakar@mohajon','Cleartext-Password',':=','123456'),(226,'babu@bod','Cleartext-Password',':=','123456'),(227,'sisir@nim','Cleartext-Password',':=','123456'),(228,'azaz@chow','Cleartext-Password',':=','123456'),(229,'khaleda@ntola','Cleartext-Password',':=','123456'),(230,'Manik@raja','Cleartext-Password',':=','123456'),(231,'habib@durga','Cleartext-Password',':=','123456'),(232,'bulbul@mia','Cleartext-Password',':=','123456'),(233,'sohidul@deow','Cleartext-Password',':=','123456'),(234,'bablu@raj','Cleartext-Password',':=','123456'),(235,'khairul@mohal','Cleartext-Password',':=','123456'),(236,'amir@rtati','Cleartext-Password',':=','123456'),(238,'arif@deow','Cleartext-Password',':=','123456'),(239,'akramul@jhondi','Cleartext-Password',':=','123456'),(240,'mahafuj@mia','Cleartext-Password',':=','123456'),(241,'sahid@bod','Cleartext-Password',':=','123456'),(242,'592364','Cleartext-Password',':=','ab1234'),(243,'kamu@chow','Cleartext-Password',':=','123456'),(244,'sofikul@markaj','Cleartext-Password',':=','123456'),(245,'rejawl@babu','Cleartext-Password',':=','123456'),(246,'based@rtati','Cleartext-Password',':=','123456'),(247,'akkash@raja','Cleartext-Password',':=','123456'),(248,'joshim@chow','Cleartext-Password',':=','123456'),(249,'usman@jhundi','Cleartext-Password',':=','123456'),(251,'oskuruni@chai','Cleartext-Password',':=','123456'),(252,'naimul@jhond','Cleartext-Password',':=','123456'),(254,'ashik@mohal','Cleartext-Password',':=','123456'),(255,'ruhul@shib','Cleartext-Password',':=','123456'),(256,'taher@bissas','Cleartext-Password',':=','123456'),(257,'lipon@bod','Cleartext-Password',':=','123456'),(258,'jubaer@raja','Cleartext-Password',':=','123456'),(260,'590910','Cleartext-Password',':=','ab1234'),(261,'728108','Cleartext-Password',':=','ab1234'),(262,'lutfor@hata','Cleartext-Password',':=','123456'),(263,'rubel@jhondi','Cleartext-Password',':=','123456'),(264,'kalam@durga','Cleartext-Password',':=','123456'),(265,'sowkot@chow','Cleartext-Password',':=','123456'),(266,'monirul@chow','Cleartext-Password',':=','123456'),(267,'lalu@chow','Cleartext-Password',':=','123456'),(268,'udps@chm','Cleartext-Password',':=','123456'),(269,'mannan@raj','Cleartext-Password',':=','123456'),(270,'masud@rod','Cleartext-Password',':=','123456'),(271,'kamrul@raja','Cleartext-Password',':=','123456'),(272,'596764','Cleartext-Password',':=','ab1234'),(273,'rofikul@ub','Cleartext-Password',':=','123456'),(274,'afjal@kraja','Cleartext-Password',':=','123456'),(275,'sujon@gro','Cleartext-Password',':=','123456'),(276,'Bleakotchow','Cleartext-Password',':=','leakot1234#'),(277,'esarul@deow','Cleartext-Password',':=','123456'),(278,'sayed@chow','Cleartext-Password',':=','123456'),(279,'parvej@deow','Cleartext-Password',':=','123456'),(280,'rohman@hata','Cleartext-Password',':=','123456'),(281,'kader@rod','Cleartext-Password',':=','123456'),(282,'fahim@kraja','Cleartext-Password',':=','123456'),(284,'586537','Cleartext-Password',':=','ab1234'),(285,'tosikul@chow','Cleartext-Password',':=','123456'),(286,'korim@ub','Cleartext-Password',':=','123456'),(287,'islami@bank','Cleartext-Password',':=','123456'),(288,'mojibur@mohal','Cleartext-Password',':=','123456'),(289,'jahaggir@deow','Cleartext-Password',':=','123456'),(290,'shahid@jhondy','Cleartext-Password',':=','123456'),(291,'dulal@mia','Cleartext-Password',':=','123456'),(292,'Lmalek@raj','Cleartext-Password',':=','123456'),(293,'emon@ntola','Cleartext-Password',':=','123456'),(295,'shahin@deo','Cleartext-Password',':=','123456'),(296,'Bkholil@chow','Cleartext-Password',':=','123456'),(297,'rasel@raj','Cleartext-Password',':=','123456'),(298,'ajmir@raja','Cleartext-Password',':=','123456'),(299,'ali@raj','Cleartext-Password',':=','123456'),(300,'ibrahim@chow','Cleartext-Password',':=','123456'),(301,'ronjit@bod','Cleartext-Password',':=','123456'),(302,'590400','Cleartext-Password',':=','ab1234'),(303,'shohidul@chai','Cleartext-Password',':=','123456'),(304,'babu@durga','Cleartext-Password',':=','123456'),(305,'mosfik@chow','Cleartext-Password',':=','123456'),(306,'manik@chow','Cleartext-Password',':=','123456'),(307,'fcn@office','Cleartext-Password',':=','12345'),(309,'morsalin@raj','Cleartext-Password',':=','123456'),(310,'kajol@ntola','Cleartext-Password',':=','123456'),(312,'potab@horma','Cleartext-Password',':=','123456'),(313,'mamun@durga','Cleartext-Password',':=','123456'),(314,'hasen@nim','Cleartext-Password',':=','123456'),(315,'tuhin@chow','Cleartext-Password',':=','123456'),(316,'school@hp','Cleartext-Password',':=','123456'),(317,'golaf@chow','Cleartext-Password',':=','123456'),(318,'munirul@deow','Cleartext-Password',':=','123456'),(319,'sajid@deow','Cleartext-Password',':=','123456'),(320,'amirul@deow','Cleartext-Password',':=','123456'),(321,'jia@chow','Cleartext-Password',':=','123456'),(322,'shohel@bod','Cleartext-Password',':=','123456'),(323,'moinul@markaj','Cleartext-Password',':=','123456'),(324,'582364','Cleartext-Password',':=','ab1234'),(325,'shohidul@chow','Cleartext-Password',':=','123456'),(326,'dulal@chow','Cleartext-Password',':=','123456'),(329,'osman@nim','Cleartext-Password',':=','123456'),(330,'ibrahim@ful','Cleartext-Password',':=','123456'),(331,'rasel@chow','Cleartext-Password',':=','123456'),(332,'sumon@chai','Cleartext-Password',':=','123456'),(333,'juwel@ub','Cleartext-Password',':=','123456'),(335,'sahalal@rod','Cleartext-Password',':=','123456'),(336,'mamun@raja','Cleartext-Password',':=','123456'),(337,'sofi@babu','Cleartext-Password',':=','123456'),(338,'567430','Cleartext-Password',':=','hp123'),(339,'Mannan@rtati','Cleartext-Password',':=','123456'),(340,'omar@chow','Cleartext-Password',':=','123456'),(341,'habibur@deow','Cleartext-Password',':=','123456'),(342,'khairul@deow','Cleartext-Password',':=','123456'),(343,'mannan@horma','Cleartext-Password',':=','123456'),(345,'571026','Cleartext-Password',':=','hp123'),(346,'kollol@nim','Cleartext-Password',':=','123456'),(347,'johorul@chow','Cleartext-Password',':=','123456'),(348,'shahariar@chm','Cleartext-Password',':=','123456'),(349,'sadikul@chow','Cleartext-Password',':=','123456'),(350,'nur@horma','Cleartext-Password',':=','123456'),(351,'rahad@dpur','Cleartext-Password',':=','123456'),(352,'mostofa@moha','Cleartext-Password',':=','123456'),(353,'munjur@chow','Cleartext-Password',':=','123456'),(354,'rojibul@ntola','Cleartext-Password',':=','123456'),(355,'jubaer@raj','Cleartext-Password',':=','123456'),(356,'rasidul@siddik','Cleartext-Password',':=','123456'),(357,'santo@dur','Cleartext-Password',':=','123456'),(358,'kurban@chur','Cleartext-Password',':=','123456'),(359,'shohidul@deo','Cleartext-Password',':=','123456'),(360,'imam@mia','Cleartext-Password',':=','123456'),(361,'580673','Cleartext-Password',':=','ab1234'),(362,'mukul@raja','Cleartext-Password',':=','123456'),(363,'hakim@kraja','Cleartext-Password',':=','123456'),(364,'tomal@babu','Cleartext-Password',':=','123456'),(365,'rojob@horma','Cleartext-Password',':=','123456'),(366,'awal@kraja','Cleartext-Password',':=','123456'),(367,'ismail@horma','Cleartext-Password',':=','123456'),(368,'azom@mia','Cleartext-Password',':=','123456'),(370,'masum@raj','Cleartext-Password',':=','123456'),(371,'sofiqul@deow','Cleartext-Password',':=','123456'),(372,'obaida@dibdi','Cleartext-Password',':=','123456'),(373,'korim@bod','Cleartext-Password',':=','123456'),(374,'amin@nim','Cleartext-Password',':=','123456'),(376,'momin@dur','Cleartext-Password',':=','123456'),(377,'hojrot@bod','Cleartext-Password',':=','123456'),(378,'sahanaj@bisas','Cleartext-Password',':=','123456'),(379,'talha@markaj','Cleartext-Password',':=','123456'),(380,'jahaggir@gro','Cleartext-Password',':=','123456'),(381,'johorul@dhab','Cleartext-Password',':=','123456'),(382,'ohed@saha','Cleartext-Password',':=','123456'),(383,'asif@deow','Cleartext-Password',':=','123456'),(384,'yousuf@markaj','Cleartext-Password',':=','123456'),(385,'torikul@raj','Cleartext-Password',':=','123456'),(386,'sohidul@bod','Cleartext-Password',':=','123456'),(387,'murtuja@raja','Cleartext-Password',':=','123456'),(388,'hoda@chow','Cleartext-Password',':=','123456'),(389,'dawad@dhab','Cleartext-Password',':=','123456'),(390,'hasan@chow','Cleartext-Password',':=','123456'),(391,'596453','Cleartext-Password',':=','ab1234'),(392,'jamal@mia','Cleartext-Password',':=','123456'),(393,'rasidul@rod','Cleartext-Password',':=','123456'),(394,'samad@gro','Cleartext-Password',':=','123456'),(395,'mijanur@hata','Cleartext-Password',':=','123456'),(396,'samol@ful','Cleartext-Password',':=','123456'),(397,'kajol@deow','Cleartext-Password',':=','123456'),(398,'kasem@nim','Cleartext-Password',':=','123456'),(400,'alornir@bod','Cleartext-Password',':=','123456'),(401,'kiron@gaggina','Cleartext-Password',':=','123456'),(402,'shohidul@ub','Cleartext-Password',':=','123456'),(403,'lotifur@deow','Cleartext-Password',':=','123456'),(404,'awal@chow','Cleartext-Password',':=','123456'),(405,'bakkar@sahu','Cleartext-Password',':=','123456'),(406,'902235','Cleartext-Password',':=','ab1234'),(407,'masud@kraja','Cleartext-Password',':=','123456'),(408,'shoriful@ntola','Cleartext-Password',':=','123456'),(409,'olye@po','Cleartext-Password',':=','123456'),(411,'ismail@mia','Cleartext-Password',':=','123456'),(412,'amijul@ds','Cleartext-Password',':=','123456'),(413,'redoy@goppi','Cleartext-Password',':=','123456'),(414,'mofazzul@cho','Cleartext-Password',':=','123456'),(415,'dulal@full','Cleartext-Password',':=','123456'),(416,'basir@ds','Cleartext-Password',':=','123456'),(417,'sarwor@db','Cleartext-Password',':=','123456'),(418,'shohel@raja','Cleartext-Password',':=','123456'),(419,'esarul@ntola','Cleartext-Password',':=','123456'),(420,'samad@rod','Cleartext-Password',':=','123456'),(421,'sahalom@cho','Cleartext-Password',':=','123456'),(422,'sadiqul@raja','Cleartext-Password',':=','123456'),(423,'hasib@sahu','Cleartext-Password',':=','123456'),(424,'575125','Cleartext-Password',':=','ab1234'),(425,'raju@siddik','Cleartext-Password',':=','123456'),(426,'kasem@full','Cleartext-Password',':=','123456'),(427,'shohel@jhondi','Cleartext-Password',':=','123456'),(428,'shihab@chai','Cleartext-Password',':=','123456'),(429,'ujjol@gaggina','Cleartext-Password',':=','123456'),(430,'kamal@raja','Cleartext-Password',':=','123456'),(432,'esarul@d','Cleartext-Password',':=','123456'),(433,'fahad@chow','Cleartext-Password',':=','123456'),(434,'emon@office','Cleartext-Password',':=','123456'),(435,'rauf@deow','Cleartext-Password',':=','123456'),(436,'roshid@mia','Cleartext-Password',':=','123456'),(437,'mosarof@mia','Cleartext-Password',':=','123456'),(438,'amin@chow','Cleartext-Password',':=','123456'),(439,'622412','Cleartext-Password',':=','ab1234'),(440,'babu@chow','Cleartext-Password',':=','123456'),(441,'595571','Cleartext-Password',':=','ab1234'),(442,'581259','Cleartext-Password',':=','ab1234'),(443,'poros@chai','Cleartext-Password',':=','123456'),(444,'barek@raja','Cleartext-Password',':=','123456'),(445,'rony@mia','Cleartext-Password',':=','123456'),(446,'rohim@mia','Cleartext-Password',':=','123456'),(447,'samad@gaggina','Cleartext-Password',':=','123456'),(448,'nashirul@chai','Cleartext-Password',':=','123456'),(449,'faruk@raj','Cleartext-Password',':=','123456'),(450,'Nantu','Cleartext-Password',':=','123456'),(451,'rakib@chow','Cleartext-Password',':=','123456'),(452,'alim@ub','Cleartext-Password',':=','123456'),(454,'robiul@office','Cleartext-Password',':=','123456'),(455,'590063','Cleartext-Password',':=','ab1234'),(456,'sojib@rod','Cleartext-Password',':=','123456'),(457,'tosikul@bod','Cleartext-Password',':=','123456'),(458,'basudeb@mohal','Cleartext-Password',':=','123456'),(459,'nasir@raj','Cleartext-Password',':=','123456'),(460,'mannan@chai','Cleartext-Password',':=','123456'),(462,'rojob@sahu','Cleartext-Password',':=','123456'),(464,'566888','Cleartext-Password',':=','hp123'),(465,'noyon@rtati','Cleartext-Password',':=','123456'),(466,'621663','Cleartext-Password',':=','ab1234'),(467,'595786','Cleartext-Password',':=','ab1234'),(468,'torikul@rod','Cleartext-Password',':=','123456'),(470,'rakib@gro','Cleartext-Password',':=','123456'),(471,'tanvir@chow','Cleartext-Password',':=','123456'),(472,'faruki@rkumar','Cleartext-Password',':=','123456'),(473,'rejaul@office','Cleartext-Password',':=','123456'),(474,'jubayer@nim','Cleartext-Password',':=','123456'),(475,'rasel@rkumar','Cleartext-Password',':=','123456'),(476,'selim@mia','Cleartext-Password',':=','123456'),(477,'raful@rod','Cleartext-Password',':=','123456'),(478,'mitun@ful','Cleartext-Password',':=','123456'),(479,'anamul@deow','Cleartext-Password',':=','123456'),(480,'arun@ful','Cleartext-Password',':=','123456'),(481,'nur@deo','Cleartext-Password',':=','123456'),(482,'shakil@markaj','Cleartext-Password',':=','123456'),(483,'rmdc','Cleartext-Password',':=','rmdc123'),(484,'kawser@rsiddik','Cleartext-Password',':=','123456'),(485,'parvej@pw','Cleartext-Password',':=','123456'),(486,'masud@deow','Cleartext-Password',':=','123456'),(487,'nahar@ntola','Cleartext-Password',':=','123456'),(488,'mukter@bod','Cleartext-Password',':=','123456'),(489,'basir@chai','Cleartext-Password',':=','123456'),(490,'957789','Cleartext-Password',':=','ab1234'),(491,'971711','Cleartext-Password',':=','ab1234'),(492,'726624','Cleartext-Password',':=','ab1234'),(493,'595724','Cleartext-Password',':=','ab1234'),(494,'manik@rtati','Cleartext-Password',':=','123456'),(495,'lima@dur','Cleartext-Password',':=','123456'),(496,'Smainulsapara','Cleartext-Password',':=','mainul1234#'),(497,'durul@dmohajon','Cleartext-Password',':=','123456'),(498,'bakkar@chow','Cleartext-Password',':=','123456'),(499,'rony@chow','Cleartext-Password',':=','123456'),(501,'joy@goppi','Cleartext-Password',':=','123456'),(502,'rahul@horma','Cleartext-Password',':=','123456'),(503,'robiul@mia','Cleartext-Password',':=','123456'),(504,'sajahan@mohal','Cleartext-Password',':=','123456'),(505,'578634','Cleartext-Password',':=','ab1234'),(506,'ahad@dur','Cleartext-Password',':=','123456'),(507,'tarek@chai','Cleartext-Password',':=','123456'),(508,'hira@bod','Cleartext-Password',':=','123456'),(509,'rofiqul@bissas','Cleartext-Password',':=','123456'),(510,'ohab@durga','Cleartext-Password',':=','123456'),(511,'aminul@bod','Cleartext-Password',':=','123456'),(512,'nadim@bod','Cleartext-Password',':=','123456'),(513,'nahid@sahu','Cleartext-Password',':=','123456'),(514,'shoriful@raja','Cleartext-Password',':=','123456'),(515,'aminul@sahu','Cleartext-Password',':=','123456'),(516,'faruk@chkhb','Cleartext-Password',':=','123456'),(517,'mahim@office','Cleartext-Password',':=','123456'),(518,'akramul@rod','Cleartext-Password',':=','123456'),(520,'romjan@deo','Cleartext-Password',':=','123456'),(521,'hredoy@horma','Cleartext-Password',':=','123456'),(522,'shaiful@ub','Cleartext-Password',':=','123456'),(523,'robiwl@goppi','Cleartext-Password',':=','123456'),(524,'jamal@sahu','Cleartext-Password',':=','123456'),(525,'rejawl@chow','Cleartext-Password',':=','123456'),(526,'mursalin@chow','Cleartext-Password',':=','123456'),(527,'kobir@chow','Cleartext-Password',':=','123456'),(528,'tuhin@office','Cleartext-Password',':=','123456'),(529,'hasan@ub','Cleartext-Password',':=','123456'),(530,'lutfur@office','Cleartext-Password',':=','123456'),(531,'isarul@bod','Cleartext-Password',':=','123456'),(532,'firoz@chow','Cleartext-Password',':=','123456'),(533,'bari@chow','Cleartext-Password',':=','123456'),(534,'akbor@chow','Cleartext-Password',':=','123456'),(535,'Abbas@hata','Cleartext-Password',':=','123456'),(536,'shahjahan@mia','Cleartext-Password',':=','123456'),(537,'tohidul@dur','Cleartext-Password',':=','123456'),(538,'azizur@gro','Cleartext-Password',':=','123456'),(539,'badsa@sahu','Cleartext-Password',':=','123456'),(540,'eakub@chow','Cleartext-Password',':=','123456'),(541,'686175','Cleartext-Password',':=','ab1234'),(542,'selim@raj','Cleartext-Password',':=','123456'),(543,'hisam@raja','Cleartext-Password',':=','123456'),(544,'shihab@raja','Cleartext-Password',':=','123456'),(545,'mehidy@chm','Cleartext-Password',':=','123456'),(546,'aowal@deo','Cleartext-Password',':=','123456'),(548,'umar@ub','Cleartext-Password',':=','123456'),(549,'ibblatm','Cleartext-Password',':=','atm1234'),(550,'khalek@gro','Cleartext-Password',':=','123456'),(551,'723271','Cleartext-Password',':=','ab1234'),(552,'sohidul@chow','Cleartext-Password',':=','123456'),(553,'samad@sahu','Cleartext-Password',':=','123456'),(554,'muni@chow','Cleartext-Password',':=','123456'),(555,'nojrul@chow','Cleartext-Password',':=','123456'),(556,'raja@horma','Cleartext-Password',':=','123456'),(557,'altab@mohal','Cleartext-Password',':=','123456'),(559,'wakidi@jondy','Cleartext-Password',':=','123456'),(560,'sayed@ful','Cleartext-Password',':=','123456'),(562,'milon@chow','Cleartext-Password',':=','123456'),(563,'azom@cho','Cleartext-Password',':=','123456'),(564,'hakim@goppi','Cleartext-Password',':=','123456'),(565,'rajib@chow','Cleartext-Password',':=','123456'),(566,'rubel@ntola','Cleartext-Password',':=','123456'),(567,'rohim@chkhb','Cleartext-Password',':=','123456'),(568,'yousuf@ful','Cleartext-Password',':=','123456'),(569,'selim@chow','Cleartext-Password',':=','123456'),(570,'rohman@rod','Cleartext-Password',':=','123456'),(571,'kamal@gro','Cleartext-Password',':=','123456'),(572,'hojrot@jhondy','Cleartext-Password',':=','123456'),(573,'alomgir@mia','Cleartext-Password',':=','123456'),(574,'asraful@gro','Cleartext-Password',':=','123456'),(575,'jubaer@cho','Cleartext-Password',':=','123456'),(576,'yousuf@chow','Cleartext-Password',':=','123456'),(577,'sanaullah@nim','Cleartext-Password',':=','123456'),(578,'minhaj@rsiddik','Cleartext-Password',':=','123456'),(579,'jahaggir@gaggina','Cleartext-Password',':=','123456'),(580,'574579','Cleartext-Password',':=','ab1234'),(581,'shohidul@hata','Cleartext-Password',':=','123456'),(582,'664011','Cleartext-Password',':=','ab1234'),(583,'protick@bod','Cleartext-Password',':=','123456'),(584,'golap@durga','Cleartext-Password',':=','123456'),(585,'nahid@nim','Cleartext-Password',':=','123456'),(586,'rifat@gaggina','Cleartext-Password',':=','123456'),(587,'Lselim','Cleartext-Password',':=','ab1234'),(588,'nirob@jhondy','Cleartext-Password',':=','123456'),(590,'tamim@full','Cleartext-Password',':=','123456'),(591,'badsa@babu','Cleartext-Password',':=','123456'),(592,'ripon@jhondy','Cleartext-Password',':=','123456'),(593,'mostakim@deow','Cleartext-Password',':=','123456'),(594,'595654','Cleartext-Password',':=','ab1234'),(595,'erfan@nim','Cleartext-Password',':=','123456'),(596,'sayem@bod','Cleartext-Password',':=','123456'),(597,'Lhashanmia','Cleartext-Password',':=','hashan1234#'),(598,'shohidul@cho','Cleartext-Password',':=','123456'),(599,'hosen@sahu','Cleartext-Password',':=','123456'),(600,'bappy@saha','Cleartext-Password',':=','123456'),(601,'amin@deow','Cleartext-Password',':=','123456'),(602,'579005','Cleartext-Password',':=','ab1234'),(603,'618540','Cleartext-Password',':=','ab1234'),(604,'589815','Cleartext-Password',':=','ab1234'),(605,'971576','Cleartext-Password',':=','ab1234'),(606,'roshid@nim','Cleartext-Password',':=','123456'),(607,'mukter@ub','Cleartext-Password',':=','123456'),(608,'nadim@pum','Cleartext-Password',':=','123456'),(609,'baijid@horma','Cleartext-Password',':=','123456'),(610,'pollob@babu','Cleartext-Password',':=','123456'),(611,'manik@raj','Cleartext-Password',':=','123456'),(612,'jobed@brig','Cleartext-Password',':=','123456'),(613,'rohmot@jhondy','Cleartext-Password',':=','123456'),(614,'meherul@cho','Cleartext-Password',':=','123456'),(615,'hakim@hata','Cleartext-Password',':=','123456'),(616,'bojlu@full','Cleartext-Password',':=','123456'),(617,'samsul@nim','Cleartext-Password',':=','123456'),(618,'salam@ub','Cleartext-Password',':=','123456'),(620,'nayon@mohal','Cleartext-Password',':=','123456'),(621,'piarul@ful','Cleartext-Password',':=','123456'),(623,'raihan@chai','Cleartext-Password',':=','123456'),(624,'shahria@jhondy','Cleartext-Password',':=','123456'),(625,'jwel@chow','Cleartext-Password',':=','123456'),(626,'ataur@ntola','Cleartext-Password',':=','123456'),(627,'Sahin@nim','Cleartext-Password',':=','123456'),(628,'rajob@hatapara','Cleartext-Password',':=','123456'),(629,'khairul@durga','Cleartext-Password',':=','123456'),(630,'shohidul@deow','Cleartext-Password',':=','123456'),(631,'limon@bod','Cleartext-Password',':=','123456'),(632,'imran@saha','Cleartext-Password',':=','123456'),(633,'razeen@babu','Cleartext-Password',':=','123456'),(634,'sahin@deow','Cleartext-Password',':=','123456'),(635,'badol@mia','Cleartext-Password',':=','123456'),(636,'Sahin@mia','Cleartext-Password',':=','123456'),(637,'595736','Cleartext-Password',':=','ab1234'),(638,'sagor@deow','Cleartext-Password',':=','123456'),(639,'595740','Cleartext-Password',':=','ab1234'),(640,'1033881','Cleartext-Password',':=','ab1234'),(641,'rahmatkps','Cleartext-Password',':=','ab1234'),(642,'durulhoda@bhat','Cleartext-Password',':=','123456'),(643,'kamal@churki','Cleartext-Password',':=','123456'),(644,'Ssalammia','Cleartext-Password',':=','salam1234#'),(645,'khokon@deow','Cleartext-Password',':=','123456'),(646,'kousik@eid','Cleartext-Password',':=','123456'),(647,'kader@tati','Cleartext-Password',':=','123456'),(648,'ekramul@eid','Cleartext-Password',':=','123456'),(649,'oliullah@nim','Cleartext-Password',':=','123456'),(650,'1013777','Cleartext-Password',':=','ab1234'),(651,'wahed@nodi','Cleartext-Password',':=','123456'),(652,'rubel','Cleartext-Password',':=','rubel1234#'),(653,'rokonchaipara','Cleartext-Password',':=','rokon1234#'),(654,'abulkalam@nodi','Cleartext-Password',':=','123456'),(655,'kader@raj','Cleartext-Password',':=','123456'),(657,'577626','Cleartext-Password',':=','ab1234'),(658,'626545','Cleartext-Password',':=','ab1234'),(659,'Muazzin@raj','Cleartext-Password',':=','123456'),(660,'583983','Cleartext-Password',':=','ab1234'),(661,'hameem','Cleartext-Password',':=','12345678#'),(662,'Kkaderub','Cleartext-Password',':=','kader1234#'),(663,'Btaj@ed','Cleartext-Password',':=','123456'),(664,'593525','Cleartext-Password',':=','ab1234'),(665,'668749','Cleartext-Password',':=','ab1234'),(666,'584388','Cleartext-Password',':=','ab1234'),(667,'581266','Cleartext-Password',':=','ab1234'),(668,'769424','Cleartext-Password',':=','ab1234'),(669,'562584','Cleartext-Password',':=','ab1234'),(670,'584671','Cleartext-Password',':=','ab1234'),(671,'591933','Cleartext-Password',':=','ab1234'),(672,'ansar@chai','Cleartext-Password',':=','123456'),(673,'tajimul@saha','Cleartext-Password',':=','123456'),(674,'sofikul@bagan','Cleartext-Password',':=','123456'),(675,'rubel2@tati','Cleartext-Password',':=','123456'),(676,'mosharof@dhab','Cleartext-Password',':=','123456'),(677,'awal@full','Cleartext-Password',':=','123456'),(678,'saif@bd','Cleartext-Password',':=','123456'),(679,'kadar@markaj','Cleartext-Password',':=','123456'),(680,'sattar@nim','Cleartext-Password',':=','123456'),(682,'nurul@chur','Cleartext-Password',':=','123456'),(683,'niamat@dtati','Cleartext-Password',':=','123456'),(684,'rojob@deow','Cleartext-Password',':=','123456'),(685,'julmat@bd','Cleartext-Password',':=','123456'),(686,'salauddin@full','Cleartext-Password',':=','123456'),(687,'farzana@tati','Cleartext-Password',':=','123456'),(688,'salim@tati','Cleartext-Password',':=','123456'),(689,'durulhoda@hata','Cleartext-Password',':=','123456'),(690,'akramul@dhab','Cleartext-Password',':=','123456'),(691,'mohamed@ful','Cleartext-Password',':=','123456'),(692,'foysal@raj','Cleartext-Password',':=','123456'),(693,'mukter@nim','Cleartext-Password',':=','123456'),(694,'mukt@hdeow','Cleartext-Password',':=','123456'),(695,'ponkoj@babu','Cleartext-Password',':=','123456'),(696,'amit@babu','Cleartext-Password',':=','123456'),(697,'sisir@raj','Cleartext-Password',':=','123456'),(698,'suvan@chow','Cleartext-Password',':=','123456'),(699,'jakariya@mohal','Cleartext-Password',':=','123456'),(700,'ppptest20','Cleartext-Password',':=','123456'),(701,'sorif@babu','Cleartext-Password',':=','123456'),(702,'yousof@hchow','Cleartext-Password',':=','123456'),(703,'jalal@chow','Cleartext-Password',':=','123456'),(704,'golap@chow','Cleartext-Password',':=','123456'),(705,'saifuddin@horma','Cleartext-Password',':=','123456'),(706,'nasirul@chow','Cleartext-Password',':=','123456'),(707,'naimul@chow','Cleartext-Password',':=','123456'),(708,'sofikul@sahu','Cleartext-Password',':=','123456'),(709,'baijid@kchow','Cleartext-Password',':=','123456'),(710,'asraful@mohal','Cleartext-Password',':=','123456'),(711,'mostofa@phouse','Cleartext-Password',':=','123456'),(712,'ansujulars@raj','Cleartext-Password',':=','123456'),(713,'sojib@hata','Cleartext-Password',':=','123456'),(714,'sarower@deow','Cleartext-Password',':=','123456'),(715,'hozrot@dd','Cleartext-Password',':=','123456'),(716,'rana@chai','Cleartext-Password',':=','123456'),(717,'raihan@chai2','Cleartext-Password',':=','123456'),(718,'rokon@chai','Cleartext-Password',':=','123456'),(719,'jahid@chai','Cleartext-Password',':=','123456'),(720,'ppp2','Cleartext-Password',':=','ab1234'),(721,'tusar@chai','Cleartext-Password',':=','123456'),(722,'sumon@mohal','Cleartext-Password',':=','123456'),(723,'Kmonirul@dnody','Cleartext-Password',':=','1234'),(724,'mahim@dnody','Cleartext-Password',':=','12345'),(725,'tohidul@nodi','Cleartext-Password',':=','123456'),(727,'shohed@hata','Cleartext-Password',':=','123456'),(729,'sumonraja','Cleartext-Password',':=','sumon1234#'),(731,'Brofikd','Cleartext-Password',':=','rofik'),(733,'Babdullah','Cleartext-Password',':=','ab1'),(735,'Lmostofa@jhondi','Cleartext-Password',':=','12345'),(737,'masud@chow','Cleartext-Password',':=','123456'),(739,'malek@rod','Cleartext-Password',':=','1234'),(741,'Bmatiur','Cleartext-Password',':=','ab1234'),(743,'furkan@saha','Cleartext-Password',':=','1234'),(746,'yousuf@dhab','Cleartext-Password',':=','123456'),(747,'rakib@deo','Cleartext-Password',':=','123456'),(749,'bakkar@raja','Cleartext-Password',':=','123456'),(751,'arif@raja','Cleartext-Password',':=','1234'),(753,'torikul@babu','Cleartext-Password',':=','1234'),(755,'shahid@deow','Cleartext-Password',':=','123456'),(757,'nur@durga','Cleartext-Password',':=','1234'),(759,'goni@durga','Cleartext-Password',':=','1234'),(761,'shohel@chow','Cleartext-Password',':=','123456'),(763,'mostafizur@raj','Cleartext-Password',':=','1234'),(766,'munirul@raj','Cleartext-Password',':=','1234'),(768,'tonmoy@bod','Cleartext-Password',':=','1234'),(770,'ruhul@brig','Cleartext-Password',':=','1234'),(772,'mojibur@bod','Cleartext-Password',':=','123456'),(774,'forhad@rtati','Cleartext-Password',':=','123456'),(776,'sariul@dur','Cleartext-Password',':=','1234'),(778,'nur@deow','Cleartext-Password',':=','1234'),(780,'hridoy@full','Cleartext-Password',':=','12345'),(782,'khadiza@dur','Cleartext-Password',':=','123456'),(784,'sohag@mohal','Cleartext-Password',':=','123456'),(786,'shohidpdb','Cleartext-Password',':=','123456'),(788,'sujon@pw','Cleartext-Password',':=','123456'),(790,'Mahabub@chow','Cleartext-Password',':=','1234'),(792,'khairul@deo','Cleartext-Password',':=','123456'),(794,'bari@deo','Cleartext-Password',':=','123456'),(796,'rifat@chow','Cleartext-Password',':=','1234'),(798,'rocky@chow','Cleartext-Password',':=','1234'),(800,'bakkar@markaj','Cleartext-Password',':=','123456'),(802,'anser@pw','Cleartext-Password',':=','123456'),(804,'tuhin@raj','Cleartext-Password',':=','123456'),(805,'babu2@bod','Cleartext-Password',':=','123456');
/*!40000 ALTER TABLE `radcheck` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radgroupcheck`
--

DROP TABLE IF EXISTS `radgroupcheck`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `radgroupcheck` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `groupname` varchar(64) NOT NULL DEFAULT '',
  `attribute` varchar(64) NOT NULL DEFAULT '',
  `op` char(2) NOT NULL DEFAULT '==',
  `value` varchar(253) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `groupname` (`groupname`(32))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radgroupcheck`
--

LOCK TABLES `radgroupcheck` WRITE;
/*!40000 ALTER TABLE `radgroupcheck` DISABLE KEYS */;
/*!40000 ALTER TABLE `radgroupcheck` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radgroupreply`
--

DROP TABLE IF EXISTS `radgroupreply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `radgroupreply` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `groupname` varchar(64) NOT NULL DEFAULT '',
  `attribute` varchar(64) NOT NULL DEFAULT '',
  `op` char(2) NOT NULL DEFAULT '=',
  `value` varchar(253) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `groupname` (`groupname`(32))
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radgroupreply`
--

LOCK TABLES `radgroupreply` WRITE;
/*!40000 ALTER TABLE `radgroupreply` DISABLE KEYS */;
INSERT INTO `radgroupreply` VALUES (3,'standard_5mbps','Mikrotik-Rate-Limit','=','5M/10M 10M/20M 5M/10M 40/40'),(4,'standard_5mbps','Acct-Interim-Interval','=','300'),(5,'premium_10mbps','Mikrotik-Rate-Limit','=','10M/20M 20M/40M 10M/20M 40/40'),(6,'premium_10mbps','Acct-Interim-Interval','=','300'),(7,'HOME','Mikrotik-Rate-Limit','=','1M/2M 2M/4M 1M/2M 40/40'),(8,'HOME','Acct-Interim-Interval','=','500');
/*!40000 ALTER TABLE `radgroupreply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radius_alerts`
--

DROP TABLE IF EXISTS `radius_alerts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `radius_alerts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `alert_type` varchar(100) NOT NULL,
  `severity` enum('critical','warning','info') NOT NULL DEFAULT 'info',
  `message` text NOT NULL,
  `context` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`context`)),
  `resolved_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_alert_type` (`alert_type`),
  KEY `idx_severity` (`severity`),
  KEY `idx_resolved_at` (`resolved_at`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='RADIUS system alerts and notifications';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radius_alerts`
--

LOCK TABLES `radius_alerts` WRITE;
/*!40000 ALTER TABLE `radius_alerts` DISABLE KEYS */;
/*!40000 ALTER TABLE `radius_alerts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radius_audit_logs`
--

DROP TABLE IF EXISTS `radius_audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `radius_audit_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `admin_user` varchar(100) NOT NULL,
  `action` varchar(100) NOT NULL,
  `target_username` varchar(64) DEFAULT NULL,
  `details` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`details`)),
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_admin_user` (`admin_user`),
  KEY `idx_target_username` (`target_username`),
  KEY `idx_action` (`action`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Audit trail for admin actions on RADIUS users';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radius_audit_logs`
--

LOCK TABLES `radius_audit_logs` WRITE;
/*!40000 ALTER TABLE `radius_audit_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `radius_audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radius_sessions`
--

DROP TABLE IF EXISTS `radius_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `radius_sessions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL,
  `nas_ip` varchar(45) NOT NULL,
  `nas_port` varchar(32) DEFAULT NULL,
  `session_id` varchar(64) NOT NULL COMMENT 'acct_session_id from NAS',
  `framed_ip` varchar(45) DEFAULT NULL,
  `start_time` datetime NOT NULL,
  `stop_time` datetime DEFAULT NULL,
  `bytes_in` bigint(20) unsigned NOT NULL DEFAULT 0,
  `bytes_out` bigint(20) unsigned NOT NULL DEFAULT 0,
  `terminate_cause` varchar(64) DEFAULT NULL,
  `status` enum('active','stopped') NOT NULL DEFAULT 'active',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_session_id` (`session_id`),
  KEY `idx_username` (`username`),
  KEY `idx_nas_ip` (`nas_ip`),
  KEY `idx_status` (`status`),
  KEY `idx_start_time` (`start_time`),
  KEY `idx_framed_ip` (`framed_ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='RADIUS session tracking';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radius_sessions`
--

LOCK TABLES `radius_sessions` WRITE;
/*!40000 ALTER TABLE `radius_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `radius_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radius_usage_daily`
--

DROP TABLE IF EXISTS `radius_usage_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `radius_usage_daily` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL,
  `date` date NOT NULL,
  `bytes_in` bigint(20) unsigned NOT NULL DEFAULT 0,
  `bytes_out` bigint(20) unsigned NOT NULL DEFAULT 0,
  `session_count` smallint(5) unsigned NOT NULL DEFAULT 0,
  `total_duration_seconds` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_username_date` (`username`,`date`),
  KEY `idx_username` (`username`),
  KEY `idx_date` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Daily usage rollup for billing and reporting';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radius_usage_daily`
--

LOCK TABLES `radius_usage_daily` WRITE;
/*!40000 ALTER TABLE `radius_usage_daily` DISABLE KEYS */;
/*!40000 ALTER TABLE `radius_usage_daily` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radius_user_profiles`
--

DROP TABLE IF EXISTS `radius_user_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `radius_user_profiles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` varchar(64) NOT NULL COMMENT 'FK to radcheck.username',
  `mac_address` varchar(20) DEFAULT NULL COMMENT 'Bound MAC address for filtering',
  `ip_binding` varchar(45) DEFAULT NULL COMMENT 'Static IP binding for this user',
  `concurrent_session_limit` tinyint(3) unsigned NOT NULL DEFAULT 1,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_user_id` (`user_id`),
  KEY `idx_mac_address` (`mac_address`),
  KEY `idx_ip_binding` (`ip_binding`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Extended RADIUS user profiles';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radius_user_profiles`
--

LOCK TABLES `radius_user_profiles` WRITE;
/*!40000 ALTER TABLE `radius_user_profiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `radius_user_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radpostauth`
--

DROP TABLE IF EXISTS `radpostauth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `radpostauth` (
  `id` bigint(21) NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL DEFAULT '',
  `pass` varchar(64) NOT NULL DEFAULT '',
  `reply` varchar(32) NOT NULL DEFAULT '',
  `authdate` timestamp(6) NOT NULL DEFAULT current_timestamp(6),
  `class` varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radpostauth`
--

LOCK TABLES `radpostauth` WRITE;
/*!40000 ALTER TABLE `radpostauth` DISABLE KEYS */;
/*!40000 ALTER TABLE `radpostauth` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radreply`
--

DROP TABLE IF EXISTS `radreply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `radreply` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL DEFAULT '',
  `attribute` varchar(64) NOT NULL DEFAULT '',
  `op` char(2) NOT NULL DEFAULT '=',
  `value` varchar(253) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `username` (`username`(32))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radreply`
--

LOCK TABLES `radreply` WRITE;
/*!40000 ALTER TABLE `radreply` DISABLE KEYS */;
/*!40000 ALTER TABLE `radreply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radusergroup`
--

DROP TABLE IF EXISTS `radusergroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `radusergroup` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL DEFAULT '',
  `groupname` varchar(64) NOT NULL DEFAULT '',
  `priority` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `username` (`username`(32))
) ENGINE=InnoDB AUTO_INCREMENT=722 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radusergroup`
--

LOCK TABLES `radusergroup` WRITE;
/*!40000 ALTER TABLE `radusergroup` DISABLE KEYS */;
INSERT INTO `radusergroup` VALUES (1,'user1','HOME',1),(2,'user2','standard_5mbps',1),(3,'user3','premium_10mbps',1),(5,'admin','Fiber 50 Mbps',1),(8,'testuser','default',1),(9,'rcn','FCN-PKG-600TK',1),(10,'576613','FCN-PKG-500TK',1),(11,'Bserajul@dtati','FCN-PKG-500TK',1),(12,'Bsihabnody','FCN-PKG-500TK',1),(13,'taj@eid','FCN-PKG-500TK',1),(14,'Kmanikb','FCN-PKG-500TK',1),(15,'Kmonirul@dnody','Expired',1),(16,'abdul@hatpara','FCN-PKG-500TK',1),(17,'ahad@dnody','FCN-PKG-500TK',1),(18,'anowar@dnody','FCN-PKG-500TK',1),(19,'arif@dtati','FCN-PKG-500TK',1),(20,'atik@dnody','FCN-PKG-500TK',1),(21,'badrul@tati','FCN-PKG-500TK',1),(22,'bisonat@dnody','FCN-PKG-500TK',1),(23,'durul@b','FCN-PKG-500TK',1),(24,'faruk@felu','FCN-PKG-500TK',1),(25,'habibur@dnody','FCN-PKG-500TK',1),(26,'hafizur@dtati','FCN-PKG-500TK',1),(27,'hakim@dnody','FCN-PKG-500TK',1),(28,'halim@dnody','FCN-PKG-500TK',1),(29,'hameem@ds','FCN-PKG-500TK',1),(30,'hasibul@felu','FCN-PKG-500TK',1),(31,'kader@hata','FCN-PKG-500TK',1),(32,'kawser@badsa','FCN-PKG-500TK',1),(33,'khairulnody','FCN-PKG-500TK',1),(34,'mahim@dnody','Expired',1),(35,'milon@dnody','FCN-PKG-500TK',1),(36,'mohammad@dta','FCN-PKG-500TK',1),(37,'mojibur@badsa','FCN-PKG-500TK',1),(38,'mostofab','FCN-PKG-500TK',1),(39,'nashir@badsa','FCN-PKG-500TK',1),(40,'omor@felu','FCN-PKG-500TK',1),(41,'pobon@dnody','FCN-PKG-500TK',1),(42,'sadiqul@dnody','FCN-PKG-500TK',1),(43,'shaide@bh','FCN-PKG-500TK',1),(44,'shamim@bnody','FCN-PKG-500TK',1),(45,'shohidul@dnody','FCN-PKG-500TK',1),(46,'taosiqe@ed','FCN-PKG-500TK',1),(47,'tohidul@nodi','Expired',1),(48,'tohorul@mohajon','FCN-PKG-500TK',1),(49,'mohammad@dtati','FCN-PKG-500TK',1),(50,'tanvir@bhat','FCN-PKG-500TK',1),(51,'591250','FCN-PKG-500TK',1),(52,'Kmonirul','FCN-PKG-500TK',1),(53,'abdullah@hata','FCN-PKG-500TK',1),(54,'ahad@bd','FCN-PKG-500TK',1),(55,'akbor@bd','FCN-PKG-500TK',1),(56,'akher@bd','FCN-PKG-500TK',1),(57,'akhtarulb','FCN-PKG-500TK',1),(58,'alim@bd','FCN-PKG-500TK',1),(59,'aminul@hata','FCN-PKG-500TK',1),(60,'chomotkersir','FCN-PKG-500TK',1),(61,'emdadul@bk','FCN-PKG-500TK',1),(62,'faruk@bd','FCN-PKG-500TK',1),(63,'kamal@bd','FCN-PKG-500TK',1),(64,'masum@bk','FCN-PKG-500TK',1),(65,'monoranjan@bk','FCN-PKG-500TK',1),(66,'morshalin@bk','FCN-PKG-500TK',1),(67,'nojrul@bk','FCN-PKG-500TK',1),(68,'rabiwl@bd','FCN-PKG-500TK',1),(69,'samad@bdro','FCN-PKG-500TK',1),(70,'shahin@bd','FCN-PKG-500TK',1),(71,'shakilb','FCN-PKG-500TK',1),(72,'shohed@hata','Expired',1),(73,'sorifulkub','FCN-PKG-500TK',1),(74,'sifat@ed','FCN-PKG-500TK',1),(75,'bayezid@tati','FCN-PKG-500TK',1),(76,'Rubel@eid','FCN-PKG-500TK',1),(77,'zillur@tati','FCN-PKG-500TK',1),(78,'atawr','FCN-PKG-500TK',1),(79,'ibrahim@rod','FCN-PKG-500TK',1),(80,'mosidul@hata','FCN-PKG-500TK',1),(81,'yakub','FCN-PKG-500TK',1),(82,'mainulgro','FCN-PKG-500TK',1),(83,'rubel@spur','FCN-PKG-500TK',1),(84,'rakib','FCN-PKG-500TK',1),(85,'samiul@rod','FCN-PKG-500TK',1),(86,'sumonnim','FCN-PKG-500TK',1),(87,'Lmoyejmia','FCN-PKG-500TK',1),(88,'sumonraja','Expired',1),(89,'mizan2','FCN-PKG-500TK',1),(90,'Lbaidulraja','FCN-PKG-500TK',1),(91,'Lnayondur','FCN-PKG-500TK',1),(92,'Lsorifulpw','FCN-PKG-500TK',1),(93,'Lesarulraja','FCN-PKG-500TK',1),(94,'Lmasudraja','FCN-PKG-500TK',1),(95,'saifulub','FCN-PKG-500TK',1),(96,'Bripongro','FCN-PKG-500TK',1),(97,'Lricpw','FCN-PKG-500TK',1),(98,'ahsan','FCN-PKG-500TK',1),(99,'Bshohidulgro','FCN-PKG-500TK',1),(100,'mijan','FCN-PKG-500TK',1),(101,'sojib@mia','FCN-PKG-500TK',1),(102,'Lmokseduldurga','FCN-PKG-500TK',1),(103,'Krahat','FCN-PKG-500TK',1),(104,'yazdani','FCN-PKG-500TK',1),(105,'shahabuldur','FCN-PKG-500TK',1),(106,'moyez@cho','FCN-PKG-500TK',1),(107,'jamal@rtati','FCN-PKG-500TK',1),(108,'shihan1','FCN-PKG-500TK',1),(109,'tohidul@deow','FCN-PKG-500TK',1),(110,'kader@ub','FCN-PKG-500TK',1),(111,'selimraj','FCN-PKG-500TK',1),(112,'masum@raja','FCN-PKG-500TK',1),(113,'Lmofijulpw','FCN-PKG-500TK',1),(114,'motalleb@chow','FCN-PKG-500TK',1),(115,'mtb mill','FCN-PKG-500TK',1),(116,'romjanmohal','FCN-PKG-500TK',1),(117,'alifbod','FCN-PKG-500TK',1),(118,'Lshifat@dur','FCN-PKG-500TK',1),(119,'mukter@mohal','FCN-PKG-500TK',1),(120,'korim@durga','FCN-PKG-500TK',1),(121,'hamid@deow','FCN-PKG-500TK',1),(122,'Lhojrot@markaj','FCN-PKG-500TK',1),(123,'mamun@bod','FCN-PKG-500TK',1),(124,'Sabdulnim','FCN-PKG-500TK',1),(125,'Ksahalalub','FCN-PKG-500TK',1),(126,'Bgaji@bod','FCN-PKG-500TK',1),(127,'Lkhabirmia','FCN-PKG-500TK',1),(128,'foisal@chm','FCN-PKG-500TK',1),(129,'Lshahindurga','FCN-PKG-500TK',1),(130,'Bmerajsir','FCN-PKG-500TK',1),(131,'Brofikd','Expired',1),(132,'Ljoshimpw','FCN-PKG-500TK',1),(133,'josim','FCN-PKG-500TK',1),(134,'rajuub','FCN-PKG-500TK',1),(135,'Saesagopi','FCN-PKG-500TK',1),(136,'Sbahadurmia','FCN-PKG-500TK',1),(137,'Ssahalaldeow','FCN-PKG-500TK',1),(138,'sagor@ghon','FCN-PKG-500TK',1),(139,'Lasrafulraja','FCN-PKG-500TK',1),(140,'dr.naimul','FCN-PKG-500TK',1),(141,'Srinabod','FCN-PKG-500TK',1),(142,'Skurbanmia','FCN-PKG-500TK',1),(143,'aminul@mohal','FCN-PKG-500TK',1),(144,'Shihab','FCN-PKG-500TK',1),(145,'Lpintu','FCN-PKG-500TK',1),(146,'Bsajid@mohal','FCN-PKG-500TK',1),(147,'Bjibon@dhab','FCN-PKG-500TK',1),(148,'582908','FCN-PKG-500TK',1),(149,'torikul@deo','FCN-PKG-500TK',1),(150,'shohel@dur','FCN-PKG-500TK',1),(151,'kamrul@deow','FCN-PKG-500TK',1),(152,'Babdullah','Expired',1),(153,'ppptest','FCN-PKG-500TK',1),(154,'577342','FCN-PKG-500TK',1),(155,'haider@chow','FCN-PKG-500TK',1),(156,'581754','FCN-PKG-500TK',1),(157,'aktarul@rod','FCN-PKG-500TK',1),(158,'sajahan@dur','FCN-PKG-500TK',1),(159,'Bjohorul@chow','FCN-PKG-500TK',1),(160,'fcntest18','FCN-PKG-500TK',1),(161,'nazim','FCN-PKG-500TK',1),(162,'Lmostofa@jhondi','Expired',1),(163,'moyej@chow','FCN-PKG-500TK',1),(164,'Bhalim@chow','FCN-PKG-500TK',1),(165,'afjal@chow','FCN-PKG-500TK',1),(166,'kawser@chow','FCN-PKG-500TK',1),(167,'masud@chow','Expired',1),(168,'rasel@cho','FCN-PKG-500TK',1),(169,'samsu@chow','FCN-PKG-500TK',1),(170,'asraful@cho','FCN-PKG-500TK',1),(171,'pritom@hpur','FCN-PKG-500TK',1),(172,'kanon@chow','FCN-PKG-500TK',1),(173,'faruk@chow','FCN-PKG-500TK',1),(174,'manik@mohal','FCN-PKG-500TK',1),(175,'593522','FCN-PKG-500TK',1),(176,'595573','FCN-PKG-500TK',1),(177,'573749','FCN-PKG-500TK',1),(178,'Latawr@rod','FCN-PKG-500TK',1),(179,'malek@rod','Expired',1),(180,'rakhi','FCN-PKG-500TK',1),(181,'Bmotaleb@moha','FCN-PKG-500TK',1),(182,'arif@rod','FCN-PKG-500TK',1),(183,'osman@raj','FCN-PKG-500TK',1),(184,'Lromjan@jhondi','FCN-PKG-500TK',1),(185,'arifmarkaj','FCN-PKG-500TK',1),(186,'sojol@deow','FCN-PKG-500TK',1),(187,'sijan@mia','FCN-PKG-500TK',1),(188,'shiper@mohal','FCN-PKG-500TK',1),(189,'Lalim@ntola','FCN-PKG-500TK',1),(190,'Bmatiur','Expired',1),(191,'Lsojib@durga','FCN-PKG-500TK',1),(192,'sadiqul','FCN-PKG-500TK',1),(193,'nayem@bod','FCN-PKG-500TK',1),(194,'Lrobbani@kraja','FCN-PKG-500TK',1),(195,'yousuf@deow','FCN-PKG-500TK',1),(196,'Lpolas@kraja','FCN-PKG-500TK',1),(197,'Bmadrasa@chow','FCN-PKG-500TK',1),(198,'mijan@raja','FCN-PKG-500TK',1),(199,'harun@nim','FCN-PKG-600TK',1),(200,'shohidul@dgoni','FCN-PKG-500TK',1),(201,'amijul@deow','FCN-PKG-500TK',1),(202,'Lpintu@mia','FCN-PKG-500TK',1),(203,'babu@horma','FCN-PKG-500TK',1),(204,'mosarof@haji','FCN-PKG-500TK',1),(205,'Bjuel@sahu','FCN-PKG-500TK',1),(206,'Lsaidur@rtati','FCN-PKG-500TK',1),(207,'raju@gro','FCN-PKG-500TK',1),(208,'Bbulu@chow','FCN-PKG-500TK',1),(209,'Lmadrasa@durga','FCN-PKG-500TK',1),(210,'Bdon@chow','FCN-PKG-500TK',1),(211,'ismail@deow','FCN-PKG-500TK',1),(212,'robbani@chow','FCN-PKG-500TK',1),(213,'Brohman@chow','FCN-PKG-500TK',1),(214,'furkan@saha','Expired',1),(215,'Kmoklesur@hata','FCN-PKG-500TK',1),(216,'sojib@nim','FCN-PKG-500TK',1),(217,'Baziz@chow','FCN-PKG-500TK',1),(218,'595737','FCN-PKG-500TK',1),(219,'Bmasud@mohal','FCN-PKG-500TK',1),(220,'Lasgar@mia','FCN-PKG-500TK',1),(221,'bablu@chow','FCN-PKG-500TK',1),(222,'mahatab@gro','FCN-PKG-500TK',1),(223,'bakar@mohajon','FCN-PKG-500TK',1),(224,'babu@bod','FCN-PKG-500TK',1),(225,'sisir@nim','FCN-PKG-500TK',1),(226,'azaz@chow','FCN-PKG-500TK',1),(227,'khaleda@ntola','FCN-PKG-500TK',1),(228,'Manik@raja','FCN-PKG-500TK',1),(229,'habib@durga','FCN-PKG-500TK',1),(230,'bulbul@mia','FCN-PKG-500TK',1),(231,'sohidul@deow','FCN-PKG-500TK',1),(232,'bablu@raj','FCN-PKG-500TK',1),(233,'khairul@mohal','FCN-PKG-500TK',1),(234,'amir@rtati','FCN-PKG-500TK',1),(235,'yousuf@dhab','Expired',1),(236,'arif@deow','FCN-PKG-500TK',1),(237,'akramul@jhondi','FCN-PKG-500TK',1),(238,'mahafuj@mia','FCN-PKG-500TK',1),(239,'sahid@bod','FCN-PKG-500TK',1),(240,'592364','FCN-PKG-500TK',1),(241,'kamu@chow','FCN-PKG-500TK',1),(242,'sofikul@markaj','FCN-PKG-500TK',1),(243,'rejawl@babu','FCN-PKG-500TK',1),(244,'based@rtati','FCN-PKG-500TK',1),(245,'akkash@raja','FCN-PKG-500TK',1),(246,'joshim@chow','FCN-PKG-500TK',1),(247,'usman@jhundi','FCN-PKG-500TK',1),(248,'rakib@deo','FCN-PKG-500TK',1),(249,'oskuruni@chai','FCN-PKG-500TK',1),(250,'naimul@jhond','FCN-PKG-500TK',1),(251,'bakkar@raja','Expired',1),(252,'ashik@mohal','FCN-PKG-500TK',1),(253,'ruhul@shib','FCN-PKG-500TK',1),(254,'taher@bissas','FCN-PKG-500TK',1),(255,'lipon@bod','FCN-PKG-500TK',1),(256,'jubaer@raja','FCN-PKG-500TK',1),(257,'arif@raja','Expired',1),(258,'590910','FCN-PKG-500TK',1),(259,'728108','FCN-PKG-500TK',1),(260,'lutfor@hata','FCN-PKG-500TK',1),(261,'rubel@jhondi','FCN-PKG-500TK',1),(262,'kalam@durga','FCN-PKG-500TK',1),(263,'sowkot@chow','FCN-PKG-500TK',1),(264,'monirul@chow','FCN-PKG-500TK',1),(265,'lalu@chow','FCN-PKG-500TK',1),(266,'udps@chm','FCN-PKG-500TK',1),(267,'mannan@raj','FCN-PKG-500TK',1),(268,'masud@rod','FCN-PKG-500TK',1),(269,'kamrul@raja','FCN-PKG-500TK',1),(270,'596764','FCN-PKG-500TK',1),(271,'rofikul@ub','FCN-PKG-500TK',1),(272,'afjal@kraja','FCN-PKG-500TK',1),(273,'sujon@gro','FCN-PKG-500TK',1),(274,'Bleakotchow','FCN-PKG-500TK',1),(275,'esarul@deow','FCN-PKG-500TK',1),(276,'sayed@chow','FCN-PKG-500TK',1),(277,'parvej@deow','FCN-PKG-500TK',1),(278,'rohman@hata','FCN-PKG-500TK',1),(279,'kader@rod','FCN-PKG-500TK',1),(280,'fahim@kraja','FCN-PKG-500TK',1),(281,'torikul@babu','Expired',1),(282,'586537','FCN-PKG-500TK',1),(283,'tosikul@chow','FCN-PKG-500TK',1),(284,'korim@ub','FCN-PKG-500TK',1),(285,'islami@bank','FCN-PKG-500TK',1),(286,'mojibur@mohal','FCN-PKG-500TK',1),(287,'jahaggir@deow','FCN-PKG-500TK',1),(288,'shahid@jhondy','FCN-PKG-500TK',1),(289,'dulal@mia','FCN-PKG-500TK',1),(290,'Lmalek@raj','FCN-PKG-500TK',1),(291,'emon@ntola','FCN-PKG-500TK',1),(292,'shahid@deow','Expired',1),(293,'shahin@deo','FCN-PKG-500TK',1),(294,'Bkholil@chow','FCN-PKG-500TK',1),(295,'rasel@raj','FCN-PKG-500TK',1),(296,'ajmir@raja','FCN-PKG-500TK',1),(297,'ali@raj','FCN-PKG-500TK',1),(298,'ibrahim@chow','FCN-PKG-500TK',1),(299,'ronjit@bod','FCN-PKG-500TK',1),(300,'590400','FCN-PKG-500TK',1),(301,'shohidul@chai','FCN-PKG-500TK',1),(302,'babu@durga','FCN-PKG-500TK',1),(303,'mosfik@chow','FCN-PKG-500TK',1),(304,'manik@chow','FCN-PKG-500TK',1),(305,'fcn@office','FCN-PKG-500TK',1),(306,'nur@durga','Expired',1),(307,'morsalin@raj','FCN-PKG-500TK',1),(308,'kajol@ntola','FCN-PKG-500TK',1),(309,'goni@durga','Expired',1),(310,'potab@horma','FCN-PKG-500TK',1),(311,'mamun@durga','FCN-PKG-500TK',1),(312,'hasen@nim','FCN-PKG-500TK',1),(313,'tuhin@chow','FCN-PKG-500TK',1),(314,'school@hp','FCN-PKG-500TK',1),(315,'golaf@chow','FCN-PKG-500TK',1),(316,'munirul@deow','FCN-PKG-500TK',1),(317,'sajid@deow','FCN-PKG-500TK',1),(318,'amirul@deow','FCN-PKG-500TK',1),(319,'jia@chow','FCN-PKG-500TK',1),(320,'shohel@bod','FCN-PKG-500TK',1),(321,'moinul@markaj','FCN-PKG-500TK',1),(322,'582364','FCN-PKG-500TK',1),(323,'shohidul@chow','FCN-PKG-500TK',1),(324,'dulal@chow','FCN-PKG-500TK',1),(325,'shohel@chow','Expired',1),(326,'mostafizur@raj','Expired',1),(327,'osman@nim','FCN-PKG-500TK',1),(328,'ibrahim@ful','FCN-PKG-600TK',1),(329,'rasel@chow','FCN-PKG-500TK',1),(330,'sumon@chai','FCN-PKG-500TK',1),(331,'juwel@ub','FCN-PKG-500TK',1),(332,'munirul@raj','Expired',1),(333,'sahalal@rod','FCN-PKG-500TK',1),(334,'mamun@raja','FCN-PKG-500TK',1),(335,'sofi@babu','FCN-PKG-500TK',1),(336,'567430','FCN-PKG-500TK',1),(337,'Mannan@rtati','FCN-PKG-500TK',1),(338,'omar@chow','FCN-PKG-500TK',1),(339,'habibur@deow','FCN-PKG-500TK',1),(340,'khairul@deow','FCN-PKG-500TK',1),(341,'mannan@horma','FCN-PKG-500TK',1),(342,'tonmoy@bod','Expired',1),(343,'571026','FCN-PKG-500TK',1),(344,'kollol@nim','FCN-PKG-500TK',1),(345,'johorul@chow','FCN-PKG-500TK',1),(346,'shahariar@chm','FCN-PKG-500TK',1),(347,'sadikul@chow','FCN-PKG-500TK',1),(348,'nur@horma','FCN-PKG-500TK',1),(349,'rahad@dpur','FCN-PKG-500TK',1),(350,'mostofa@moha','FCN-PKG-500TK',1),(351,'munjur@chow','FCN-PKG-500TK',1),(352,'rojibul@ntola','FCN-PKG-500TK',1),(353,'jubaer@raj','FCN-PKG-500TK',1),(354,'rasidul@siddik','FCN-PKG-500TK',1),(355,'santo@dur','FCN-PKG-500TK',1),(356,'kurban@chur','FCN-PKG-500TK',1),(357,'shohidul@deo','FCN-PKG-500TK',1),(358,'imam@mia','FCN-PKG-500TK',1),(359,'580673','FCN-PKG-500TK',1),(360,'mukul@raja','FCN-PKG-500TK',1),(361,'hakim@kraja','FCN-PKG-500TK',1),(362,'tomal@babu','FCN-PKG-500TK',1),(363,'rojob@horma','FCN-PKG-500TK',1),(364,'awal@kraja','FCN-PKG-500TK',1),(365,'ismail@horma','FCN-PKG-500TK',1),(366,'azom@mia','FCN-PKG-500TK',1),(367,'ruhul@brig','Expired',1),(368,'masum@raj','FCN-PKG-500TK',1),(369,'sofiqul@deow','FCN-PKG-500TK',1),(370,'obaida@dibdi','FCN-PKG-500TK',1),(371,'korim@bod','FCN-PKG-500TK',1),(372,'amin@nim','FCN-PKG-500TK',1),(373,'mojibur@bod','Expired',1),(374,'momin@dur','FCN-PKG-500TK',1),(375,'hojrot@bod','FCN-PKG-500TK',1),(376,'sahanaj@bisas','FCN-PKG-500TK',1),(377,'talha@markaj','FCN-PKG-500TK',1),(378,'jahaggir@gro','FCN-PKG-500TK',1),(379,'johorul@dhab','FCN-PKG-500TK',1),(380,'ohed@saha','FCN-PKG-500TK',1),(381,'asif@deow','FCN-PKG-500TK',1),(382,'yousuf@markaj','FCN-PKG-500TK',1),(383,'torikul@raj','FCN-PKG-500TK',1),(384,'sohidul@bod','FCN-PKG-500TK',1),(385,'murtuja@raja','FCN-PKG-500TK',1),(386,'hoda@chow','FCN-PKG-500TK',1),(387,'dawad@dhab','FCN-PKG-500TK',1),(388,'hasan@chow','FCN-PKG-500TK',1),(389,'596453','FCN-PKG-500TK',1),(390,'jamal@mia','FCN-PKG-500TK',1),(391,'rasidul@rod','FCN-PKG-500TK',1),(392,'samad@gro','FCN-PKG-500TK',1),(393,'mijanur@hata','FCN-PKG-500TK',1),(394,'samol@ful','FCN-PKG-500TK',1),(395,'kajol@deow','FCN-PKG-500TK',1),(396,'kasem@nim','FCN-PKG-500TK',1),(397,'forhad@rtati','Expired',1),(398,'alornir@bod','FCN-PKG-500TK',1),(399,'kiron@gaggina','FCN-PKG-500TK',1),(400,'shohidul@ub','FCN-PKG-500TK',1),(401,'lotifur@deow','FCN-PKG-500TK',1),(402,'awal@chow','FCN-PKG-500TK',1),(403,'bakkar@sahu','FCN-PKG-500TK',1),(404,'902235','FCN-PKG-500TK',1),(405,'masud@kraja','FCN-PKG-500TK',1),(406,'shoriful@ntola','FCN-PKG-500TK',1),(407,'olye@po','FCN-PKG-500TK',1),(408,'sariul@dur','Expired',1),(409,'ismail@mia','FCN-PKG-500TK',1),(410,'amijul@ds','FCN-PKG-500TK',1),(411,'redoy@goppi','FCN-PKG-500TK',1),(412,'mofazzul@cho','FCN-PKG-500TK',1),(413,'dulal@full','FCN-PKG-500TK',1),(414,'basir@ds','FCN-PKG-500TK',1),(415,'sarwor@db','FCN-PKG-500TK',1),(416,'shohel@raja','FCN-PKG-500TK',1),(417,'esarul@ntola','FCN-PKG-500TK',1),(418,'samad@rod','FCN-PKG-500TK',1),(419,'sahalom@cho','FCN-PKG-500TK',1),(420,'sadiqul@raja','FCN-PKG-500TK',1),(421,'hasib@sahu','FCN-PKG-500TK',1),(422,'575125','FCN-PKG-500TK',1),(423,'raju@siddik','FCN-PKG-500TK',1),(424,'kasem@full','FCN-PKG-500TK',1),(425,'shohel@jhondi','FCN-PKG-500TK',1),(426,'shihab@chai','FCN-PKG-500TK',1),(427,'ujjol@gaggina','FCN-PKG-500TK',1),(428,'kamal@raja','FCN-PKG-500TK',1),(429,'nur@deow','Expired',1),(430,'esarul@d','FCN-PKG-500TK',1),(431,'fahad@chow','FCN-PKG-500TK',1),(432,'emon@office','FCN-PKG-500TK',1),(433,'rauf@deow','FCN-PKG-500TK',1),(434,'roshid@mia','FCN-PKG-500TK',1),(435,'mosarof@mia','FCN-PKG-500TK',1),(436,'amin@chow','FCN-PKG-500TK',1),(437,'622412','FCN-PKG-500TK',1),(438,'babu@chow','FCN-PKG-500TK',1),(439,'595571','FCN-PKG-500TK',1),(440,'581259','FCN-PKG-500TK',1),(441,'poros@chai','FCN-PKG-500TK',1),(442,'barek@raja','FCN-PKG-500TK',1),(443,'rony@mia','FCN-PKG-500TK',1),(444,'rohim@mia','FCN-PKG-500TK',1),(445,'samad@gaggina','FCN-PKG-500TK',1),(446,'nashirul@chai','FCN-PKG-500TK',1),(447,'faruk@raj','FCN-PKG-500TK',1),(448,'Nantu','FCN-PKG-700TK',1),(449,'rakib@chow','FCN-PKG-700TK',1),(450,'alim@ub','FCN-PKG-500TK',1),(451,'mahabub@chow','FCN-PKG-500TK',1),(452,'robiul@office','FCN-PKG-500TK',1),(453,'590063','FCN-PKG-500TK',1),(454,'sojib@rod','FCN-PKG-500TK',1),(455,'tosikul@bod','FCN-PKG-500TK',1),(456,'basudeb@mohal','FCN-PKG-500TK',1),(457,'nasir@raj','FCN-PKG-500TK',1),(458,'mannan@chai','FCN-PKG-500TK',1),(459,'hridoy@full','Expired',1),(460,'rojob@sahu','FCN-PKG-500TK',1),(461,'khadiza@dur','Expired',1),(462,'566888','FCN-PKG-500TK',1),(463,'noyon@rtati','FCN-PKG-500TK',1),(464,'621663','FCN-PKG-500TK',1),(465,'595786','FCN-PKG-500TK',1),(466,'torikul@rod','FCN-PKG-500TK',1),(467,'sohag@mohal','Expired',1),(468,'rakib@gro','FCN-PKG-500TK',1),(469,'tanvir@chow','FCN-PKG-500TK',1),(470,'faruki@rkumar','FCN-PKG-500TK',1),(471,'rejaul@office','FCN-PKG-500TK',1),(472,'jubayer@nim','FCN-PKG-500TK',1),(473,'rasel@rkumar','FCN-PKG-500TK',1),(474,'selim@mia','FCN-PKG-500TK',1),(475,'raful@rod','FCN-PKG-500TK',1),(476,'mitun@ful','FCN-PKG-500TK',1),(477,'anamul@deow','FCN-PKG-500TK',1),(478,'arun@ful','FCN-PKG-500TK',1),(479,'nur@deo','FCN-PKG-500TK',1),(480,'shakil@markaj','FCN-PKG-500TK',1),(481,'rmdc','FCN-PKG-500TK',1),(482,'kawser@rsiddik','FCN-PKG-500TK',1),(483,'parvej@pw','FCN-PKG-500TK',1),(484,'masud@deow','FCN-PKG-500TK',1),(485,'nahar@ntola','FCN-PKG-500TK',1),(486,'mukter@bod','FCN-PKG-500TK',1),(487,'basir@chai','FCN-PKG-500TK',1),(488,'957789','FCN-PKG-500TK',1),(489,'971711','FCN-PKG-700TK',1),(490,'726624','FCN-PKG-700TK',1),(491,'595724','FCN-PKG-700TK',1),(492,'manik@rtati','FCN-PKG-500TK',1),(493,'lima@dur','FCN-PKG-500TK',1),(494,'Smainulsapara','FCN-PKG-500TK',1),(495,'durul@dmohajon','FCN-PKG-500TK',1),(496,'bakkar@chow','FCN-PKG-500TK',1),(497,'rony@chow','FCN-PKG-500TK',1),(498,'shohidpdb','Expired',1),(499,'joy@goppi','FCN-PKG-500TK',1),(500,'rahul@horma','FCN-PKG-500TK',1),(501,'robiul@mia','FCN-PKG-500TK',1),(502,'sajahan@mohal','FCN-PKG-500TK',1),(503,'578634','FCN-PKG-500TK',1),(504,'ahad@dur','FCN-PKG-500TK',1),(505,'tarek@chai','FCN-PKG-500TK',1),(506,'hira@bod','FCN-PKG-500TK',1),(507,'rofiqul@bissas','FCN-PKG-500TK',1),(508,'ohab@durga','FCN-PKG-500TK',1),(509,'aminul@bod','FCN-PKG-500TK',1),(510,'nadim@bod','FCN-PKG-500TK',1),(511,'nahid@sahu','FCN-PKG-500TK',1),(512,'shoriful@raja','FCN-PKG-500TK',1),(513,'aminul@sahu','FCN-PKG-500TK',1),(514,'faruk@chkhb','FCN-PKG-500TK',1),(515,'mahim@office','FCN-PKG-500TK',1),(516,'akramul@rod','FCN-PKG-500TK',1),(517,'sujon@pw','Expired',1),(518,'romjan@deo','FCN-PKG-500TK',1),(519,'hredoy@horma','FCN-PKG-500TK',1),(520,'shaiful@ub','FCN-PKG-500TK',1),(521,'robiwl@goppi','FCN-PKG-500TK',1),(522,'jamal@sahu','FCN-PKG-500TK',1),(523,'rejawl@chow','FCN-PKG-500TK',1),(524,'mursalin@chow','FCN-PKG-500TK',1),(525,'kobir@chow','FCN-PKG-500TK',1),(526,'tuhin@office','FCN-PKG-500TK',1),(527,'hasan@ub','FCN-PKG-500TK',1),(528,'lutfur@office','FCN-PKG-500TK',1),(529,'isarul@bod','FCN-PKG-500TK',1),(530,'firoz@chow','FCN-PKG-500TK',1),(531,'bari@chow','FCN-PKG-500TK',1),(532,'akbor@chow','FCN-PKG-500TK',1),(533,'Abbas@hata','FCN-PKG-500TK',1),(534,'shahjahan@mia','FCN-PKG-500TK',1),(535,'tohidul@dur','FCN-PKG-500TK',1),(536,'azizur@gro','FCN-PKG-500TK',1),(537,'badsa@sahu','FCN-PKG-500TK',1),(538,'eakub@chow','FCN-PKG-500TK',1),(539,'686175','FCN-PKG-500TK',1),(540,'selim@raj','FCN-PKG-500TK',1),(541,'hisam@raja','FCN-PKG-500TK',1),(542,'shihab@raja','FCN-PKG-500TK',1),(543,'mehidy@chm','FCN-PKG-500TK',1),(544,'aowal@deo','FCN-PKG-500TK',1),(545,'khairul@deo','Expired',1),(546,'umar@ub','FCN-PKG-500TK',1),(547,'ibblatm','FCN-PKG-500TK',1),(548,'khalek@gro','FCN-PKG-700TK',1),(549,'723271','FCN-PKG-500TK',1),(550,'sohidul@chow','FCN-PKG-500TK',1),(551,'samad@sahu','FCN-PKG-500TK',1),(552,'muni@chow','FCN-PKG-500TK',1),(553,'nojrul@chow','FCN-PKG-500TK',1),(554,'raja@horma','FCN-PKG-500TK',1),(555,'altab@mohal','FCN-PKG-500TK',1),(556,'bari@deo','Expired',1),(557,'wakidi@jondy','FCN-PKG-500TK',1),(558,'sayed@ful','FCN-PKG-500TK',1),(559,'rifat@chow','Expired',1),(560,'milon@chow','FCN-PKG-500TK',1),(561,'azom@cho','FCN-PKG-500TK',1),(562,'hakim@goppi','FCN-PKG-500TK',1),(563,'rajib@chow','FCN-PKG-500TK',1),(564,'rubel@ntola','FCN-PKG-500TK',1),(565,'rohim@chkhb','FCN-PKG-500TK',1),(566,'yousuf@ful','FCN-PKG-500TK',1),(567,'selim@chow','FCN-PKG-500TK',1),(568,'rohman@rod','FCN-PKG-500TK',1),(569,'kamal@gro','FCN-PKG-500TK',1),(570,'hojrot@jhondy','FCN-PKG-500TK',1),(571,'alomgir@mia','FCN-PKG-500TK',1),(572,'asraful@gro','FCN-PKG-500TK',1),(573,'jubaer@cho','FCN-PKG-500TK',1),(574,'yousuf@chow','FCN-PKG-500TK',1),(575,'sanaullah@nim','FCN-PKG-500TK',1),(576,'minhaj@rsiddik','FCN-PKG-500TK',1),(577,'jahaggir@gaggina','FCN-PKG-500TK',1),(578,'574579','FCN-PKG-500TK',1),(579,'shohidul@hata','FCN-PKG-500TK',1),(580,'664011','FCN-PKG-500TK',1),(581,'protick@bod','FCN-PKG-500TK',1),(582,'golap@durga','FCN-PKG-500TK',1),(583,'nahid@nim','FCN-PKG-500TK',1),(584,'rifat@gaggina','FCN-PKG-500TK',1),(585,'Lselim','FCN-PKG-500TK',1),(586,'nirob@jhondy','FCN-PKG-500TK',1),(587,'rocky@chow','Expired',1),(588,'tamim@full','FCN-PKG-500TK',1),(589,'badsa@babu','FCN-PKG-500TK',1),(590,'ripon@jhondy','FCN-PKG-500TK',1),(591,'mostakim@deow','FCN-PKG-500TK',1),(592,'595654','FCN-PKG-500TK',1),(593,'erfan@nim','FCN-PKG-500TK',1),(594,'sayem@bod','FCN-PKG-500TK',1),(595,'Lhashanmia','FCN-PKG-500TK',1),(596,'shohidul@cho','FCN-PKG-500TK',1),(597,'hosen@sahu','FCN-PKG-500TK',1),(598,'bappy@saha','FCN-PKG-500TK',1),(599,'amin@deow','FCN-PKG-500TK',1),(600,'579005','FCN-PKG-500TK',1),(601,'618540','FCN-PKG-500TK',1),(602,'589815','FCN-PKG-500TK',1),(603,'971576','FCN-PKG-500TK',1),(604,'roshid@nim','FCN-PKG-500TK',1),(605,'mukter@ub','FCN-PKG-500TK',1),(606,'nadim@pum','FCN-PKG-500TK',1),(607,'baijid@horma','FCN-PKG-500TK',1),(608,'pollob@babu','FCN-PKG-500TK',1),(609,'manik@raj','FCN-PKG-500TK',1),(610,'jobed@brig','FCN-PKG-500TK',1),(611,'rohmot@jhondy','FCN-PKG-500TK',1),(612,'meherul@cho','FCN-PKG-500TK',1),(613,'hakim@hata','FCN-PKG-500TK',1),(614,'bojlu@full','FCN-PKG-500TK',1),(615,'samsul@nim','FCN-PKG-500TK',1),(616,'salam@ub','FCN-PKG-500TK',1),(617,'bakkar@markaj','Expired',1),(618,'nayon@mohal','FCN-PKG-500TK',1),(619,'piarul@ful','FCN-PKG-500TK',1),(620,'anser@pw','Expired',1),(621,'raihan@chai','FCN-PKG-500TK',1),(622,'shahria@jhondy','FCN-PKG-500TK',1),(623,'jwel@chow','FCN-PKG-500TK',1),(624,'ataur@ntola','FCN-PKG-500TK',1),(625,'Sahin@nim','FCN-PKG-500TK',1),(626,'rajob@hatapara','FCN-PKG-500TK',1),(627,'khairul@durga','FCN-PKG-500TK',1),(628,'shohidul@deow','FCN-PKG-500TK',1),(629,'limon@bod','FCN-PKG-500TK',1),(630,'imran@saha','FCN-PKG-500TK',1),(631,'razeen@babu','FCN-PKG-500TK',1),(632,'sahin@deow','FCN-PKG-500TK',1),(633,'badol@mia','FCN-PKG-500TK',1),(634,'Sahin@mia','FCN-PKG-500TK',1),(635,'595736','FCN-PKG-500TK',1),(636,'sagor@deow','FCN-PKG-500TK',1),(637,'595740','FCN-PKG-500TK',1),(638,'1033881','FCN-PKG-500TK',1),(639,'rahmatkps','FCN-PKG-500TK',1),(640,'durulhoda@bhat','FCN-PKG-500TK',1),(641,'kamal@churki','FCN-PKG-500TK',1),(642,'Ssalammia','FCN-PKG-500TK',1),(643,'khokon@deow','FCN-PKG-500TK',1),(644,'kousik@eid','FCN-PKG-500TK',1),(645,'kader@tati','FCN-PKG-500TK',1),(646,'ekramul@eid','FCN-PKG-700TK',1),(647,'oliullah@nim','FCN-PKG-600TK',1),(648,'1013777','FCN-PKG-500TK',1),(649,'wahed@nodi','FCN-PKG-500TK',1),(650,'rubel','FCN-PKG-500TK',1),(651,'rokonchaipara','FCN-PKG-500TK',1),(652,'abulkalam@nodi','FCN-PKG-500TK',1),(653,'kader@raj','FCN-PKG-500TK',1),(654,'tuhin@raj','Expired',1),(655,'577626','FCN-PKG-500TK',1),(656,'626545','FCN-PKG-700TK',1),(657,'Muazzin@raj','FCN-PKG-500TK',1),(658,'583983','FCN-PKG-700TK',1),(659,'hameem','FCN-PKG-500TK',1),(660,'Kkaderub','FCN-PKG-500TK',1),(661,'Btaj@ed','FCN-PKG-500TK',1),(662,'593525','FCN-PKG-700TK',1),(663,'668749','FCN-PKG-700TK',1),(664,'584388','FCN-PKG-600TK',1),(665,'581266','FCN-PKG-600TK',1),(666,'769424','FCN-PKG-600TK',1),(667,'562584','FCN-PKG-500TK',1),(668,'584671','FCN-PKG-700TK',1),(669,'591933','FCN-PKG-700TK',1),(670,'ansar@chai','FCN-PKG-500TK',1),(671,'tajimul@saha','FCN-PKG-500TK',1),(672,'sofikul@bagan','FCN-PKG-500TK',1),(673,'rubel2@tati','FCN-PKG-500TK',1),(674,'mosharof@dhab','FCN-PKG-500TK',1),(675,'awal@full','FCN-PKG-500TK',1),(676,'saif@bd','FCN-PKG-500TK',1),(677,'kadar@markaj','FCN-PKG-500TK',1),(678,'sattar@nim','FCN-PKG-500TK',1),(679,'babu2@bod','FCN-PKG-500TK',1),(680,'nurul@chur','FCN-PKG-500TK',1),(681,'niamat@dtati','FCN-PKG-500TK',1),(682,'rojob@deow','FCN-PKG-500TK',1),(683,'julmat@bd','FCN-PKG-500TK',1),(684,'salauddin@full','FCN-PKG-500TK',1),(685,'farzana@tati','FCN-PKG-500TK',1),(686,'salim@tati','FCN-PKG-500TK',1),(687,'durulhoda@hata','FCN-PKG-500TK',1),(688,'akramul@dhab','FCN-PKG-500TK',1),(689,'mohamed@ful','FCN-PKG-500TK',1),(690,'foysal@raj','FCN-PKG-500TK',1),(691,'mukter@nim','FCN-PKG-500TK',1),(692,'mukt@hdeow','FCN-PKG-500TK',1),(693,'ponkoj@babu','FCN-PKG-500TK',1),(694,'amit@babu','FCN-PKG-500TK',1),(695,'sisir@raj','FCN-PKG-500TK',1),(696,'suvan@chow','FCN-PKG-500TK',1),(697,'jakariya@mohal','FCN-PKG-500TK',1),(698,'ppptest20','FCN-PKG-500TK',1),(699,'sorif@babu','FCN-PKG-500TK',1),(700,'yousof@hchow','FCN-PKG-500TK',1),(701,'jalal@chow','FCN-PKG-500TK',1),(702,'golap@chow','FCN-PKG-500TK',1),(703,'saifuddin@horma','FCN-PKG-500TK',1),(704,'nasirul@chow','FCN-PKG-500TK',1),(705,'naimul@chow','FCN-PKG-500TK',1),(706,'sofikul@sahu','FCN-PKG-500TK',1),(707,'baijid@kchow','FCN-PKG-500TK',1),(708,'asraful@mohal','FCN-PKG-700TK',1),(709,'mostofa@phouse','FCN-PKG-500TK',1),(710,'ansujulars@raj','FCN-PKG-500TK',1),(711,'sojib@hata','FCN-PKG-500TK',1),(712,'sarower@deow','FCN-PKG-500TK',1),(713,'hozrot@dd','FCN-PKG-500TK',1),(714,'rana@chai','FCN-PKG-500TK',1),(715,'raihan@chai2','FCN-PKG-500TK',1),(716,'rokon@chai','FCN-PKG-500TK',1),(717,'jahid@chai','FCN-PKG-500TK',1),(718,'ppp2','FCN-PKG-500TK',1),(719,'tusar@chai','FCN-PKG-500TK',1),(720,'sumon@mohal','FCN-PKG-500TK',1),(721,'fcnpc','FCN-PKG-500TK',1);
/*!40000 ALTER TABLE `radusergroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reseller_config`
--

DROP TABLE IF EXISTS `reseller_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reseller_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reseller_id` int(11) NOT NULL,
  `credit_limit` decimal(12,2) DEFAULT 0.00,
  `used_credit` decimal(12,2) DEFAULT 0.00,
  `commission_rate` decimal(5,2) DEFAULT 0.00,
  `allowed_plans` text DEFAULT NULL,
  `allowed_groups` text DEFAULT NULL,
  `max_users` int(11) DEFAULT 100,
  `can_create_plans` tinyint(1) DEFAULT 0,
  `can_view_reports` tinyint(1) DEFAULT 1,
  `can_manage_own_users` tinyint(1) DEFAULT 1,
  `prefix` varchar(16) DEFAULT '',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `reseller_id` (`reseller_id`),
  CONSTRAINT `reseller_config_ibfk_1` FOREIGN KEY (`reseller_id`) REFERENCES `admin_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reseller_config`
--

LOCK TABLES `reseller_config` WRITE;
/*!40000 ALTER TABLE `reseller_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `reseller_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reseller_transactions`
--

DROP TABLE IF EXISTS `reseller_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reseller_transactions` (
  `id` bigint(21) NOT NULL AUTO_INCREMENT,
  `reseller_id` int(11) NOT NULL,
  `txn_type` enum('credit','debit','commission','refund') DEFAULT 'credit',
  `amount` decimal(12,2) NOT NULL,
  `balance_after` decimal(12,2) DEFAULT 0.00,
  `description` varchar(512) DEFAULT '',
  `reference_id` varchar(128) DEFAULT '',
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `reseller_id` (`reseller_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reseller_transactions`
--

LOCK TABLES `reseller_transactions` WRITE;
/*!40000 ALTER TABLE `reseller_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `reseller_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms_config`
--

DROP TABLE IF EXISTS `sms_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sms_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `provider` varchar(64) NOT NULL,
  `api_url` varchar(512) NOT NULL,
  `api_key` varchar(256) DEFAULT '',
  `api_secret` varchar(256) DEFAULT '',
  `sender_id` varchar(32) DEFAULT '',
  `mask` varchar(32) DEFAULT '',
  `status` enum('active','inactive') DEFAULT 'active',
  `config_json` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms_config`
--

LOCK TABLES `sms_config` WRITE;
/*!40000 ALTER TABLE `sms_config` DISABLE KEYS */;
INSERT INTO `sms_config` VALUES (1,'sslwireless','https://sms.sslwireless.com/pushapi/dynamic/server.php','','','','','inactive',NULL,'2026-03-27 02:03:32','2026-03-27 02:03:32'),(2,'bulksmsbd','https://bulksmsbd.net/api/smsapi','','','','','inactive',NULL,'2026-03-27 02:03:32','2026-03-27 02:03:32'),(3,'mimsms','https://api.mimsms.com/smsapiv2','','','','','inactive',NULL,'2026-03-27 02:03:32','2026-03-27 02:03:32'),(4,'greenweb','https://api.greenweb.com.bd/api.php','','','','','inactive',NULL,'2026-03-27 02:03:32','2026-03-27 02:03:32');
/*!40000 ALTER TABLE `sms_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms_log`
--

DROP TABLE IF EXISTS `sms_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sms_log` (
  `id` bigint(21) NOT NULL AUTO_INCREMENT,
  `username` varchar(128) DEFAULT NULL,
  `phone` varchar(32) NOT NULL,
  `message` text NOT NULL,
  `template_id` int(11) DEFAULT NULL,
  `event_type` varchar(64) DEFAULT '',
  `provider` varchar(64) DEFAULT '',
  `api_response` text DEFAULT NULL,
  `status` enum('sent','failed','pending','delivered') DEFAULT 'pending',
  `sms_id` varchar(128) DEFAULT '',
  `cost` decimal(6,4) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `username` (`username`),
  KEY `phone` (`phone`),
  KEY `status` (`status`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms_log`
--

LOCK TABLES `sms_log` WRITE;
/*!40000 ALTER TABLE `sms_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `sms_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms_templates`
--

DROP TABLE IF EXISTS `sms_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sms_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_name` varchar(128) NOT NULL,
  `event_type` varchar(64) NOT NULL,
  `message_en` text NOT NULL,
  `message_bn` text DEFAULT NULL,
  `variables` varchar(512) DEFAULT '',
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `event_type` (`event_type`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms_templates`
--

LOCK TABLES `sms_templates` WRITE;
/*!40000 ALTER TABLE `sms_templates` DISABLE KEYS */;
INSERT INTO `sms_templates` VALUES (1,'Invoice Generated','invoice_generated','Dear {username}, your invoice #{invoice_number} of {amount} {currency} has been generated. Due date: {due_date}. Pay now to avoid service interruption.','প্রিয় {username}, আপনার ইনভয়েস #{invoice_number} {amount} {currency} তৈরি হয়েছে। পরিশোধের তারিখ: {due_date}।','{username},{invoice_number},{amount},{currency},{due_date}','active','2026-03-27 02:03:32'),(2,'Payment Reminder','payment_reminder','Dear {username}, your bill of {amount} {currency} is due on {due_date}. Please pay to continue your internet service.','প্রিয় {username}, আপনার {amount} {currency} বিল {due_date} তারিখে পরিশোধযোগ্য।','{username},{amount},{currency},{due_date}','active','2026-03-27 02:03:32'),(3,'Payment Received','payment_received','Dear {username}, we received your payment of {amount} {currency}. Invoice: {invoice_number}. Your service is active. Thank you!','প্রিয় {username}, আপনার {amount} {currency} পেমেন্ট গৃহীত হয়েছে। ইনভয়েস: {invoice_number}। ধন্যবাদ!','{username},{amount},{currency},{invoice_number}','active','2026-03-27 02:03:32'),(4,'Service Suspended','service_suspended','Dear {username}, your internet service has been suspended due to non-payment. Please pay {amount} {currency} to reactivate.','প্রিয় {username}, বিল না দেওয়ায় আপনার ইন্টারনেট সেবা স্থগিত করা হয়েছে। {amount} {currency} পরিশোধ করুন।','{username},{amount},{currency}','active','2026-03-27 02:03:32'),(5,'Service Reactivated','service_reactivated','Dear {username}, your internet service has been reactivated. Thank you for your payment!','প্রিয় {username}, আপনার ইন্টারনেট সেবা পুনরায় সক্রিয় করা হয়েছে। ধন্যবাদ!','{username}','active','2026-03-27 02:03:32'),(6,'Overdue Warning','overdue_warning','Dear {username}, your payment of {amount} {currency} is overdue. Service will be suspended in {grace_days} days. Pay now!','প্রিয় {username}, আপনার {amount} {currency} বিল বকেয়া। {grace_days} দিনের মধ্যে পরিশোধ না করলে সেবা বন্ধ হবে।','{username},{amount},{currency},{grace_days}','active','2026-03-27 02:03:32'),(7,'New Connection','new_connection','Welcome {username}! Your internet service is now active. Plan: {planname}, Speed: {rate_limit}. Support: {support_number}','স্বাগতম {username}! আপনার ইন্টারনেট সেবা সক্রিয়। প্ল্যান: {planname}, গতি: {rate_limit}।','{username},{planname},{rate_limit},{support_number}','active','2026-03-27 02:03:32'),(8,'Renewal Confirmation','renewal_confirmed','Dear {username}, your plan {planname} has been renewed. Next billing: {next_date}. Amount: {amount} {currency}.','প্রিয় {username}, আপনার প্ল্যান {planname} নবায়ন হয়েছে। পরবর্তী বিলিং: {next_date}।','{username},{planname},{next_date},{amount},{currency}','active','2026-03-27 02:03:32');
/*!40000 ALTER TABLE `sms_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_settings`
--

DROP TABLE IF EXISTS `system_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_group` varchar(64) NOT NULL DEFAULT 'general',
  `setting_key` varchar(128) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `setting_type` enum('text','number','boolean','json','select','textarea') DEFAULT 'text',
  `label` varchar(128) DEFAULT '',
  `description` varchar(512) DEFAULT '',
  `options` text DEFAULT NULL,
  `sort_order` int(11) DEFAULT 0,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`),
  KEY `setting_group` (`setting_group`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_settings`
--

LOCK TABLES `system_settings` WRITE;
/*!40000 ALTER TABLE `system_settings` DISABLE KEYS */;
INSERT INTO `system_settings` VALUES (1,'general','company_name','ISP Billing','text','Company Name','Your company name displayed in invoices and SMS',NULL,1,NULL,'2026-03-27 02:02:53'),(2,'general','company_logo','','text','Company Logo URL','URL to your company logo',NULL,2,NULL,'2026-03-27 02:02:53'),(3,'general','company_email','billing@example.com','text','Company Email','Contact email address',NULL,3,NULL,'2026-03-27 02:02:53'),(4,'general','company_phone','+8801XXXXXXXXX','text','Company Phone','Contact phone number',NULL,4,NULL,'2026-03-27 02:02:53'),(5,'general','company_address','','textarea','Company Address','Physical address',NULL,5,NULL,'2026-03-27 02:02:53'),(6,'general','currency','BDT','text','Currency','Default currency code',NULL,6,NULL,'2026-03-27 02:02:53'),(7,'general','currency_symbol','','text','Currency Symbol','Currency symbol (auto-detected if empty)',NULL,7,NULL,'2026-03-27 02:02:53'),(8,'general','timezone','Asia/Dhaka','select','Timezone','System timezone','[\"Asia\\/Dhaka\",\"Asia\\/Kolkata\",\"UTC\",\"America\\/New_York\",\"Europe\\/London\"]',8,NULL,'2026-03-27 02:02:53'),(9,'general','date_format','d M Y','text','Date Format','PHP date format for display',NULL,9,NULL,'2026-03-27 02:02:53'),(10,'general','language','en','select','Language','Default language','[\"en\",\"bn\"]',10,NULL,'2026-03-27 02:02:53'),(11,'security','session_timeout','3600','number','Session Timeout (seconds)','Auto-logout after inactivity',NULL,1,NULL,'2026-03-27 02:02:53'),(12,'security','max_login_attempts','5','number','Max Login Attempts','Lock account after failed attempts',NULL,2,NULL,'2026-03-27 02:02:53'),(13,'security','lock_duration','900','number','Lock Duration (seconds)','How long account stays locked',NULL,3,NULL,'2026-03-27 02:02:53'),(14,'security','password_min_length','6','number','Min Password Length','Minimum password length for admin users',NULL,4,NULL,'2026-03-27 02:02:53'),(15,'security','require_strong_password','0','boolean','Require Strong Password','Require uppercase, number, special char',NULL,5,NULL,'2026-03-27 02:02:53'),(16,'security','two_factor_enabled','0','boolean','Two-Factor Auth','Enable 2FA for admin login',NULL,6,NULL,'2026-03-27 02:02:53'),(17,'security','allowed_ips','','textarea','Allowed IPs','Comma-separated IPs allowed to access admin (empty = all)',NULL,7,NULL,'2026-03-27 02:02:53'),(18,'user_defaults','default_plan','','text','Default Plan','Default plan for new users',NULL,1,NULL,'2026-03-27 02:02:53'),(19,'user_defaults','default_group','','text','Default Group','Default group for new users',NULL,2,NULL,'2026-03-27 02:02:53'),(20,'user_defaults','default_simultaneous_use','1','number','Default Simultaneous Use','Default concurrent session limit',NULL,3,NULL,'2026-03-27 02:02:53'),(21,'user_defaults','auto_generate_username','0','boolean','Auto Generate Username','Auto-generate username from prefix + number',NULL,4,NULL,'2026-03-27 02:02:53'),(22,'user_defaults','username_prefix','user','text','Username Prefix','Prefix for auto-generated usernames',NULL,5,NULL,'2026-03-27 02:02:53'),(23,'user_defaults','auto_generate_password','0','boolean','Auto Generate Password','Auto-generate random password',NULL,6,NULL,'2026-03-27 02:02:53'),(24,'user_defaults','password_length','8','number','Generated Password Length','Length of auto-generated passwords',NULL,7,NULL,'2026-03-27 02:02:53'),(25,'user_defaults','send_welcome_sms','0','boolean','Send Welcome SMS','Send SMS when user is created',NULL,8,NULL,'2026-03-27 02:02:53'),(26,'reseller','reseller_can_delete_users','0','boolean','Reseller Can Delete Users','Allow resellers to delete their users',NULL,1,NULL,'2026-03-27 02:02:53'),(27,'reseller','reseller_can_view_all','0','boolean','Reseller Can View All','Allow resellers to see all users (not just their own)',NULL,2,NULL,'2026-03-27 02:02:53'),(28,'reseller','reseller_prefix_required','0','boolean','Require Username Prefix','Force resellers to use a username prefix',NULL,3,NULL,'2026-03-27 02:02:53'),(29,'reseller','default_credit_limit','10000','number','Default Credit Limit','Default credit limit for new resellers',NULL,4,NULL,'2026-03-27 02:02:53'),(30,'reseller','default_commission_rate','10','number','Default Commission Rate (%)','Default commission percentage',NULL,5,NULL,'2026-03-27 02:02:53'),(31,'reseller','auto_credit_on_payment','1','boolean','Auto Credit on Payment','Auto-add credit when reseller pays',NULL,6,NULL,'2026-03-27 02:02:53'),(32,'notifications','notify_on_new_user','1','boolean','Notify on New User','Send notification when user is created',NULL,1,NULL,'2026-03-27 02:02:53'),(33,'notifications','notify_on_payment','1','boolean','Notify on Payment','Send notification on successful payment',NULL,2,NULL,'2026-03-27 02:02:53'),(34,'notifications','notify_on_suspension','1','boolean','Notify on Suspension','Send notification when user is suspended',NULL,3,NULL,'2026-03-27 02:02:53'),(35,'notifications','notify_on_low_credit','1','boolean','Notify on Low Credit','Alert reseller when credit is low',NULL,4,NULL,'2026-03-27 02:02:53'),(36,'notifications','low_credit_threshold','1000','number','Low Credit Threshold','Amount below which to alert',NULL,5,NULL,'2026-03-27 02:02:53'),(37,'notifications','admin_email_notifications','0','boolean','Admin Email Notifications','Send email alerts to admin',NULL,6,NULL,'2026-03-27 02:02:53'),(38,'invoice','invoice_prefix','INV','text','Invoice Prefix','Prefix for invoice numbers',NULL,1,NULL,'2026-03-27 02:02:53'),(39,'invoice','invoice_footer','Thank you for your business!','textarea','Invoice Footer','Text shown at bottom of invoices',NULL,2,NULL,'2026-03-27 02:02:53'),(40,'invoice','invoice_due_days','7','number','Invoice Due Days','Default days until invoice is due',NULL,3,NULL,'2026-03-27 02:02:53'),(41,'invoice','auto_generate_invoice','1','boolean','Auto Generate Invoices','Auto-create invoices on billing date',NULL,4,NULL,'2026-03-27 02:02:53'),(42,'system','maintenance_mode','0','boolean','Maintenance Mode','Enable maintenance mode (only super admin can access)',NULL,1,NULL,'2026-03-27 02:02:53'),(43,'system','debug_mode','0','boolean','Debug Mode','Enable debug logging',NULL,2,NULL,'2026-03-27 02:02:53'),(44,'system','backup_enabled','0','boolean','Auto Backup','Enable automatic database backup',NULL,3,NULL,'2026-03-27 02:02:53'),(45,'system','backup_frequency','daily','select','Backup Frequency','How often to backup','[\"daily\",\"weekly\",\"monthly\"]',4,NULL,'2026-03-27 02:02:53'),(46,'general','action','update_settings','text','','',NULL,0,NULL,'2026-03-27 06:56:20');
/*!40000 ALTER TABLE `system_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_balance`
--

DROP TABLE IF EXISTS `user_balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_balance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(128) NOT NULL,
  `balance` decimal(10,2) DEFAULT 0.00,
  `total_paid` decimal(10,2) DEFAULT 0.00,
  `total_invoiced` decimal(10,2) DEFAULT 0.00,
  `last_payment_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_balance`
--

LOCK TABLES `user_balance` WRITE;
/*!40000 ALTER TABLE `user_balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userbillinfo`
--

DROP TABLE IF EXISTS `userbillinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userbillinfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(128) NOT NULL,
  `planname` varchar(64) DEFAULT NULL,
  `contactname` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `address` varchar(256) DEFAULT NULL,
  `city` varchar(128) DEFAULT NULL,
  `state` varchar(128) DEFAULT NULL,
  `zip` varchar(20) DEFAULT NULL,
  `country` varchar(64) DEFAULT NULL,
  `paymentmethod` varchar(64) DEFAULT NULL,
  `billstatus` varchar(16) DEFAULT 'new',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `planname` (`planname`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userbillinfo`
--

LOCK TABLES `userbillinfo` WRITE;
/*!40000 ALTER TABLE `userbillinfo` DISABLE KEYS */;
INSERT INTO `userbillinfo` VALUES (1,'user1','basic_1mbps','John Doe','john@example.com','+1234567890',NULL,'New York',NULL,NULL,'US',NULL,'new','2026-03-27 02:02:40','2026-03-27 02:02:40'),(2,'user2','standard_5mbps','Jane Smith','jane@example.com','+0987654321',NULL,'Los Angeles',NULL,NULL,'US',NULL,'new','2026-03-27 02:02:40','2026-03-27 02:02:40'),(3,'user3','premium_10mbps','Bob Wilson','bob@example.com','+1122334455',NULL,'Chicago',NULL,NULL,'US',NULL,'new','2026-03-27 02:02:40','2026-03-27 02:02:40');
/*!40000 ALTER TABLE `userbillinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'radius'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-04-22  2:00:02
