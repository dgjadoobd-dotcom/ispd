-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: piprapay
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `pp_addon`
--

DROP TABLE IF EXISTS `pp_addon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pp_addon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `addon_id` varchar(15) NOT NULL,
  `slug` varchar(40) NOT NULL DEFAULT '--',
  `name` text DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_date` varchar(20) NOT NULL,
  `updated_date` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `addon_id` (`addon_id`,`status`,`created_date`,`updated_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pp_addon`
--

LOCK TABLES `pp_addon` WRITE;
/*!40000 ALTER TABLE `pp_addon` DISABLE KEYS */;
/*!40000 ALTER TABLE `pp_addon` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pp_addon_parameter`
--

DROP TABLE IF EXISTS `pp_addon_parameter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pp_addon_parameter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `addon_id` varchar(15) NOT NULL,
  `option_name` varchar(50) NOT NULL,
  `value` text NOT NULL,
  `created_date` varchar(20) NOT NULL,
  `updated_date` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `addon_id` (`addon_id`,`option_name`,`created_date`,`updated_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pp_addon_parameter`
--

LOCK TABLES `pp_addon_parameter` WRITE;
/*!40000 ALTER TABLE `pp_addon_parameter` DISABLE KEYS */;
/*!40000 ALTER TABLE `pp_addon_parameter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pp_admin`
--

DROP TABLE IF EXISTS `pp_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pp_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `a_id` varchar(15) NOT NULL,
  `full_name` text NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` text NOT NULL,
  `temp_password` text DEFAULT NULL,
  `reset_limit` varchar(10) NOT NULL DEFAULT '3',
  `status` enum('active','suspend') NOT NULL DEFAULT 'active',
  `role` enum('admin','staff') NOT NULL DEFAULT 'admin',
  `2fa_status` enum('enable','disable') NOT NULL DEFAULT 'disable',
  `2fa_secret` varchar(20) NOT NULL DEFAULT '--',
  `created_date` varchar(20) NOT NULL,
  `updated_date` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `a_id` (`a_id`,`email`),
  KEY `username` (`username`),
  KEY `created_date` (`created_date`,`updated_date`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pp_admin`
--

LOCK TABLES `pp_admin` WRITE;
/*!40000 ALTER TABLE `pp_admin` DISABLE KEYS */;
INSERT INTO `pp_admin` VALUES (1,'5265d0701bdc560','Admin','admin','admin@bkdnet.xyz','$2y$10$O2KyQ3MdKuPlBYbD37JWaeOJT7JgvH2hrXjSRT1zAVHyOr85r8VQW','$2y$10$BqpVsgRTp1mcl6Cumo./5uH8FqfQGNEwn8YCzOrsH3m7oWBxKvB8i','3','active','admin','disable','ZIPKPNLRZA3J54AZ','2026-04-07 17:31:17','2026-04-07 17:31:17');
/*!40000 ALTER TABLE `pp_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pp_api`
--

DROP TABLE IF EXISTS `pp_api`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pp_api` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `brand_id` varchar(15) NOT NULL,
  `name` text NOT NULL,
  `api_key` varchar(60) NOT NULL,
  `expired_date` text DEFAULT NULL,
  `api_scopes` text NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_date` varchar(20) NOT NULL,
  `updated_date` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `brand_id` (`brand_id`,`api_key`,`created_date`,`updated_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pp_api`
--

LOCK TABLES `pp_api` WRITE;
/*!40000 ALTER TABLE `pp_api` DISABLE KEYS */;
/*!40000 ALTER TABLE `pp_api` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pp_balance_verification`
--

DROP TABLE IF EXISTS `pp_balance_verification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pp_balance_verification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_id` varchar(15) NOT NULL,
  `sender_key` varchar(15) NOT NULL,
  `type` enum('Personal','Agent','Merchant') NOT NULL DEFAULT 'Personal',
  `current_balance` decimal(20,8) NOT NULL,
  `simslot` varchar(6) NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_date` varchar(20) NOT NULL,
  `updated_date` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `device_id` (`device_id`,`sender_key`,`type`,`created_date`,`updated_date`),
  KEY `simslot` (`simslot`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pp_balance_verification`
--

LOCK TABLES `pp_balance_verification` WRITE;
/*!40000 ALTER TABLE `pp_balance_verification` DISABLE KEYS */;
/*!40000 ALTER TABLE `pp_balance_verification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pp_brands`
--

DROP TABLE IF EXISTS `pp_brands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pp_brands` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `brand_id` varchar(15) NOT NULL,
  `favicon` text DEFAULT NULL,
  `logo` text DEFAULT NULL,
  `identify_name` varchar(50) NOT NULL DEFAULT 'Default',
  `name` text DEFAULT NULL,
  `support_email_address` text DEFAULT NULL,
  `support_phone_number` text DEFAULT NULL,
  `support_website` text DEFAULT NULL,
  `whatsapp_number` text DEFAULT NULL,
  `telegram` text DEFAULT NULL,
  `facebook_messenger` text DEFAULT NULL,
  `facebook_page` text DEFAULT NULL,
  `theme` varchar(120) NOT NULL DEFAULT 'twenty-six',
  `street_address` text DEFAULT NULL,
  `city_town` text DEFAULT NULL,
  `postal_code` text DEFAULT NULL,
  `country` text DEFAULT NULL,
  `timezone` varchar(150) NOT NULL DEFAULT 'Asia/Dhaka',
  `language` varchar(150) NOT NULL DEFAULT 'en',
  `currency_code` varchar(150) NOT NULL DEFAULT 'BDT',
  `autoExchange` enum('disabled','enabled') NOT NULL DEFAULT 'disabled',
  `payment_tolerance` varchar(150) NOT NULL DEFAULT '0',
  `created_date` varchar(20) NOT NULL DEFAULT '--',
  `updated_date` varchar(20) NOT NULL DEFAULT '--',
  PRIMARY KEY (`id`),
  KEY `brand_id` (`brand_id`),
  KEY `created_date` (`created_date`,`updated_date`),
  KEY `identify_name` (`identify_name`),
  KEY `autoExchange` (`autoExchange`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pp_brands`
--

LOCK TABLES `pp_brands` WRITE;
/*!40000 ALTER TABLE `pp_brands` DISABLE KEYS */;
INSERT INTO `pp_brands` VALUES (1,'27ff9624b24c3a3',NULL,NULL,'BKD Net','BKD Net','admin@bkdnet.xyz','01700000000','http://localhost/ispd/paybill',NULL,NULL,NULL,NULL,'twenty-six',NULL,NULL,NULL,NULL,'Asia/Dhaka','en','BDT','disabled','0','2026-04-07 17:31:17','2026-04-10 20:26:46');
/*!40000 ALTER TABLE `pp_brands` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pp_browser_log`
--

DROP TABLE IF EXISTS `pp_browser_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pp_browser_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `a_id` varchar(15) NOT NULL,
  `cookie` varchar(40) NOT NULL,
  `browser` varchar(10) NOT NULL,
  `device` varchar(10) NOT NULL,
  `ip` varchar(15) NOT NULL,
  `status` enum('active','expired') NOT NULL DEFAULT 'active',
  `created_date` varchar(20) NOT NULL,
  `updated_date` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `a_id` (`a_id`,`cookie`,`created_date`,`updated_date`),
  KEY `created_date` (`created_date`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pp_browser_log`
--

LOCK TABLES `pp_browser_log` WRITE;
/*!40000 ALTER TABLE `pp_browser_log` DISABLE KEYS */;
INSERT INTO `pp_browser_log` VALUES (1,'5265d0701bdc560','1d1ad19aac05b398b95c16843e07c617','Safari','Mobile','::1','active','2026-04-10 05:09:06','2026-04-10 05:09:06'),(2,'5265d0701bdc560','dec8e03e2f7a69247f12ed8db668b12c','Unknown Br','Desktop','::1','active','2026-04-10 05:16:14','2026-04-10 05:16:14'),(3,'5265d0701bdc560','51143d541cc43e711dbaef38d6e35d08','Unknown Br','Desktop','::1','active','2026-04-10 14:28:31','2026-04-10 14:28:31'),(4,'5265d0701bdc560','7a6b6ef75424fcf864aa83c46ebff8c5','Unknown Br','Desktop','::1','active','2026-04-10 14:43:51','2026-04-10 14:43:51');
/*!40000 ALTER TABLE `pp_browser_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pp_currency`
--

DROP TABLE IF EXISTS `pp_currency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pp_currency` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `brand_id` varchar(15) NOT NULL,
  `code` varchar(6) NOT NULL,
  `symbol` varchar(5) NOT NULL,
  `rate` decimal(20,8) NOT NULL DEFAULT 0.00000000,
  `created_date` varchar(20) NOT NULL,
  `updated_date` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `brand_id` (`brand_id`,`code`,`symbol`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pp_currency`
--

LOCK TABLES `pp_currency` WRITE;
/*!40000 ALTER TABLE `pp_currency` DISABLE KEYS */;
INSERT INTO `pp_currency` VALUES (1,'27ff9624b24c3a3','BDT','₳',0.00000000,'2026-04-07 17:31:17','2026-04-07 17:31:17');
/*!40000 ALTER TABLE `pp_currency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pp_customer`
--

DROP TABLE IF EXISTS `pp_customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pp_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ref` varchar(15) NOT NULL,
  `brand_id` varchar(15) NOT NULL,
  `name` text NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `status` enum('active','suspend') NOT NULL DEFAULT 'active',
  `suspend_reason` text DEFAULT NULL,
  `inserted_via` enum('manual','checkout') NOT NULL DEFAULT 'manual',
  `created_date` varchar(20) NOT NULL,
  `updated_date` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ref` (`ref`,`brand_id`,`email`,`mobile`),
  KEY `created_date` (`created_date`,`updated_date`),
  KEY `status` (`status`,`inserted_via`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pp_customer`
--

LOCK TABLES `pp_customer` WRITE;
/*!40000 ALTER TABLE `pp_customer` DISABLE KEYS */;
/*!40000 ALTER TABLE `pp_customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pp_device`
--

DROP TABLE IF EXISTS `pp_device`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pp_device` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `d_id` varchar(40) NOT NULL,
  `device_id` varchar(15) NOT NULL,
  `otp` varchar(15) NOT NULL,
  `name` text DEFAULT NULL,
  `model` text DEFAULT NULL,
  `android_level` text DEFAULT NULL,
  `app_version` text DEFAULT NULL,
  `status` enum('processing','used') NOT NULL DEFAULT 'processing',
  `created_date` varchar(20) NOT NULL,
  `updated_date` varchar(20) NOT NULL,
  `last_sync` varchar(20) NOT NULL DEFAULT '--',
  PRIMARY KEY (`id`),
  KEY `device_id` (`device_id`),
  KEY `created_date` (`created_date`,`updated_date`),
  KEY `a_id` (`d_id`),
  KEY `otp` (`otp`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pp_device`
--

LOCK TABLES `pp_device` WRITE;
/*!40000 ALTER TABLE `pp_device` DISABLE KEYS */;
/*!40000 ALTER TABLE `pp_device` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pp_domain`
--

DROP TABLE IF EXISTS `pp_domain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pp_domain` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `domain` varchar(50) NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_date` varchar(20) NOT NULL,
  `updated_date` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `domain` (`domain`),
  KEY `created_date` (`created_date`,`updated_date`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pp_domain`
--

LOCK TABLES `pp_domain` WRITE;
/*!40000 ALTER TABLE `pp_domain` DISABLE KEYS */;
/*!40000 ALTER TABLE `pp_domain` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pp_env`
--

DROP TABLE IF EXISTS `pp_env`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pp_env` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `brand_id` varchar(15) NOT NULL DEFAULT 'both',
  `option_name` varchar(50) NOT NULL,
  `value` text NOT NULL,
  `created_date` varchar(20) NOT NULL,
  `updated_date` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `option_name` (`option_name`),
  KEY `brand_id` (`brand_id`),
  KEY `created_date` (`created_date`,`updated_date`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pp_env`
--

LOCK TABLES `pp_env` WRITE;
/*!40000 ALTER TABLE `pp_env` DISABLE KEYS */;
INSERT INTO `pp_env` VALUES (1,'both','geneal-application-settings-paymentPath','--','2026-04-10 04:37:09','2026-04-10 04:37:09'),(2,'both','geneal-application-settings-invoicePath','--','2026-04-10 04:37:09','2026-04-10 04:37:09'),(3,'both','geneal-application-settings-paymentLinkPath','--','2026-04-10 04:37:09','2026-04-10 04:37:09'),(4,'both','geneal-application-settings-adminPath','--','2026-04-10 04:37:09','2026-04-10 04:37:09'),(5,'both','geneal-application-settings-cronPath','--','2026-04-10 04:37:09','2026-04-10 04:37:09'),(6,'both','geneal-application-settings-homepageRedirect','--','2026-04-10 04:37:09','2026-04-10 04:37:09'),(7,'both','last-cron-invocation','--','2026-04-10 05:09:07','2026-04-10 05:09:07'),(8,'27ff9624b24c3a3','payment-link-default-currency','BDT','2026-04-10 05:09:42','2026-04-10 20:26:46'),(9,'both','geneal-application-settings-default_timezone','--','2026-04-10 05:13:19','2026-04-10 05:13:19'),(10,'both','geneal-application-settings-webhook_attempts_limit','--','2026-04-10 05:13:19','2026-04-10 05:13:19');
/*!40000 ALTER TABLE `pp_env` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pp_faq`
--

DROP TABLE IF EXISTS `pp_faq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pp_faq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `brand_id` varchar(15) NOT NULL,
  `title` text NOT NULL,
  `description` text NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_date` varchar(20) NOT NULL,
  `updated_date` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `brand_id` (`brand_id`,`created_date`,`updated_date`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pp_faq`
--

LOCK TABLES `pp_faq` WRITE;
/*!40000 ALTER TABLE `pp_faq` DISABLE KEYS */;
/*!40000 ALTER TABLE `pp_faq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pp_gateways`
--

DROP TABLE IF EXISTS `pp_gateways`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pp_gateways` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gateway_id` varchar(15) NOT NULL,
  `brand_id` varchar(15) NOT NULL,
  `slug` varchar(40) NOT NULL DEFAULT '--',
  `name` text DEFAULT NULL,
  `display` text DEFAULT NULL,
  `logo` text DEFAULT NULL,
  `currency` varchar(6) NOT NULL,
  `min_allow` decimal(20,8) NOT NULL DEFAULT 0.00000000,
  `max_allow` decimal(20,8) NOT NULL DEFAULT 0.00000000,
  `fixed_discount` decimal(20,8) NOT NULL DEFAULT 0.00000000,
  `percentage_discount` decimal(20,8) NOT NULL DEFAULT 0.00000000,
  `fixed_charge` decimal(20,8) NOT NULL DEFAULT 0.00000000,
  `percentage_charge` decimal(20,8) NOT NULL DEFAULT 0.00000000,
  `primary_color` text DEFAULT NULL,
  `text_color` text DEFAULT NULL,
  `btn_color` text DEFAULT NULL,
  `btn_text_color` text DEFAULT NULL,
  `tab` enum('mfs','bank','global') NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_date` varchar(20) NOT NULL,
  `updated_date` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `brand_id` (`brand_id`,`slug`),
  KEY `g_id` (`gateway_id`),
  KEY `created_date` (`created_date`,`updated_date`),
  KEY `tab` (`tab`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pp_gateways`
--

LOCK TABLES `pp_gateways` WRITE;
/*!40000 ALTER TABLE `pp_gateways` DISABLE KEYS */;
INSERT INTO `pp_gateways` VALUES (1,'5726834022','27ff9624b24c3a3','bkash-personal','bKash Personal','bKash Personal','http://localhost/ispd/paybill/pp-content/pp-modules/pp-gateways/bkash-personal/assets/logo.jpg','BDT',10.00000000,50000.00000000,0.00000000,0.00000000,0.00000000,0.00000000,'#d12053','#ffffff','#d12053','#ffffff','mfs','active','2026-04-10 05:12:27','2026-04-10 20:27:57');
/*!40000 ALTER TABLE `pp_gateways` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pp_gateways_parameter`
--

DROP TABLE IF EXISTS `pp_gateways_parameter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pp_gateways_parameter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `brand_id` varchar(15) NOT NULL,
  `gateway_id` varchar(15) NOT NULL,
  `option_name` varchar(50) NOT NULL,
  `value` text NOT NULL,
  `created_date` varchar(20) NOT NULL,
  `updated_date` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `slug` (`gateway_id`,`option_name`),
  KEY `brand_id` (`brand_id`),
  KEY `created_date` (`created_date`,`updated_date`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pp_gateways_parameter`
--

LOCK TABLES `pp_gateways_parameter` WRITE;
/*!40000 ALTER TABLE `pp_gateways_parameter` DISABLE KEYS */;
INSERT INTO `pp_gateways_parameter` VALUES (1,'27ff9624b24c3a3','5726834022','mobile_number','[\"01306959816\"]','2026-04-10 05:21:45','2026-04-10 05:21:45'),(2,'27ff9624b24c3a3','5726834022','pending_payment','enable','2026-04-10 05:21:45','2026-04-10 05:21:45');
/*!40000 ALTER TABLE `pp_gateways_parameter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pp_invoice`
--

DROP TABLE IF EXISTS `pp_invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pp_invoice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ref` varchar(30) NOT NULL,
  `brand_id` varchar(15) NOT NULL,
  `customer_info` text DEFAULT NULL,
  `gateway_id` varchar(15) NOT NULL DEFAULT '--',
  `currency` text NOT NULL,
  `due_date` text DEFAULT NULL,
  `shipping` varchar(250) NOT NULL DEFAULT '0',
  `status` enum('paid','unpaid','refunded','canceled') NOT NULL,
  `note` text DEFAULT NULL,
  `private_note` text DEFAULT NULL,
  `created_date` varchar(20) NOT NULL,
  `updated_date` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ref` (`ref`,`brand_id`),
  KEY `created_date` (`created_date`,`updated_date`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pp_invoice`
--

LOCK TABLES `pp_invoice` WRITE;
/*!40000 ALTER TABLE `pp_invoice` DISABLE KEYS */;
/*!40000 ALTER TABLE `pp_invoice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pp_invoice_items`
--

DROP TABLE IF EXISTS `pp_invoice_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pp_invoice_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `brand_id` varchar(15) NOT NULL,
  `invoice_id` varchar(30) NOT NULL,
  `description` text DEFAULT NULL,
  `amount` decimal(20,8) NOT NULL DEFAULT 0.00000000,
  `quantity` int(11) NOT NULL DEFAULT 0,
  `discount` decimal(20,8) NOT NULL DEFAULT 0.00000000,
  `vat` decimal(20,8) NOT NULL DEFAULT 0.00000000,
  `created_date` varchar(20) NOT NULL,
  `updated_date` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `invoice_id` (`invoice_id`),
  KEY `brand_id` (`brand_id`),
  KEY `created_date` (`created_date`,`updated_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pp_invoice_items`
--

LOCK TABLES `pp_invoice_items` WRITE;
/*!40000 ALTER TABLE `pp_invoice_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `pp_invoice_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pp_payment_link`
--

DROP TABLE IF EXISTS `pp_payment_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pp_payment_link` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ref` varchar(30) NOT NULL,
  `brand_id` varchar(15) NOT NULL,
  `product_info` text NOT NULL,
  `amount` decimal(20,8) NOT NULL DEFAULT 0.00000000,
  `quantity` int(11) NOT NULL DEFAULT 0,
  `currency` text NOT NULL,
  `expired_date` text NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_date` varchar(20) NOT NULL,
  `updated_date` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ref` (`ref`,`brand_id`,`created_date`,`updated_date`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pp_payment_link`
--

LOCK TABLES `pp_payment_link` WRITE;
/*!40000 ALTER TABLE `pp_payment_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `pp_payment_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pp_payment_link_field`
--

DROP TABLE IF EXISTS `pp_payment_link_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pp_payment_link_field` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `paymentLinkID` varchar(30) NOT NULL,
  `formType` text NOT NULL,
  `fieldName` text NOT NULL,
  `value` text NOT NULL,
  `required` enum('true','false') NOT NULL DEFAULT 'true',
  `created_date` varchar(20) NOT NULL,
  `updated_date` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `paymentLinkID` (`paymentLinkID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pp_payment_link_field`
--

LOCK TABLES `pp_payment_link_field` WRITE;
/*!40000 ALTER TABLE `pp_payment_link_field` DISABLE KEYS */;
/*!40000 ALTER TABLE `pp_payment_link_field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pp_permission`
--

DROP TABLE IF EXISTS `pp_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pp_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `brand_id` varchar(15) NOT NULL,
  `a_id` varchar(15) NOT NULL,
  `permission` text NOT NULL,
  `status` enum('active','suspend') NOT NULL DEFAULT 'active',
  `created_date` varchar(20) NOT NULL,
  `updated_date` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `brand_id` (`brand_id`,`a_id`,`created_date`,`updated_date`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pp_permission`
--

LOCK TABLES `pp_permission` WRITE;
/*!40000 ALTER TABLE `pp_permission` DISABLE KEYS */;
INSERT INTO `pp_permission` VALUES (1,'27ff9624b24c3a3','5265d0701bdc560','{\"type\":\"admin\"}','active','2026-04-07 17:31:17','2026-04-07 17:31:17');
/*!40000 ALTER TABLE `pp_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pp_sms_data`
--

DROP TABLE IF EXISTS `pp_sms_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pp_sms_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `source` enum('app','web') NOT NULL DEFAULT 'web',
  `device_id` varchar(15) NOT NULL,
  `sender` varchar(15) NOT NULL DEFAULT '--',
  `sender_key` varchar(15) NOT NULL,
  `simslot` text DEFAULT NULL,
  `number` varchar(20) NOT NULL DEFAULT '--',
  `amount` decimal(20,8) NOT NULL DEFAULT 0.00000000,
  `currency` varchar(10) NOT NULL DEFAULT '--',
  `trx_id` varchar(100) NOT NULL DEFAULT '--',
  `balance` varchar(70) NOT NULL DEFAULT '--',
  `message` text DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `type` enum('Personal','Agent','Merchant') NOT NULL DEFAULT 'Personal',
  `entry_type` enum('manual','automatic') NOT NULL DEFAULT 'automatic',
  `edit_status` enum('done','pending') NOT NULL DEFAULT 'pending',
  `status` enum('approved','awaiting-review','used','error') NOT NULL DEFAULT 'approved',
  `created_date` varchar(20) NOT NULL,
  `updated_date` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `device_id` (`sender_key`,`amount`,`trx_id`),
  KEY `created_date` (`created_date`,`updated_date`),
  KEY `number` (`number`),
  KEY `balance` (`balance`),
  KEY `device_id_2` (`device_id`),
  KEY `sender` (`sender`),
  KEY `source` (`source`),
  KEY `type` (`type`,`entry_type`,`edit_status`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pp_sms_data`
--

LOCK TABLES `pp_sms_data` WRITE;
/*!40000 ALTER TABLE `pp_sms_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `pp_sms_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pp_transaction`
--

DROP TABLE IF EXISTS `pp_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pp_transaction` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `brand_id` varchar(15) NOT NULL,
  `source` enum('invoice','payment-link','payment-link-default','api') NOT NULL DEFAULT 'api',
  `ref` varchar(30) NOT NULL,
  `customer_info` text NOT NULL,
  `amount` decimal(20,8) NOT NULL DEFAULT 0.00000000,
  `processing_fee` decimal(20,8) NOT NULL DEFAULT 0.00000000,
  `discount_amount` decimal(20,8) NOT NULL DEFAULT 0.00000000,
  `local_net_amount` decimal(20,8) NOT NULL DEFAULT 0.00000000,
  `currency` text DEFAULT NULL,
  `local_currency` text DEFAULT NULL,
  `sender` varchar(50) NOT NULL DEFAULT '--',
  `trx_id` varchar(70) NOT NULL DEFAULT '--',
  `trx_slip` text DEFAULT NULL,
  `gateway_id` varchar(50) NOT NULL DEFAULT '--',
  `sender_key` varchar(50) NOT NULL DEFAULT '--',
  `sender_type` varchar(11) NOT NULL,
  `source_info` text DEFAULT NULL,
  `metadata` text DEFAULT NULL,
  `status` enum('completed','pending','refunded','initiated','canceled') NOT NULL DEFAULT 'initiated',
  `return_url` text DEFAULT NULL,
  `webhook_url` text DEFAULT NULL,
  `created_date` varchar(20) NOT NULL,
  `updated_date` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `brand_id` (`brand_id`,`ref`,`trx_id`),
  KEY `payment_method_id` (`gateway_id`,`sender_key`),
  KEY `gateway_slug` (`sender_key`),
  KEY `created_date` (`created_date`,`updated_date`),
  KEY `sender` (`sender`),
  KEY `source` (`source`,`status`),
  KEY `sender_type` (`sender_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pp_transaction`
--

LOCK TABLES `pp_transaction` WRITE;
/*!40000 ALTER TABLE `pp_transaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `pp_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pp_webhook_log`
--

DROP TABLE IF EXISTS `pp_webhook_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pp_webhook_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ref` varchar(15) NOT NULL,
  `brand_id` varchar(15) NOT NULL,
  `payload` text NOT NULL,
  `url` text NOT NULL,
  `attempts` int(11) NOT NULL DEFAULT 0,
  `response_body` text DEFAULT NULL,
  `http_code` text DEFAULT NULL,
  `status` enum('completed','pending','canceled') NOT NULL DEFAULT 'pending',
  `created_date` varchar(20) NOT NULL,
  `updated_date` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ref` (`ref`),
  KEY `brand_id` (`brand_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pp_webhook_log`
--

LOCK TABLES `pp_webhook_log` WRITE;
/*!40000 ALTER TABLE `pp_webhook_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `pp_webhook_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'piprapay'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-04-18  2:00:05
