-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: radius
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activity_log`
--

DROP TABLE IF EXISTS `activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activity_log` (
  `id` bigint(21) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `username` varchar(64) DEFAULT '',
  `action` varchar(64) NOT NULL,
  `module` varchar(64) DEFAULT '',
  `description` text DEFAULT NULL,
  `old_data` text DEFAULT NULL,
  `new_data` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT '',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `action` (`action`),
  KEY `module` (`module`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_log`
--

LOCK TABLES `activity_log` WRITE;
/*!40000 ALTER TABLE `activity_log` DISABLE KEYS */;
INSERT INTO `activity_log` VALUES (1,1,'admin','login','auth','User logged in',NULL,NULL,'172.17.50.10','2026-03-27 02:03:56'),(2,1,'admin','login','auth','User logged in',NULL,NULL,'127.0.0.1','2026-03-27 02:53:25'),(3,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-27 03:01:45'),(4,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-27 03:02:22'),(5,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-27 03:47:57'),(6,1,'admin','login','auth','User logged in',NULL,NULL,'127.0.0.1','2026-03-27 03:49:24'),(7,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-27 04:05:26'),(8,1,'admin','login','auth','User logged in',NULL,NULL,'127.0.0.1','2026-03-27 06:47:09'),(9,1,'admin','update_settings','settings','Updated system settings',NULL,NULL,'127.0.0.1','2026-03-27 06:56:20'),(10,1,'admin','login','auth','User logged in',NULL,NULL,'127.0.0.1','2026-03-27 07:00:42'),(11,1,'admin','login','auth','User logged in',NULL,NULL,'127.0.0.1','2026-03-27 07:18:08'),(12,1,'admin','login','auth','User logged in',NULL,NULL,'127.0.0.1','2026-03-27 07:18:50'),(13,1,'','logout','auth','User logged out',NULL,NULL,'','2026-03-27 07:18:50'),(14,1,'admin','login','auth','User logged in',NULL,NULL,'127.0.0.1','2026-03-27 11:10:07'),(15,1,'admin','login','auth','User logged in',NULL,NULL,'127.0.0.1','2026-03-29 01:46:36'),(16,1,'admin','login','auth','User logged in',NULL,NULL,'127.0.0.1','2026-03-29 08:00:15'),(17,1,'admin','login','auth','User logged in',NULL,NULL,'127.0.0.1','2026-03-29 17:46:45'),(18,1,'admin','login','auth','User logged in',NULL,NULL,'127.0.0.1','2026-03-30 19:14:00'),(19,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-31 08:43:36'),(20,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-31 08:43:48'),(21,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-31 08:44:03'),(22,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-31 08:45:52'),(23,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-31 08:52:00'),(24,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-31 08:52:41'),(25,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-31 08:53:51'),(26,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-31 08:54:02'),(27,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-31 08:55:04'),(28,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-31 08:56:19'),(29,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-31 08:57:53'),(30,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-31 09:03:38'),(31,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-31 09:04:08'),(32,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-31 09:15:13'),(33,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-31 09:16:47'),(34,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-31 09:17:04'),(35,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-31 09:18:45'),(36,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-31 09:20:01'),(37,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-31 09:20:31'),(38,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-31 09:21:17'),(39,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-31 09:21:35'),(40,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-31 09:23:57'),(41,1,'admin','login','auth','User logged in',NULL,NULL,'::1','2026-03-31 10:29:25');
/*!40000 ALTER TABLE `activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_permissions`
--

DROP TABLE IF EXISTS `admin_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permission_name` varchar(128) NOT NULL,
  `permission_slug` varchar(128) NOT NULL,
  `module` varchar(64) NOT NULL,
  `description` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `permission_slug` (`permission_slug`),
  KEY `module` (`module`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_permissions`
--

LOCK TABLES `admin_permissions` WRITE;
/*!40000 ALTER TABLE `admin_permissions` DISABLE KEYS */;
INSERT INTO `admin_permissions` VALUES (1,'View Dashboard','dashboard.view','dashboard','View dashboard statistics'),(2,'View Users','users.view','users','View RADIUS users'),(3,'Create Users','users.create','users','Create new RADIUS users'),(4,'Edit Users','users.edit','users','Edit existing RADIUS users'),(5,'Delete Users','users.delete','users','Delete RADIUS users'),(6,'Disconnect Users','users.disconnect','users','Disconnect user sessions'),(7,'Manage User Attributes','users.attributes','users','Manage RADIUS attributes'),(8,'View Groups','groups.view','groups','View user groups'),(9,'Create Groups','groups.create','groups','Create new groups'),(10,'Edit Groups','groups.edit','groups','Edit existing groups'),(11,'Delete Groups','groups.delete','groups','Delete groups'),(12,'View Plans','plans.view','plans','View billing plans'),(13,'Create Plans','plans.create','plans','Create billing plans'),(14,'Edit Plans','plans.edit','plans','Edit billing plans'),(15,'Delete Plans','plans.delete','plans','Delete billing plans'),(16,'View NAS','nas.view','nas','View NAS devices'),(17,'Create NAS','nas.create','nas','Create NAS devices'),(18,'Edit NAS','nas.edit','nas','Edit NAS devices'),(19,'Delete NAS','nas.delete','nas','Delete NAS devices'),(20,'View Sessions','sessions.view','sessions','View active sessions'),(21,'Disconnect Sessions','sessions.disconnect','sessions','Kill active sessions'),(22,'View Traffic','traffic.view','traffic','View traffic data'),(23,'View Accounting','accounting.view','accounting','View accounting records'),(24,'View Auth Log','authlog.view','authlog','View authentication log'),(25,'View OLT','olt.view','olt','View OLT devices'),(26,'Create OLT','olt.create','olt','Create OLT devices'),(27,'Edit OLT','olt.edit','olt','Edit OLT devices'),(28,'Delete OLT','olt.delete','olt','Delete OLT devices'),(29,'Sync OLT','olt.sync','olt','Sync OLT data'),(30,'Manage ONU','onu.manage','olt','Manage ONU devices'),(31,'View Payments','payments.view','payments','View payments and invoices'),(32,'Create Invoice','payments.create','payments','Create invoices'),(33,'Cancel Invoice','payments.cancel','payments','Cancel invoices'),(34,'Manage Gateways','payments.gateways','payments','Manage payment gateways'),(35,'View Billing','billing.view','billing','View auto-billing'),(36,'Run Cron','billing.cron','billing','Run billing cron'),(37,'Manage Schedules','billing.schedules','billing','Manage billing schedules'),(38,'View SMS','sms.view','sms','View SMS log'),(39,'Send SMS','sms.send','sms','Send SMS messages'),(40,'Manage Templates','sms.templates','sms','Manage SMS templates'),(41,'Manage Providers','sms.providers','sms','Manage SMS providers'),(42,'View Settings','settings.view','settings','View system settings'),(43,'Edit Settings','settings.edit','settings','Edit system settings'),(44,'View Admin Users','adminusers.view','adminusers','View admin users'),(45,'Create Admin Users','adminusers.create','adminusers','Create admin users'),(46,'Edit Admin Users','adminusers.edit','adminusers','Edit admin users'),(47,'Delete Admin Users','adminusers.delete','adminusers','Delete admin users'),(48,'View Roles','roles.view','roles','View roles and permissions'),(49,'Create Roles','roles.create','roles','Create roles'),(50,'Edit Roles','roles.edit','roles','Edit roles'),(51,'Delete Roles','roles.delete','roles','Delete roles'),(52,'View Resellers','resellers.view','resellers','View resellers'),(53,'Manage Resellers','resellers.manage','resellers','Manage reseller config'),(54,'Credit Reseller','resellers.credit','resellers','Add/deduct reseller credit'),(55,'View Reports','reports.view','reports','View reports'),(56,'Export Reports','reports.export','reports','Export reports'),(57,'View Activity Log','activitylog.view','activitylog','View activity log');
/*!40000 ALTER TABLE `admin_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_role_permissions`
--

DROP TABLE IF EXISTS `admin_role_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_role_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_permission` (`role_id`,`permission_id`),
  KEY `role_id` (`role_id`),
  KEY `permission_id` (`permission_id`),
  CONSTRAINT `admin_role_permissions_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `admin_roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `admin_role_permissions_ibfk_2` FOREIGN KEY (`permission_id`) REFERENCES `admin_permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=183 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_role_permissions`
--

LOCK TABLES `admin_role_permissions` WRITE;
/*!40000 ALTER TABLE `admin_role_permissions` DISABLE KEYS */;
INSERT INTO `admin_role_permissions` VALUES (11,1,1),(52,1,2),(53,1,3),(54,1,4),(55,1,5),(56,1,6),(57,1,7),(12,1,8),(13,1,9),(14,1,10),(15,1,11),(30,1,12),(31,1,13),(32,1,14),(33,1,15),(16,1,16),(17,1,17),(18,1,18),(19,1,19),(43,1,20),(44,1,21),(51,1,22),(1,1,23),(7,1,24),(20,1,25),(21,1,26),(22,1,27),(23,1,28),(24,1,29),(25,1,30),(26,1,31),(27,1,32),(28,1,33),(29,1,34),(8,1,35),(9,1,36),(10,1,37),(47,1,38),(48,1,39),(49,1,40),(50,1,41),(45,1,42),(46,1,43),(3,1,44),(4,1,45),(5,1,46),(6,1,47),(39,1,48),(40,1,49),(41,1,50),(42,1,51),(36,1,52),(37,1,53),(38,1,54),(34,1,55),(35,1,56),(2,1,57),(73,2,1),(117,2,2),(113,2,3),(116,2,4),(114,2,5),(115,2,6),(112,2,7),(77,2,8),(74,2,9),(76,2,10),(75,2,11),(95,2,12),(92,2,13),(94,2,14),(93,2,15),(81,2,16),(78,2,17),(80,2,18),(79,2,19),(105,2,20),(104,2,21),(111,2,22),(64,2,23),(69,2,24),(86,2,25),(82,2,26),(84,2,27),(83,2,28),(85,2,29),(87,2,30),(91,2,31),(89,2,32),(88,2,33),(90,2,34),(72,2,35),(70,2,36),(71,2,37),(110,2,38),(108,2,39),(109,2,40),(107,2,41),(106,2,42),(68,2,44),(66,2,45),(67,2,46),(103,2,48),(101,2,49),(102,2,50),(100,2,52),(99,2,53),(98,2,54),(97,2,55),(96,2,56),(65,2,57),(129,3,1),(140,3,2),(137,3,3),(139,3,4),(138,3,6),(136,3,7),(130,3,8),(131,3,12),(134,3,20),(133,3,21),(135,3,22),(127,3,23),(128,3,35),(132,3,55),(144,4,1),(153,4,2),(150,4,3),(152,4,4),(151,4,6),(145,4,8),(146,4,12),(148,4,20),(147,4,21),(149,4,22),(142,4,23),(143,4,24),(159,5,1),(162,5,2),(160,5,20),(161,5,22),(157,5,23),(158,5,24),(169,6,1),(182,6,2),(170,6,8),(174,6,12),(171,6,16),(178,6,20),(181,6,22),(164,6,23),(167,6,24),(172,6,25),(173,6,31),(168,6,35),(180,6,38),(179,6,42),(166,6,44),(177,6,48),(176,6,52),(175,6,55),(165,6,57);
/*!40000 ALTER TABLE `admin_role_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_roles`
--

DROP TABLE IF EXISTS `admin_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(64) NOT NULL,
  `role_slug` varchar(64) NOT NULL,
  `description` varchar(255) DEFAULT '',
  `is_default` tinyint(1) DEFAULT 0,
  `is_system` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_slug` (`role_slug`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_roles`
--

LOCK TABLES `admin_roles` WRITE;
/*!40000 ALTER TABLE `admin_roles` DISABLE KEYS */;
INSERT INTO `admin_roles` VALUES (1,'Super Admin','super-admin','Full system access',0,1,'2026-03-27 02:02:53'),(2,'Admin','admin','Administrative access',0,1,'2026-03-27 02:02:53'),(3,'Reseller','reseller','Reseller with credit-based user management',0,1,'2026-03-27 02:02:53'),(4,'Employee','employee','Staff member with limited access',0,1,'2026-03-27 02:02:53'),(5,'Support','support','Support staff - view and ticket management',0,1,'2026-03-27 02:02:53'),(6,'Viewer','viewer','Read-only access',1,1,'2026-03-27 02:02:53');
/*!40000 ALTER TABLE `admin_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_sessions`
--

DROP TABLE IF EXISTS `admin_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_sessions` (
  `id` bigint(21) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `session_token` varchar(128) NOT NULL,
  `ip_address` varchar(45) DEFAULT '',
  `user_agent` varchar(512) DEFAULT '',
  `expires_at` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `session_token` (`session_token`),
  KEY `user_id` (`user_id`),
  KEY `expires_at` (`expires_at`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_sessions`
--

LOCK TABLES `admin_sessions` WRITE;
/*!40000 ALTER TABLE `admin_sessions` DISABLE KEYS */;
INSERT INTO `admin_sessions` VALUES (5,1,'9bd701d20242bbbde0155bb03e337fb496ac05376c8791e65226609d2750076c','::1','','2026-03-27 10:47:57','2026-03-27 03:47:57'),(6,1,'64c1f709d0bb3bd541d458852916ada06699c5820cba8e9d66a2dc073ee0274f','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0','2026-03-27 11:18:49','2026-03-27 03:49:24'),(7,1,'d2a9c93537455782bfbe9d6ede4575d00c5155c293fb6a36d39308c6f851f8b6','::1','','2026-03-27 11:05:26','2026-03-27 04:05:26'),(8,1,'aa69e80a5d014f6fc28a2d8db35c89cf331d7f06938cb8649bf53731ae1de671','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0','2026-03-27 13:57:38','2026-03-27 06:47:09'),(9,1,'6c801728d64f96a6cadbf5059c5e723aacc6f11136ab1e26dfd19ddcdcc0e57a','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0','2026-03-27 16:06:48','2026-03-27 07:00:42'),(10,1,'04a6419f7513ce49c0c86ff83ead551e13f4c7f7a3ece3c304850a3ebf4c173c','127.0.0.1','','2026-03-27 09:18:08','2026-03-27 07:18:08'),(12,1,'3c336c45d7f90af33bd323b1016c0de1955e9b4722aaf96a520175879c8fc757','172.17.50.10','curl/8.18.0','2026-03-27 09:59:02','2026-03-27 07:48:37'),(13,1,'4b17d92127a45887ea8c0410114bcdb980d1cf426d95b94bc74c6b62a4c2845e','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0','2026-03-27 18:40:38','2026-03-27 11:10:07'),(14,1,'ab66275c4bbe3377ee747b71061f6cf03b1352ab047b2d5309bb002924ed59f8','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0','2026-03-29 08:46:52','2026-03-29 01:46:36'),(15,1,'b12d0d42aa90c42cfcf230a20d9a0b5c33ebf6818da6f219f6aa885c85ddedf8','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0','2026-03-29 15:00:34','2026-03-29 08:00:15'),(16,1,'a2176f79764b8874c6f1564ca0d5b4baf0f708ed15fe0b5ee853e7569b304734','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0','2026-03-30 00:48:06','2026-03-29 17:46:45'),(17,1,'802dbb1ef29a2c209f22116f76d65a55668ad3a932c1ddb8350abba7989272b0','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0','2026-03-31 02:14:14','2026-03-30 19:14:00'),(18,1,'c72e7cc6262e846e908cf476f40c8ba93e3b1dabc4b0a694e8d1881694074bf9','::1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920','2026-03-31 11:43:35','2026-03-31 08:43:36'),(19,1,'1815ee83b735fe49e70a5e85763595094439f4bd6821648aa17668454c434ca7','::1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920','2026-03-31 11:43:48','2026-03-31 08:43:48'),(20,1,'3164fc7f89fc54b234488b92af6f4bf1b280740ec9c364ea317232a7b4ae2e36','::1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920','2026-03-31 11:44:03','2026-03-31 08:44:03'),(21,1,'a59b04157df50a049e088a881a645fef43ace5d32702c31ae429dd1be9e40b77','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36','2026-03-31 11:45:52','2026-03-31 08:45:52'),(22,1,'87d7ffa57f12cc7b5861838c7a94d7a0fa66006ed4258a501374141461c48a6d','::1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920','2026-03-31 11:52:00','2026-03-31 08:52:00'),(23,1,'c66dbda2046a53b84f0075089ff568ba521437e41b551c63bb3dabcefb587bd3','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36','2026-03-31 11:52:41','2026-03-31 08:52:41'),(24,1,'131d80fc6946ed9685677ea59b0d60185764509c17d9aac397502f21d8d152bd','::1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920','2026-03-31 11:53:51','2026-03-31 08:53:51'),(25,1,'4d2ba3570e7bae849eceba9876a257954e73b1caae86cb04053fa7694073dbeb','::1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920','2026-03-31 11:54:02','2026-03-31 08:54:02'),(26,1,'88db3b5aca5d75e2f3aba9ab8e40ba0ab76600e39056454ee3ca270d7cd7a236','::1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920','2026-03-31 11:55:04','2026-03-31 08:55:04'),(27,1,'6a65699c6abd76736c968da5e5d4402ffb24190c7489e955b669e3b86ff42712','::1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920','2026-03-31 11:56:19','2026-03-31 08:56:19'),(28,1,'acbba7ac52377babd069ba28b80a4259ff80be1b5cc10c138c8027c6c36684c0','::1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920','2026-03-31 11:57:53','2026-03-31 08:57:53'),(29,1,'2947b7bc31fbca07a63aa0c23e70fea3b291be196a5c49f8b91a6d963137eae5','::1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920','2026-03-31 12:03:40','2026-03-31 09:03:38'),(30,1,'4925d70690f6d6fde1427852d2d587e63f2c74a5680d8b97a139a7c206151b02','::1','','2026-03-31 12:04:09','2026-03-31 09:04:08'),(31,1,'e742c1d2258da11df28fcfc1f75a289ad36102c95a06bbfed2e861884eb7f351','::1','','2026-03-31 12:15:13','2026-03-31 09:15:13'),(32,1,'e5ea7e25fb899ac99dfc616df1e32e95bbc304f1c95ee0b58dae51329b3cac7f','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36','2026-03-31 12:16:47','2026-03-31 09:16:47'),(33,1,'06544f2beb8ea419c0cb11493b3f2f1df9945ef5266b7c5127ed8a3d5faa35d7','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36','2026-03-31 12:17:04','2026-03-31 09:17:04'),(34,1,'8637bdfe0f57523e4f74213fe564c673cf5adcd4724c228df6e19c17365da02e','::1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920','2026-03-31 12:18:45','2026-03-31 09:18:45'),(35,1,'ebd5d2c30d5b49fa792cb383a14d54ea721731e4b9061fe51c630bc1f83763cc','::1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920','2026-03-31 12:20:01','2026-03-31 09:20:01'),(36,1,'c15e315f5e0b89e3bf8b4f5e8f7e751de3980e8888a7500d55959358e5437836','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36','2026-03-31 12:20:31','2026-03-31 09:20:31'),(37,1,'7498a0dfb7c1bd1277fafe063635cda09afd5d57dd0ecebc620fa6a9821e25c0','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36','2026-03-31 12:21:17','2026-03-31 09:21:17'),(38,1,'bd4ad436bea1e7e680f241f3ff2f412cb0a050f15aadc7898160e5717321656b','::1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920','2026-03-31 12:21:35','2026-03-31 09:21:35'),(39,1,'a198f4a27f67b45a93d2589cc18c70d249bc81edec4169c5ec1065a32d98ff07','::1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.26100.7920','2026-03-31 12:23:57','2026-03-31 09:23:57'),(40,1,'c3b2649a8325734c85b03201ca55311ccd3432bfc5ff875c362a77460cb52dda','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36','2026-03-31 13:31:54','2026-03-31 10:29:25');
/*!40000 ALTER TABLE `admin_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_users`
--

DROP TABLE IF EXISTS `admin_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL,
  `password` varchar(255) NOT NULL,
  `fullname` varchar(128) DEFAULT '',
  `email` varchar(200) DEFAULT '',
  `phone` varchar(32) DEFAULT '',
  `role_id` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `user_type` enum('admin','reseller','employee','support','viewer') DEFAULT 'employee',
  `status` enum('active','inactive','suspended','locked') DEFAULT 'active',
  `avatar` varchar(255) DEFAULT '',
  `last_login` datetime DEFAULT NULL,
  `last_ip` varchar(45) DEFAULT '',
  `login_attempts` int(3) DEFAULT 0,
  `locked_until` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `role_id` (`role_id`),
  KEY `parent_id` (`parent_id`),
  KEY `user_type` (`user_type`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_users`
--

LOCK TABLES `admin_users` WRITE;
/*!40000 ALTER TABLE `admin_users` DISABLE KEYS */;
INSERT INTO `admin_users` VALUES (1,'admin','$2y$10$gEtsbUYHaqdalPLSgUyGe.K54HBZPqGSqAYJVjfQPvCtADNUv1gIu','System Administrator','admin@example.com','',1,NULL,'admin','active','','2026-03-31 10:29:25','::1',1,NULL,'2026-03-27 02:02:53','2026-04-01 04:34:23');
/*!40000 ALTER TABLE `admin_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `billing_history`
--

DROP TABLE IF EXISTS `billing_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `billing_history` (
  `id` bigint(21) NOT NULL AUTO_INCREMENT,
  `username` varchar(128) NOT NULL,
  `action` enum('invoice_generated','payment_received','reminder_sent','grace_period','suspended','reactivated','auto_renewed','plan_changed') NOT NULL,
  `invoice_number` varchar(64) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `details` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `username` (`username`),
  KEY `action` (`action`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billing_history`
--

LOCK TABLES `billing_history` WRITE;
/*!40000 ALTER TABLE `billing_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `billing_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `billing_plans`
--

DROP TABLE IF EXISTS `billing_plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `billing_plans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `planname` varchar(64) NOT NULL,
  `plandesc` varchar(256) DEFAULT NULL,
  `rate_limit` varchar(128) DEFAULT NULL,
  `burst_limit` varchar(128) DEFAULT NULL,
  `burst_threshold` varchar(128) DEFAULT NULL,
  `burst_time` varchar(128) DEFAULT NULL,
  `priority` int(11) DEFAULT 8,
  `traffic_limit` bigint(20) DEFAULT NULL,
  `time_limit` int(11) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT 0.00,
  `currency` varchar(3) DEFAULT 'USD',
  `active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `planname` (`planname`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billing_plans`
--

LOCK TABLES `billing_plans` WRITE;
/*!40000 ALTER TABLE `billing_plans` DISABLE KEYS */;
INSERT INTO `billing_plans` VALUES (1,'basic_1mbps','15Mbps','20M/20M','40M/40M','40M/40M','40/40',8,0,0,500.00,'BDT',1,'2026-03-27 02:02:40','2026-03-27 08:56:34'),(2,'standard_5mbps','Standard 5Mbps Plan','5M/10M','10M/20M','5M/10M','40/40',6,0,0,2500.00,'BDT',1,'2026-03-27 02:02:40','2026-03-27 06:49:22'),(3,'premium_10mbps','Premium 10Mbps Plan','10M/20M','20M/40M','10M/20M','40/40',4,0,0,500.00,'BDT',1,'2026-03-27 02:02:40','2026-03-27 06:49:05');
/*!40000 ALTER TABLE `billing_plans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `billing_schedule`
--

DROP TABLE IF EXISTS `billing_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `billing_schedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(128) NOT NULL,
  `planname` varchar(128) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `currency` varchar(3) DEFAULT 'BDT',
  `billing_cycle` enum('daily','weekly','monthly','quarterly','yearly','one-time') DEFAULT 'monthly',
  `billing_day` int(2) DEFAULT 1,
  `next_billing_date` date NOT NULL,
  `last_billed_date` date DEFAULT NULL,
  `grace_period_days` int(3) DEFAULT 3,
  `auto_suspend` tinyint(1) DEFAULT 1,
  `auto_generate_invoice` tinyint(1) DEFAULT 1,
  `send_sms_reminder` tinyint(1) DEFAULT 1,
  `reminder_days_before` int(3) DEFAULT 3,
  `status` enum('active','paused','cancelled') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `next_billing_date` (`next_billing_date`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billing_schedule`
--

LOCK TABLES `billing_schedule` WRITE;
/*!40000 ALTER TABLE `billing_schedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `billing_schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `billing_settings`
--

DROP TABLE IF EXISTS `billing_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `billing_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(128) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `description` varchar(512) DEFAULT '',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billing_settings`
--

LOCK TABLES `billing_settings` WRITE;
/*!40000 ALTER TABLE `billing_settings` DISABLE KEYS */;
INSERT INTO `billing_settings` VALUES (1,'auto_billing_enabled','0','Enable/disable automatic billing system','2026-03-27 02:03:32'),(2,'auto_suspend_enabled','1','Auto-suspend users who dont pay','2026-03-27 02:03:32'),(3,'auto_sms_enabled','0','Enable/disable SMS notifications','2026-03-27 02:03:32'),(4,'sms_provider','sslwireless','Active SMS provider','2026-03-27 02:03:32'),(5,'support_number','+8801XXXXXXXXX','Support phone number','2026-03-27 02:03:32'),(6,'company_name','ISP Billing','Company name for SMS','2026-03-27 02:03:32'),(7,'invoice_prefix','INV','Invoice number prefix','2026-03-27 02:03:32'),(8,'grace_period_days','3','Default grace period before suspension','2026-03-27 02:03:32'),(9,'reminder_days_before','3','Days before due date to send reminder','2026-03-27 02:03:32'),(10,'billing_cron_last_run','2026-03-31 10:15:49','Last auto-billing cron run time','2026-03-31 08:15:49');
/*!40000 ALTER TABLE `billing_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoices`
--

DROP TABLE IF EXISTS `invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_number` varchar(64) NOT NULL,
  `gateway_id` int(11) DEFAULT NULL,
  `username` varchar(128) NOT NULL,
  `planname` varchar(128) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `currency` varchar(3) DEFAULT 'BDT',
  `payment_method` varchar(32) DEFAULT '',
  `description` varchar(512) DEFAULT '',
  `status` enum('pending','processing','paid','failed','expired','cancelled','refunded') DEFAULT 'pending',
  `gateway_txn_id` varchar(256) DEFAULT '',
  `gateway_ref` varchar(256) DEFAULT '',
  `gateway_response` text DEFAULT NULL,
  `paid_at` datetime DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoice_number` (`invoice_number`),
  KEY `username` (`username`),
  KEY `status` (`status`),
  KEY `gateway_id` (`gateway_id`),
  CONSTRAINT `invoices_ibfk_1` FOREIGN KEY (`gateway_id`) REFERENCES `payment_gateways` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoices`
--

LOCK TABLES `invoices` WRITE;
/*!40000 ALTER TABLE `invoices` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mikrotik_devices`
--

DROP TABLE IF EXISTS `mikrotik_devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mikrotik_devices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `api_port` int(11) NOT NULL DEFAULT 8728,
  `api_user` varchar(64) NOT NULL DEFAULT 'admin',
  `api_pass` varchar(128) NOT NULL DEFAULT '',
  `description` varchar(255) DEFAULT '',
  `status` enum('online','offline','unknown') DEFAULT 'unknown',
  `is_default` tinyint(1) DEFAULT 0,
  `version` varchar(50) DEFAULT '',
  `board` varchar(100) DEFAULT '',
  `uptime` varchar(100) DEFAULT '',
  `last_sync` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_ip_port` (`ip_address`,`api_port`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mikrotik_devices`
--

LOCK TABLES `mikrotik_devices` WRITE;
/*!40000 ALTER TABLE `mikrotik_devices` DISABLE KEYS */;
INSERT INTO `mikrotik_devices` VALUES (1,'Main Router','192.168.1.1',8728,'admin','','Main office router','offline',1,'','','',NULL,'2026-03-27 11:23:43','2026-03-29 01:47:41');
/*!40000 ALTER TABLE `mikrotik_devices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nas`
--

DROP TABLE IF EXISTS `nas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nas` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `nasname` varchar(128) NOT NULL,
  `shortname` varchar(32) DEFAULT NULL,
  `type` varchar(30) DEFAULT 'other',
  `ports` int(5) DEFAULT NULL,
  `secret` varchar(60) NOT NULL DEFAULT 'secret',
  `server` varchar(64) DEFAULT NULL,
  `community` varchar(50) DEFAULT NULL,
  `description` varchar(200) DEFAULT 'RADIUS Client',
  `require_ma` varchar(4) DEFAULT 'auto',
  `limit_proxy_state` varchar(4) DEFAULT 'auto',
  PRIMARY KEY (`id`),
  KEY `nasname` (`nasname`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nas`
--

LOCK TABLES `nas` WRITE;
/*!40000 ALTER TABLE `nas` DISABLE KEYS */;
INSERT INTO `nas` VALUES (2,'180.149.232.33','KP-R2','Mikrotik',1812,'fcn1999','','','CCR-1009','auto','auto');
/*!40000 ALTER TABLE `nas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `olt_devices`
--

DROP TABLE IF EXISTS `olt_devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `olt_devices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `port` int(5) DEFAULT 23,
  `telnet_user` varchar(64) DEFAULT 'admin',
  `telnet_pass` varchar(128) DEFAULT '',
  `enable_pass` varchar(128) DEFAULT '',
  `vendor` varchar(64) DEFAULT 'generic',
  `model` varchar(128) DEFAULT '',
  `firmware` varchar(128) DEFAULT '',
  `connection_type` enum('telnet','ssh','snmp') DEFAULT 'telnet',
  `snmp_community` varchar(64) DEFAULT 'public',
  `snmp_version` int(1) DEFAULT 2,
  `snmp_port` int(5) DEFAULT 161,
  `slot_count` int(11) DEFAULT 16,
  `ports_per_slot` int(11) DEFAULT 4,
  `onus_per_port` int(11) DEFAULT 64,
  `status` enum('online','offline','unknown') DEFAULT 'unknown',
  `location` varchar(256) DEFAULT '',
  `description` varchar(512) DEFAULT '',
  `last_sync` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip_address` (`ip_address`),
  KEY `status` (`status`),
  KEY `vendor` (`vendor`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `olt_devices`
--

LOCK TABLES `olt_devices` WRITE;
/*!40000 ALTER TABLE `olt_devices` DISABLE KEYS */;
INSERT INTO `olt_devices` VALUES (1,'OLT-HeadOffice','192.168.1.10',23,'admin','admin','','huawei','MA5608T','','telnet','public',2,161,2,16,128,'offline','','Head Office Huawei OLT',NULL,'2026-03-27 02:03:19','2026-03-27 07:44:31'),(2,'OLT-Branch1','172.25.100.2',23,'admin','admin','','zte','ZXA10 C320','','telnet','public',2,161,2,16,64,'offline','','Branch 1 ZTE OLT',NULL,'2026-03-27 02:03:19','2026-03-27 09:00:06'),(3,'OLT-Branch2','192.168.1.30',23,'admin','admin','','fiberhome','AN5516-01','','telnet','public',2,161,4,16,128,'offline','','Branch 2 Fiberhome OLT',NULL,'2026-03-27 02:03:19','2026-03-27 07:44:41');
/*!40000 ALTER TABLE `olt_devices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `olt_pon_ports`
--

DROP TABLE IF EXISTS `olt_pon_ports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `olt_pon_ports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `olt_id` int(11) NOT NULL,
  `slot_number` int(11) NOT NULL,
  `port_number` int(11) NOT NULL,
  `port_name` varchar(64) DEFAULT '',
  `port_type` enum('EPON','GPON','XG-PON','XGS-PON') DEFAULT 'GPON',
  `status` enum('up','down','admin-down','unknown') DEFAULT 'unknown',
  `onu_count` int(11) DEFAULT 0,
  `rx_power` decimal(10,2) DEFAULT NULL,
  `tx_power` decimal(10,2) DEFAULT NULL,
  `description` varchar(256) DEFAULT '',
  `last_sync` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `olt_port` (`olt_id`,`slot_number`,`port_number`),
  KEY `olt_id` (`olt_id`),
  CONSTRAINT `olt_pon_ports_ibfk_1` FOREIGN KEY (`olt_id`) REFERENCES `olt_devices` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `olt_pon_ports`
--

LOCK TABLES `olt_pon_ports` WRITE;
/*!40000 ALTER TABLE `olt_pon_ports` DISABLE KEYS */;
/*!40000 ALTER TABLE `olt_pon_ports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `onu_alarms`
--

DROP TABLE IF EXISTS `onu_alarms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `onu_alarms` (
  `id` bigint(21) NOT NULL AUTO_INCREMENT,
  `olt_id` int(11) NOT NULL,
  `onu_id` int(11) DEFAULT NULL,
  `slot_number` int(11) DEFAULT NULL,
  `port_number` int(11) DEFAULT NULL,
  `onu_number` int(11) DEFAULT NULL,
  `alarm_type` varchar(64) NOT NULL,
  `severity` enum('critical','major','minor','warning','info') DEFAULT 'info',
  `message` text DEFAULT NULL,
  `cleared` tinyint(1) DEFAULT 0,
  `cleared_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `olt_id` (`olt_id`),
  KEY `severity` (`severity`),
  KEY `created_at` (`created_at`),
  CONSTRAINT `onu_alarms_ibfk_1` FOREIGN KEY (`olt_id`) REFERENCES `olt_devices` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `onu_alarms`
--

LOCK TABLES `onu_alarms` WRITE;
/*!40000 ALTER TABLE `onu_alarms` DISABLE KEYS */;
/*!40000 ALTER TABLE `onu_alarms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `onu_devices`
--

DROP TABLE IF EXISTS `onu_devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `onu_devices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `olt_id` int(11) NOT NULL,
  `pon_port_id` int(11) DEFAULT NULL,
  `slot_number` int(11) NOT NULL,
  `port_number` int(11) NOT NULL,
  `onu_number` int(11) NOT NULL,
  `onu_id` varchar(64) DEFAULT '',
  `serial_number` varchar(128) DEFAULT '',
  `mac_address` varchar(32) DEFAULT '',
  `name` varchar(128) DEFAULT '',
  `status` enum('online','offline','dying-gasp','unknown') DEFAULT 'unknown',
  `auth_status` enum('authorized','unauthorized','pending') DEFAULT 'pending',
  `distance` decimal(10,2) DEFAULT NULL,
  `uptime` int(12) DEFAULT 0,
  `last_down_time` datetime DEFAULT NULL,
  `last_down_reason` varchar(256) DEFAULT '',
  `rx_power` decimal(10,2) DEFAULT NULL,
  `tx_power` decimal(10,2) DEFAULT NULL,
  `olt_rx_power` decimal(10,2) DEFAULT NULL,
  `temperature` decimal(10,2) DEFAULT NULL,
  `voltage` decimal(10,2) DEFAULT NULL,
  `firmware` varchar(128) DEFAULT '',
  `equipment_id` varchar(256) DEFAULT '',
  `profile_name` varchar(128) DEFAULT '',
  `vlan_id` int(11) DEFAULT NULL,
  `bandwidth_up` varchar(64) DEFAULT '',
  `bandwidth_down` varchar(64) DEFAULT '',
  `description` varchar(256) DEFAULT '',
  `last_sync` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `olt_onu` (`olt_id`,`slot_number`,`port_number`,`onu_number`),
  KEY `olt_id` (`olt_id`),
  KEY `serial_number` (`serial_number`),
  KEY `mac_address` (`mac_address`),
  KEY `status` (`status`),
  CONSTRAINT `onu_devices_ibfk_1` FOREIGN KEY (`olt_id`) REFERENCES `olt_devices` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `onu_devices`
--

LOCK TABLES `onu_devices` WRITE;
/*!40000 ALTER TABLE `onu_devices` DISABLE KEYS */;
/*!40000 ALTER TABLE `onu_devices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `onu_eth_ports`
--

DROP TABLE IF EXISTS `onu_eth_ports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `onu_eth_ports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `onu_id` int(11) NOT NULL,
  `port_number` int(11) NOT NULL,
  `port_name` varchar(64) DEFAULT '',
  `status` enum('up','down','unknown') DEFAULT 'unknown',
  `speed` varchar(32) DEFAULT '',
  `duplex` varchar(16) DEFAULT '',
  `vlan_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `onu_id` (`onu_id`),
  CONSTRAINT `onu_eth_ports_ibfk_1` FOREIGN KEY (`onu_id`) REFERENCES `onu_devices` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `onu_eth_ports`
--

LOCK TABLES `onu_eth_ports` WRITE;
/*!40000 ALTER TABLE `onu_eth_ports` DISABLE KEYS */;
/*!40000 ALTER TABLE `onu_eth_ports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_gateways`
--

DROP TABLE IF EXISTS `payment_gateways`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_gateways` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `slug` varchar(64) NOT NULL,
  `gateway_url` varchar(512) NOT NULL,
  `api_key` varchar(256) DEFAULT '',
  `api_secret` varchar(256) DEFAULT '',
  `callback_url` varchar(512) DEFAULT '',
  `method` enum('bkash','nagad','rocket','bank','card','all') DEFAULT 'all',
  `currency` varchar(3) DEFAULT 'BDT',
  `auto_activate` tinyint(1) DEFAULT 0,
  `min_amount` decimal(10,2) DEFAULT 10.00,
  `max_amount` decimal(10,2) DEFAULT 50000.00,
  `status` enum('active','inactive','test') DEFAULT 'test',
  `description` varchar(512) DEFAULT '',
  `config_json` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_gateways`
--

LOCK TABLES `payment_gateways` WRITE;
/*!40000 ALTER TABLE `payment_gateways` DISABLE KEYS */;
INSERT INTO `payment_gateways` VALUES (1,'PiPraPay bKash','piprapay-bkash','https://billing.fcnchbd.xyz/bkash/ngod/getway','','','','bkash','BDT',0,10.00,50000.00,'active','PiPraPay bKash/Nagad Gateway',NULL,'2026-03-27 02:03:08','2026-03-27 02:03:08');
/*!40000 ALTER TABLE `payment_gateways` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_transactions`
--

DROP TABLE IF EXISTS `payment_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_transactions` (
  `id` bigint(21) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) DEFAULT NULL,
  `gateway_id` int(11) DEFAULT NULL,
  `username` varchar(128) NOT NULL,
  `txn_type` enum('payment','refund','reversal') DEFAULT 'payment',
  `amount` decimal(10,2) NOT NULL,
  `currency` varchar(3) DEFAULT 'BDT',
  `payment_method` varchar(32) DEFAULT '',
  `gateway_txn_id` varchar(256) DEFAULT '',
  `gateway_ref` varchar(256) DEFAULT '',
  `status` enum('success','failed','pending','cancelled') DEFAULT 'pending',
  `request_data` text DEFAULT NULL,
  `response_data` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT '',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `invoice_id` (`invoice_id`),
  KEY `username` (`username`),
  KEY `status` (`status`),
  KEY `created_at` (`created_at`),
  CONSTRAINT `payment_transactions_ibfk_1` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_transactions`
--

LOCK TABLES `payment_transactions` WRITE;
/*!40000 ALTER TABLE `payment_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radacct`
--

DROP TABLE IF EXISTS `radacct`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `radacct` (
  `radacctid` bigint(21) NOT NULL AUTO_INCREMENT,
  `acctsessionid` varchar(64) NOT NULL DEFAULT '',
  `acctuniqueid` varchar(32) NOT NULL DEFAULT '',
  `username` varchar(64) NOT NULL DEFAULT '',
  `groupname` varchar(64) NOT NULL DEFAULT '',
  `realm` varchar(64) DEFAULT '',
  `nasipaddress` varchar(15) NOT NULL DEFAULT '',
  `nasportid` varchar(32) DEFAULT NULL,
  `nasporttype` varchar(32) DEFAULT NULL,
  `acctstarttime` datetime DEFAULT NULL,
  `acctupdatetime` datetime DEFAULT NULL,
  `acctstoptime` datetime DEFAULT NULL,
  `acctinterval` int(12) DEFAULT NULL,
  `acctsessiontime` int(12) unsigned DEFAULT NULL,
  `acctauthentic` varchar(32) DEFAULT NULL,
  `connectinfo_start` varchar(50) DEFAULT NULL,
  `connectinfo_stop` varchar(50) DEFAULT NULL,
  `acctinputoctets` bigint(20) DEFAULT NULL,
  `acctoutputoctets` bigint(20) DEFAULT NULL,
  `calledstationid` varchar(50) NOT NULL DEFAULT '',
  `callingstationid` varchar(50) NOT NULL DEFAULT '',
  `acctterminatecause` varchar(32) NOT NULL DEFAULT '',
  `servicetype` varchar(32) DEFAULT NULL,
  `framedprotocol` varchar(32) DEFAULT NULL,
  `framedipaddress` varchar(15) NOT NULL DEFAULT '',
  `framedipv6address` varchar(45) NOT NULL DEFAULT '',
  `framedipv6prefix` varchar(45) NOT NULL DEFAULT '',
  `framedinterfaceid` varchar(44) NOT NULL DEFAULT '',
  `delegatedipv6prefix` varchar(45) NOT NULL DEFAULT '',
  `class` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`radacctid`),
  UNIQUE KEY `acctuniqueid` (`acctuniqueid`),
  KEY `username` (`username`),
  KEY `framedipaddress` (`framedipaddress`),
  KEY `acctstoptime` (`acctstoptime`),
  KEY `nasipaddress` (`nasipaddress`),
  KEY `bulk_close` (`acctstoptime`,`nasipaddress`,`acctstarttime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radacct`
--

LOCK TABLES `radacct` WRITE;
/*!40000 ALTER TABLE `radacct` DISABLE KEYS */;
/*!40000 ALTER TABLE `radacct` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radcheck`
--

DROP TABLE IF EXISTS `radcheck`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `radcheck` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL DEFAULT '',
  `attribute` varchar(64) NOT NULL DEFAULT '',
  `op` char(2) NOT NULL DEFAULT '==',
  `value` varchar(253) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `username` (`username`(32))
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radcheck`
--

LOCK TABLES `radcheck` WRITE;
/*!40000 ALTER TABLE `radcheck` DISABLE KEYS */;
INSERT INTO `radcheck` VALUES (1,'user1','Cleartext-Password',':=','pass123'),(2,'user2','Cleartext-Password',':=','pass456'),(3,'user3','Cleartext-Password',':=','pass789'),(5,'admin','Cleartext-Password',':=','ab123'),(6,'ppp1','Cleartext-Password',':=','fcn@1999'),(7,'testuser','Cleartext-Password',':=','test123'),(8,'fcnpc','Cleartext-Password',':=','ab1234'),(9,'test','Cleartext-Password',':=','ab1234');
/*!40000 ALTER TABLE `radcheck` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radgroupcheck`
--

DROP TABLE IF EXISTS `radgroupcheck`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `radgroupcheck` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `groupname` varchar(64) NOT NULL DEFAULT '',
  `attribute` varchar(64) NOT NULL DEFAULT '',
  `op` char(2) NOT NULL DEFAULT '==',
  `value` varchar(253) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `groupname` (`groupname`(32))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radgroupcheck`
--

LOCK TABLES `radgroupcheck` WRITE;
/*!40000 ALTER TABLE `radgroupcheck` DISABLE KEYS */;
/*!40000 ALTER TABLE `radgroupcheck` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radgroupreply`
--

DROP TABLE IF EXISTS `radgroupreply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `radgroupreply` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `groupname` varchar(64) NOT NULL DEFAULT '',
  `attribute` varchar(64) NOT NULL DEFAULT '',
  `op` char(2) NOT NULL DEFAULT '=',
  `value` varchar(253) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `groupname` (`groupname`(32))
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radgroupreply`
--

LOCK TABLES `radgroupreply` WRITE;
/*!40000 ALTER TABLE `radgroupreply` DISABLE KEYS */;
INSERT INTO `radgroupreply` VALUES (3,'standard_5mbps','Mikrotik-Rate-Limit','=','5M/10M 10M/20M 5M/10M 40/40'),(4,'standard_5mbps','Acct-Interim-Interval','=','300'),(5,'premium_10mbps','Mikrotik-Rate-Limit','=','10M/20M 20M/40M 10M/20M 40/40'),(6,'premium_10mbps','Acct-Interim-Interval','=','300'),(7,'HOME','Mikrotik-Rate-Limit','=','1M/2M 2M/4M 1M/2M 40/40'),(8,'HOME','Acct-Interim-Interval','=','500');
/*!40000 ALTER TABLE `radgroupreply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radpostauth`
--

DROP TABLE IF EXISTS `radpostauth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `radpostauth` (
  `id` bigint(21) NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL DEFAULT '',
  `pass` varchar(64) NOT NULL DEFAULT '',
  `reply` varchar(32) NOT NULL DEFAULT '',
  `authdate` timestamp(6) NOT NULL DEFAULT current_timestamp(6),
  `class` varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radpostauth`
--

LOCK TABLES `radpostauth` WRITE;
/*!40000 ALTER TABLE `radpostauth` DISABLE KEYS */;
/*!40000 ALTER TABLE `radpostauth` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radreply`
--

DROP TABLE IF EXISTS `radreply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `radreply` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL DEFAULT '',
  `attribute` varchar(64) NOT NULL DEFAULT '',
  `op` char(2) NOT NULL DEFAULT '=',
  `value` varchar(253) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `username` (`username`(32))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radreply`
--

LOCK TABLES `radreply` WRITE;
/*!40000 ALTER TABLE `radreply` DISABLE KEYS */;
/*!40000 ALTER TABLE `radreply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radusergroup`
--

DROP TABLE IF EXISTS `radusergroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `radusergroup` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL DEFAULT '',
  `groupname` varchar(64) NOT NULL DEFAULT '',
  `priority` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `username` (`username`(32))
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radusergroup`
--

LOCK TABLES `radusergroup` WRITE;
/*!40000 ALTER TABLE `radusergroup` DISABLE KEYS */;
INSERT INTO `radusergroup` VALUES (1,'user1','HOME',1),(2,'user2','standard_5mbps',1),(3,'user3','premium_10mbps',1),(5,'admin','Fiber 50 Mbps',1),(7,'fcnpc','FCN-PKG-500TK',1),(8,'testuser','default',1);
/*!40000 ALTER TABLE `radusergroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reseller_config`
--

DROP TABLE IF EXISTS `reseller_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reseller_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reseller_id` int(11) NOT NULL,
  `credit_limit` decimal(12,2) DEFAULT 0.00,
  `used_credit` decimal(12,2) DEFAULT 0.00,
  `commission_rate` decimal(5,2) DEFAULT 0.00,
  `allowed_plans` text DEFAULT NULL,
  `allowed_groups` text DEFAULT NULL,
  `max_users` int(11) DEFAULT 100,
  `can_create_plans` tinyint(1) DEFAULT 0,
  `can_view_reports` tinyint(1) DEFAULT 1,
  `can_manage_own_users` tinyint(1) DEFAULT 1,
  `prefix` varchar(16) DEFAULT '',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `reseller_id` (`reseller_id`),
  CONSTRAINT `reseller_config_ibfk_1` FOREIGN KEY (`reseller_id`) REFERENCES `admin_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reseller_config`
--

LOCK TABLES `reseller_config` WRITE;
/*!40000 ALTER TABLE `reseller_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `reseller_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reseller_transactions`
--

DROP TABLE IF EXISTS `reseller_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reseller_transactions` (
  `id` bigint(21) NOT NULL AUTO_INCREMENT,
  `reseller_id` int(11) NOT NULL,
  `txn_type` enum('credit','debit','commission','refund') DEFAULT 'credit',
  `amount` decimal(12,2) NOT NULL,
  `balance_after` decimal(12,2) DEFAULT 0.00,
  `description` varchar(512) DEFAULT '',
  `reference_id` varchar(128) DEFAULT '',
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `reseller_id` (`reseller_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reseller_transactions`
--

LOCK TABLES `reseller_transactions` WRITE;
/*!40000 ALTER TABLE `reseller_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `reseller_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms_config`
--

DROP TABLE IF EXISTS `sms_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sms_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `provider` varchar(64) NOT NULL,
  `api_url` varchar(512) NOT NULL,
  `api_key` varchar(256) DEFAULT '',
  `api_secret` varchar(256) DEFAULT '',
  `sender_id` varchar(32) DEFAULT '',
  `mask` varchar(32) DEFAULT '',
  `status` enum('active','inactive') DEFAULT 'active',
  `config_json` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms_config`
--

LOCK TABLES `sms_config` WRITE;
/*!40000 ALTER TABLE `sms_config` DISABLE KEYS */;
INSERT INTO `sms_config` VALUES (1,'sslwireless','https://sms.sslwireless.com/pushapi/dynamic/server.php','','','','','inactive',NULL,'2026-03-27 02:03:32','2026-03-27 02:03:32'),(2,'bulksmsbd','https://bulksmsbd.net/api/smsapi','','','','','inactive',NULL,'2026-03-27 02:03:32','2026-03-27 02:03:32'),(3,'mimsms','https://api.mimsms.com/smsapiv2','','','','','inactive',NULL,'2026-03-27 02:03:32','2026-03-27 02:03:32'),(4,'greenweb','https://api.greenweb.com.bd/api.php','','','','','inactive',NULL,'2026-03-27 02:03:32','2026-03-27 02:03:32');
/*!40000 ALTER TABLE `sms_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms_log`
--

DROP TABLE IF EXISTS `sms_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sms_log` (
  `id` bigint(21) NOT NULL AUTO_INCREMENT,
  `username` varchar(128) DEFAULT NULL,
  `phone` varchar(32) NOT NULL,
  `message` text NOT NULL,
  `template_id` int(11) DEFAULT NULL,
  `event_type` varchar(64) DEFAULT '',
  `provider` varchar(64) DEFAULT '',
  `api_response` text DEFAULT NULL,
  `status` enum('sent','failed','pending','delivered') DEFAULT 'pending',
  `sms_id` varchar(128) DEFAULT '',
  `cost` decimal(6,4) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `username` (`username`),
  KEY `phone` (`phone`),
  KEY `status` (`status`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms_log`
--

LOCK TABLES `sms_log` WRITE;
/*!40000 ALTER TABLE `sms_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `sms_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms_templates`
--

DROP TABLE IF EXISTS `sms_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sms_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_name` varchar(128) NOT NULL,
  `event_type` varchar(64) NOT NULL,
  `message_en` text NOT NULL,
  `message_bn` text DEFAULT NULL,
  `variables` varchar(512) DEFAULT '',
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `event_type` (`event_type`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms_templates`
--

LOCK TABLES `sms_templates` WRITE;
/*!40000 ALTER TABLE `sms_templates` DISABLE KEYS */;
INSERT INTO `sms_templates` VALUES (1,'Invoice Generated','invoice_generated','Dear {username}, your invoice #{invoice_number} of {amount} {currency} has been generated. Due date: {due_date}. Pay now to avoid service interruption.','প্রিয় {username}, আপনার ইনভয়েস #{invoice_number} {amount} {currency} তৈরি হয়েছে। পরিশোধের তারিখ: {due_date}।','{username},{invoice_number},{amount},{currency},{due_date}','active','2026-03-27 02:03:32'),(2,'Payment Reminder','payment_reminder','Dear {username}, your bill of {amount} {currency} is due on {due_date}. Please pay to continue your internet service.','প্রিয় {username}, আপনার {amount} {currency} বিল {due_date} তারিখে পরিশোধযোগ্য।','{username},{amount},{currency},{due_date}','active','2026-03-27 02:03:32'),(3,'Payment Received','payment_received','Dear {username}, we received your payment of {amount} {currency}. Invoice: {invoice_number}. Your service is active. Thank you!','প্রিয় {username}, আপনার {amount} {currency} পেমেন্ট গৃহীত হয়েছে। ইনভয়েস: {invoice_number}। ধন্যবাদ!','{username},{amount},{currency},{invoice_number}','active','2026-03-27 02:03:32'),(4,'Service Suspended','service_suspended','Dear {username}, your internet service has been suspended due to non-payment. Please pay {amount} {currency} to reactivate.','প্রিয় {username}, বিল না দেওয়ায় আপনার ইন্টারনেট সেবা স্থগিত করা হয়েছে। {amount} {currency} পরিশোধ করুন।','{username},{amount},{currency}','active','2026-03-27 02:03:32'),(5,'Service Reactivated','service_reactivated','Dear {username}, your internet service has been reactivated. Thank you for your payment!','প্রিয় {username}, আপনার ইন্টারনেট সেবা পুনরায় সক্রিয় করা হয়েছে। ধন্যবাদ!','{username}','active','2026-03-27 02:03:32'),(6,'Overdue Warning','overdue_warning','Dear {username}, your payment of {amount} {currency} is overdue. Service will be suspended in {grace_days} days. Pay now!','প্রিয় {username}, আপনার {amount} {currency} বিল বকেয়া। {grace_days} দিনের মধ্যে পরিশোধ না করলে সেবা বন্ধ হবে।','{username},{amount},{currency},{grace_days}','active','2026-03-27 02:03:32'),(7,'New Connection','new_connection','Welcome {username}! Your internet service is now active. Plan: {planname}, Speed: {rate_limit}. Support: {support_number}','স্বাগতম {username}! আপনার ইন্টারনেট সেবা সক্রিয়। প্ল্যান: {planname}, গতি: {rate_limit}।','{username},{planname},{rate_limit},{support_number}','active','2026-03-27 02:03:32'),(8,'Renewal Confirmation','renewal_confirmed','Dear {username}, your plan {planname} has been renewed. Next billing: {next_date}. Amount: {amount} {currency}.','প্রিয় {username}, আপনার প্ল্যান {planname} নবায়ন হয়েছে। পরবর্তী বিলিং: {next_date}।','{username},{planname},{next_date},{amount},{currency}','active','2026-03-27 02:03:32');
/*!40000 ALTER TABLE `sms_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_settings`
--

DROP TABLE IF EXISTS `system_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_group` varchar(64) NOT NULL DEFAULT 'general',
  `setting_key` varchar(128) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `setting_type` enum('text','number','boolean','json','select','textarea') DEFAULT 'text',
  `label` varchar(128) DEFAULT '',
  `description` varchar(512) DEFAULT '',
  `options` text DEFAULT NULL,
  `sort_order` int(11) DEFAULT 0,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`),
  KEY `setting_group` (`setting_group`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_settings`
--

LOCK TABLES `system_settings` WRITE;
/*!40000 ALTER TABLE `system_settings` DISABLE KEYS */;
INSERT INTO `system_settings` VALUES (1,'general','company_name','ISP Billing','text','Company Name','Your company name displayed in invoices and SMS',NULL,1,NULL,'2026-03-27 02:02:53'),(2,'general','company_logo','','text','Company Logo URL','URL to your company logo',NULL,2,NULL,'2026-03-27 02:02:53'),(3,'general','company_email','billing@example.com','text','Company Email','Contact email address',NULL,3,NULL,'2026-03-27 02:02:53'),(4,'general','company_phone','+8801XXXXXXXXX','text','Company Phone','Contact phone number',NULL,4,NULL,'2026-03-27 02:02:53'),(5,'general','company_address','','textarea','Company Address','Physical address',NULL,5,NULL,'2026-03-27 02:02:53'),(6,'general','currency','BDT','text','Currency','Default currency code',NULL,6,NULL,'2026-03-27 02:02:53'),(7,'general','currency_symbol','','text','Currency Symbol','Currency symbol (auto-detected if empty)',NULL,7,NULL,'2026-03-27 02:02:53'),(8,'general','timezone','Asia/Dhaka','select','Timezone','System timezone','[\"Asia\\/Dhaka\",\"Asia\\/Kolkata\",\"UTC\",\"America\\/New_York\",\"Europe\\/London\"]',8,NULL,'2026-03-27 02:02:53'),(9,'general','date_format','d M Y','text','Date Format','PHP date format for display',NULL,9,NULL,'2026-03-27 02:02:53'),(10,'general','language','en','select','Language','Default language','[\"en\",\"bn\"]',10,NULL,'2026-03-27 02:02:53'),(11,'security','session_timeout','3600','number','Session Timeout (seconds)','Auto-logout after inactivity',NULL,1,NULL,'2026-03-27 02:02:53'),(12,'security','max_login_attempts','5','number','Max Login Attempts','Lock account after failed attempts',NULL,2,NULL,'2026-03-27 02:02:53'),(13,'security','lock_duration','900','number','Lock Duration (seconds)','How long account stays locked',NULL,3,NULL,'2026-03-27 02:02:53'),(14,'security','password_min_length','6','number','Min Password Length','Minimum password length for admin users',NULL,4,NULL,'2026-03-27 02:02:53'),(15,'security','require_strong_password','0','boolean','Require Strong Password','Require uppercase, number, special char',NULL,5,NULL,'2026-03-27 02:02:53'),(16,'security','two_factor_enabled','0','boolean','Two-Factor Auth','Enable 2FA for admin login',NULL,6,NULL,'2026-03-27 02:02:53'),(17,'security','allowed_ips','','textarea','Allowed IPs','Comma-separated IPs allowed to access admin (empty = all)',NULL,7,NULL,'2026-03-27 02:02:53'),(18,'user_defaults','default_plan','','text','Default Plan','Default plan for new users',NULL,1,NULL,'2026-03-27 02:02:53'),(19,'user_defaults','default_group','','text','Default Group','Default group for new users',NULL,2,NULL,'2026-03-27 02:02:53'),(20,'user_defaults','default_simultaneous_use','1','number','Default Simultaneous Use','Default concurrent session limit',NULL,3,NULL,'2026-03-27 02:02:53'),(21,'user_defaults','auto_generate_username','0','boolean','Auto Generate Username','Auto-generate username from prefix + number',NULL,4,NULL,'2026-03-27 02:02:53'),(22,'user_defaults','username_prefix','user','text','Username Prefix','Prefix for auto-generated usernames',NULL,5,NULL,'2026-03-27 02:02:53'),(23,'user_defaults','auto_generate_password','0','boolean','Auto Generate Password','Auto-generate random password',NULL,6,NULL,'2026-03-27 02:02:53'),(24,'user_defaults','password_length','8','number','Generated Password Length','Length of auto-generated passwords',NULL,7,NULL,'2026-03-27 02:02:53'),(25,'user_defaults','send_welcome_sms','0','boolean','Send Welcome SMS','Send SMS when user is created',NULL,8,NULL,'2026-03-27 02:02:53'),(26,'reseller','reseller_can_delete_users','0','boolean','Reseller Can Delete Users','Allow resellers to delete their users',NULL,1,NULL,'2026-03-27 02:02:53'),(27,'reseller','reseller_can_view_all','0','boolean','Reseller Can View All','Allow resellers to see all users (not just their own)',NULL,2,NULL,'2026-03-27 02:02:53'),(28,'reseller','reseller_prefix_required','0','boolean','Require Username Prefix','Force resellers to use a username prefix',NULL,3,NULL,'2026-03-27 02:02:53'),(29,'reseller','default_credit_limit','10000','number','Default Credit Limit','Default credit limit for new resellers',NULL,4,NULL,'2026-03-27 02:02:53'),(30,'reseller','default_commission_rate','10','number','Default Commission Rate (%)','Default commission percentage',NULL,5,NULL,'2026-03-27 02:02:53'),(31,'reseller','auto_credit_on_payment','1','boolean','Auto Credit on Payment','Auto-add credit when reseller pays',NULL,6,NULL,'2026-03-27 02:02:53'),(32,'notifications','notify_on_new_user','1','boolean','Notify on New User','Send notification when user is created',NULL,1,NULL,'2026-03-27 02:02:53'),(33,'notifications','notify_on_payment','1','boolean','Notify on Payment','Send notification on successful payment',NULL,2,NULL,'2026-03-27 02:02:53'),(34,'notifications','notify_on_suspension','1','boolean','Notify on Suspension','Send notification when user is suspended',NULL,3,NULL,'2026-03-27 02:02:53'),(35,'notifications','notify_on_low_credit','1','boolean','Notify on Low Credit','Alert reseller when credit is low',NULL,4,NULL,'2026-03-27 02:02:53'),(36,'notifications','low_credit_threshold','1000','number','Low Credit Threshold','Amount below which to alert',NULL,5,NULL,'2026-03-27 02:02:53'),(37,'notifications','admin_email_notifications','0','boolean','Admin Email Notifications','Send email alerts to admin',NULL,6,NULL,'2026-03-27 02:02:53'),(38,'invoice','invoice_prefix','INV','text','Invoice Prefix','Prefix for invoice numbers',NULL,1,NULL,'2026-03-27 02:02:53'),(39,'invoice','invoice_footer','Thank you for your business!','textarea','Invoice Footer','Text shown at bottom of invoices',NULL,2,NULL,'2026-03-27 02:02:53'),(40,'invoice','invoice_due_days','7','number','Invoice Due Days','Default days until invoice is due',NULL,3,NULL,'2026-03-27 02:02:53'),(41,'invoice','auto_generate_invoice','1','boolean','Auto Generate Invoices','Auto-create invoices on billing date',NULL,4,NULL,'2026-03-27 02:02:53'),(42,'system','maintenance_mode','0','boolean','Maintenance Mode','Enable maintenance mode (only super admin can access)',NULL,1,NULL,'2026-03-27 02:02:53'),(43,'system','debug_mode','0','boolean','Debug Mode','Enable debug logging',NULL,2,NULL,'2026-03-27 02:02:53'),(44,'system','backup_enabled','0','boolean','Auto Backup','Enable automatic database backup',NULL,3,NULL,'2026-03-27 02:02:53'),(45,'system','backup_frequency','daily','select','Backup Frequency','How often to backup','[\"daily\",\"weekly\",\"monthly\"]',4,NULL,'2026-03-27 02:02:53'),(46,'general','action','update_settings','text','','',NULL,0,NULL,'2026-03-27 06:56:20');
/*!40000 ALTER TABLE `system_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_balance`
--

DROP TABLE IF EXISTS `user_balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_balance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(128) NOT NULL,
  `balance` decimal(10,2) DEFAULT 0.00,
  `total_paid` decimal(10,2) DEFAULT 0.00,
  `total_invoiced` decimal(10,2) DEFAULT 0.00,
  `last_payment_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_balance`
--

LOCK TABLES `user_balance` WRITE;
/*!40000 ALTER TABLE `user_balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userbillinfo`
--

DROP TABLE IF EXISTS `userbillinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userbillinfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(128) NOT NULL,
  `planname` varchar(64) DEFAULT NULL,
  `contactname` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `address` varchar(256) DEFAULT NULL,
  `city` varchar(128) DEFAULT NULL,
  `state` varchar(128) DEFAULT NULL,
  `zip` varchar(20) DEFAULT NULL,
  `country` varchar(64) DEFAULT NULL,
  `paymentmethod` varchar(64) DEFAULT NULL,
  `billstatus` varchar(16) DEFAULT 'new',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `planname` (`planname`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userbillinfo`
--

LOCK TABLES `userbillinfo` WRITE;
/*!40000 ALTER TABLE `userbillinfo` DISABLE KEYS */;
INSERT INTO `userbillinfo` VALUES (1,'user1','basic_1mbps','John Doe','john@example.com','+1234567890',NULL,'New York',NULL,NULL,'US',NULL,'new','2026-03-27 02:02:40','2026-03-27 02:02:40'),(2,'user2','standard_5mbps','Jane Smith','jane@example.com','+0987654321',NULL,'Los Angeles',NULL,NULL,'US',NULL,'new','2026-03-27 02:02:40','2026-03-27 02:02:40'),(3,'user3','premium_10mbps','Bob Wilson','bob@example.com','+1122334455',NULL,'Chicago',NULL,NULL,'US',NULL,'new','2026-03-27 02:02:40','2026-03-27 02:02:40');
/*!40000 ALTER TABLE `userbillinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'radius'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-04-10  1:43:49
